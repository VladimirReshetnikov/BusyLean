# BusyLean Contender 55: Self-Indexed Plethystic Free-Monad Reactor

This archive proposes a computable Lean natural number above the strongest
pending BusyLean baseline, Contender 54 TILED.

## Definition

A finite nonsymmetric polynomial container is represented by the list of the
arities of its operations.  The independent engine combines:

1. container substitution (plethysm), retaining the full arity spectrum;
2. formal derivatives and finite jets of pointed contexts;
3. a feedback crown whose new arity is the current polynomial value; and
4. finite free-monad approximants, i.e. bounded trees over the crowned
   signature.

For input `n`, the same parameter controls the evaluation point, jet order,
free-term depth, and number of outer reactor rounds.  Let `coreValue n` be the
resulting polynomial value and

    reactorValue n = n + 1 + coreValue n.

The small additive prefix is only a transparent strict-progress certificate.
The mechanism-level payload is `coreValue`.

Let

    family54 n = F54 (F54 n)
    N          = family54 n
    F55 n      = iterate reactorValue (N + 1) N
    contender_55 = F55 (F55 42).

The predecessor supplies only `N`, the seed and finite iteration budget.  No
iteration of `F54`, reflection operator, ordinal-tree reader, large-elimination
operator, or ideal-completion engine occurs inside the reactor.

The comparison module is designed to prove

    contender_54 < contender_55

and the stronger closed lower bound

    iterate reactorValue (contender_54 + 1) contender_54
      < contender_55.

## Important files

* `article/contender55_plethystic_reactor.tex` and `.pdf` - research article;
* `lean/BusyLean/Plethystic.lean` - independent executable engine;
* `lean/BusyLean/Contender55.lean` - BusyLean adapter;
* `lean/BusyLean/Comparison55.lean` - strict comparison chain;
* `lean/test/` - exact reductions, theorem checks, and axiom report commands;
* `scripts/reference_model.py` - independent exact Python model;
* `scripts/static_check.py` - escape-hatch and novelty audit;
* `scripts/build_overlay.sh` - integration and kernel-replay script;
* `patches/contender55.patch` - repository patch;
* `VALIDATION.md` - precise completed and outstanding checks.

The assembly container could not run Lean 4.34.0.  No kernel result is claimed
without evidence; see `VALIDATION.md`.
