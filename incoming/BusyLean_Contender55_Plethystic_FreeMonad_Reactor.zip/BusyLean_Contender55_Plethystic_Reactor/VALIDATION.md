# Validation status

## Completed in this package

* independent Python reference model with 254 exact assertions;
* finite-grid checks of plethysm, shape-count, and derivative identities;
* exact reductions `coreValue 0 = 8206` and `reactorValue 0 = 8207`;
* a symbolic positive-input expansion diagnostic without materializing the
  infeasible list;
* static audit for `axiom`, `sorry`, `admit`, `unsafe`, `partial`,
  `noncomputable`, `Classical.choice`, and `native_decide`;
* dependency and mechanism-level novelty audit of the independent core;
* LaTeX compilation, PDF metadata and text checks, and page rendering;
* archive manifest, ZIP integrity check, and SHA-256 hashes.

## Outstanding

The assembly container has no Lean, Lake, or Elan installation and no network
route for installing the repository's pinned Lean 4.34.0 toolchain.  Therefore
this package does **not** claim a fresh kernel build of Contender 55.

The prerequisite TILED patch is copied from its prior archive, which records a
successful clean Lean 4.34.0 run.  The three new Lean modules must still be
replayed in a BusyLean checkout with:

    scripts/build_overlay.sh /path/to/BusyLean

A kernel failure would be an implementation defect to repair, not a change to
the finite mathematical definition.  No unverified build is represented as a
successful one.
