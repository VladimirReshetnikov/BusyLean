# Formalization notes and next lemmas

The trusted comparison path is intentionally small.  It requires only:

1. structural executability of the finite reactor;
2. the transparent theorem `n < reactorValue n`;
3. a generic positive-orbit lemma; and
4. the predecessor theorem `n < F54 n`.

No proof unfolds a closed contender-sized value.

The mathematical article proves the main structural identities on paper, and
the independent Python model checks them on a finite grid.  Natural next Lean
lemmas are:

1. `polyEval_compose`;
2. `length_compose`;
3. `polyEval_derivative`;
4. `polyEval_freeApprox`;
5. monotonicity of `polyEval` in its argument;
6. `n + 2 <= coreValue n`;
7. the formal recurrence lower bound for `coreValue`.

They are not needed to denote the number or compare it with the predecessor.
Keeping them out of the comparison module reduces the risk that simplification
will normalize a contender-sized closed term.
