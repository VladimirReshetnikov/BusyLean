# Growth facts

For a finite arity signature `A`, write

    P_A(x) = sum_{a in A} x^a.

The executable definitions satisfy the following exact identities.

1. **Plethysm.** `P_(A compose B)(x) = P_A(P_B(x))`.
2. **Shape count.** `|A compose B| = P_A(|B|)`.
3. **Derivative.** `P_(derivative A)(x) = d/dx P_A(x)`.
4. **Free terms.** If `T_0(x)=x` and
   `T_(k+1)(x)=x+P_A(T_k(x))`, then
   `P_(freeApprox A k)(x)=T_k(x)`.

For a reactor parameter `n`, set `x=n+2`.  Suppose an incoming state has value
`v=P_A(x)`.  Its jet `J` contains `A`, so `P_J(x)>=v`.  The crown adds a
monomial of degree

    d = P_J(x) + 1 >= v + 1.

During the `n+1` free-term stages, if `q_0=x` then

    q_(k+1) = x + P_C(q_k) >= q_k^d.

Consequently one complete reactor step has value at least

    x^(d^(n+1)) >= x^((v+1)^(n+1)).

Writing

    v_0 = 1 + x + x^(n+2),
    v_(r+1) = x^((v_r+1)^(n+1)),

the autonomous payload obeys

    coreValue(n) >= v_(n+1).

This is deliberately conservative: it ignores every jet term except the
feedback crown and ignores the additive variable in later free stages.

For `n=1`, even before the first outer reactor step has completed, the second
free stage contains exactly

    54339821358090949193236971635850702892227949026963430834147317227689200080931186676025394783

operations.  The independent model derives this count without materializing
the list.

At repository scale, put `N=contender_54`.  The first public value `F55 42` is
exactly `N+1` iterations of this autonomous reactor starting at `N`; the final
closed contender applies the complete `F55` family once more at that already
larger input.
