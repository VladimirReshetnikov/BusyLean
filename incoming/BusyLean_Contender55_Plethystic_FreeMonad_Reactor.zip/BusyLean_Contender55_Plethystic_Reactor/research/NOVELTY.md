# Mechanism-level novelty audit

The independent module `BusyLean/Plethystic.lean` manipulates finite polynomial
containers.  It does not import or mention:

* BusyLean's reflection operators;
* ordinal trees or collapsing functions;
* enumeration or normalization of object-language programs;
* tree-indexed large elimination;
* finite-poset ideal completion.

The state is a finite multiset of operation arities with multiplicity.
Container substitution uses the complete arity spectrum.  This state cannot be
replaced by its cardinality: signatures `[1,1]` and `[0,2]` both have two
operations, but substitution into an `m`-operation signature produces `2m` and
`1+m^2` composite operations, respectively.

Nor can the state be replaced by its value at the calibration point.  At
`x=2`, signatures `[2]` and `[0,0,1]` both evaluate to `4`, but their derivative
values are `4` and `1`.  The jet therefore separates signatures that a scalar
feedback loop would identify.

The predecessor occurs only in `Contender55.lean`, where it supplies a
numerical seed and finite iteration budget.  The public definition does not
iterate the predecessor family.  Deleting all BusyLean adapter files leaves a
standalone executable reactor; deleting the reactor leaves no large-number
mechanism, only the predecessor seed.

The ingredients (polynomial functors, substitution, derivative, free monads)
are established mathematics.  The proposed novelty is their specific
self-indexed combination as an executable large-number reactor and its use as
a new BusyLean successor mechanism.
