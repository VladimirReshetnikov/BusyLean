# Baseline and target

Repository snapshot inspected: `VladimirReshetnikov/BusyLean` at
`650b23afcc266fb90d0140bc4bbc136d63f07209` (13 October 2026).

The integrated hierarchy ends at Contender 53.  Two incoming Contender 54
archives are present.  The default prerequisite for this package is TILED
(Tree-Indexed Large Elimination), because its archive records a successful
Lean 4.34.0 clean build at commit
`803c9771c730fd0125eb6a8ebd877a90782e9fff`.

The adapter deliberately uses only the common public API:

* `F54 : Nat -> Nat`;
* `contender_54 : Nat := F54 (F54 42)`;
* `input_lt_F54 : forall n, n < F54 n`.

Therefore the same Contender 55 files can be placed over the Birkhoff-Sperner
Contender 54 alternative if that proposal is adopted instead.
