#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "usage: $0 /path/to/BusyLean" >&2
  exit 2
fi

ROOT=$(cd "$(dirname "$0")/.." && pwd)
REPO=$(cd "$1" && pwd)

if [[ ! -f "$REPO/lean-toolchain" || ! -f "$REPO/BusyLean.lean" ]]; then
  echo "not a BusyLean checkout: $REPO" >&2
  exit 2
fi

# Current main stops at Contender 53.  Install the CI-verified TILED Contender
# 54 baseline when no Contender 54 is present.  If another accepted Contender 54
# already exists, retain it: the Contender 55 adapter needs only the public API.
if [[ ! -f "$REPO/BusyLean/Contender54.lean" ]]; then
  (cd "$REPO" && git apply "$ROOT/baseline/contender54-tiled.patch")
fi

cp "$ROOT/lean/BusyLean/Plethystic.lean" "$REPO/BusyLean/Plethystic.lean"
cp "$ROOT/lean/BusyLean/Contender55.lean" "$REPO/BusyLean/Contender55.lean"
cp "$ROOT/lean/BusyLean/Comparison55.lean" "$REPO/BusyLean/Comparison55.lean"
cp "$ROOT/lean/test/PlethysticSmoke.lean" "$REPO/test/PlethysticSmoke.lean"
cp "$ROOT/lean/test/Audit55.lean" "$REPO/test/Audit55.lean"

for imp in \
  'import BusyLean.Plethystic' \
  'import BusyLean.Contender55' \
  'import BusyLean.Comparison55'
do
  grep -qxF "$imp" "$REPO/BusyLean.lean" || echo "$imp" >> "$REPO/BusyLean.lean"
done

cd "$REPO"
lake build BusyLean.Comparison55
lake env lean test/PlethysticSmoke.lean
lake env lean test/Audit55.lean
