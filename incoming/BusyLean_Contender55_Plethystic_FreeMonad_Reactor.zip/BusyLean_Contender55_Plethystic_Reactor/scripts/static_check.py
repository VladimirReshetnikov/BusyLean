#!/usr/bin/env python3
"""Static source, novelty, integration, and packaging audit."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LEAN = ROOT / "lean"
CORE = LEAN / "BusyLean" / "Plethystic.lean"

BANNED_TOKENS = [
    r"\baxiom\b",
    r"\bsorry\b",
    r"\badmit\b",
    r"\bunsafe\b",
    r"\bpartial\b",
    r"\bnoncomputable\b",
    r"Classical\.choice",
    r"native_decide",
]

CORE_FORBIDDEN = [
    "F54",
    "F53",
    "contender_54",
    "LargeElim",
    "largeElim",
    "CTree",
    "Reflection",
    "treeReflect",
    "ladderReflect",
    "PrimLanguage",
    "FiniteIdeals",
]

# Generated or transient files that must not participate in the audit's own
# hash inventory.  Excluding the JSON output avoids a self-referential hash;
# LaTeX auxiliaries, render previews, and Python bytecode are validation
# scratch data rather than package artifacts.
HASH_EXCLUDE_NAMES = {
    "MANIFEST.json",
    "SHA256SUMS.txt",
    "static_check.json",
}
HASH_EXCLUDE_SUFFIXES = {
    ".aux",
    ".fdb_latexmk",
    ".fls",
    ".log",
    ".toc",
    ".pyc",
}


def strip_lean_comments(text: str) -> str:
    text = re.sub(r"/-.*?-/", "", text, flags=re.S)
    text = re.sub(r"--.*", "", text)
    return text


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def main() -> None:
    lean_files = sorted(LEAN.rglob("*.lean"))
    assert lean_files, "no Lean sources"

    findings: list[str] = []
    for path in lean_files:
        clean = strip_lean_comments(path.read_text(encoding="utf-8"))
        for token in BANNED_TOKENS:
            if re.search(token, clean):
                findings.append(f"{path.relative_to(ROOT)}: banned token {token}")

    core_text = strip_lean_comments(CORE.read_text(encoding="utf-8"))
    for token in CORE_FORBIDDEN:
        if token in core_text:
            findings.append(f"Plethystic core unexpectedly references {token}")

    required = {
        "README.md",
        "VALIDATION.md",
        "lean/BusyLean/Plethystic.lean",
        "lean/BusyLean/Contender55.lean",
        "lean/BusyLean/Comparison55.lean",
        "lean/test/PlethysticSmoke.lean",
        "lean/test/Audit55.lean",
        "article/contender55_plethystic_reactor.tex",
        "article/contender55_plethystic_reactor.pdf",
        "baseline/contender54-tiled.patch",
        "patches/contender55.patch",
        "scripts/reference_model.py",
        "scripts/build_overlay.sh",
        "ci/verify-contender55.yml",
    }
    missing = [p for p in sorted(required) if not (ROOT / p).exists()]
    findings.extend(f"missing required file: {p}" for p in missing)

    status = "PASS" if not findings else "FAIL"
    report_lines = [
        f"STATIC AUDIT: {status}",
        f"Lean files checked: {len(lean_files)}",
        f"Banned source tokens: {len(BANNED_TOKENS)}",
        f"Novelty exclusions in core: {len(CORE_FORBIDDEN)}",
        "",
    ]
    if findings:
        report_lines.extend(findings)
    else:
        report_lines.extend(
            [
                "No axiom/sorry/admit/unsafe/partial/noncomputable escape hatch found.",
                "The independent core does not reference the incumbent, reflection,",
                "ordinal trees, program languages, large elimination, or finite ideals.",
                "Required integration and article artifacts are present.",
            ]
        )

    report = "\n".join(report_lines) + "\n"
    print(report, end="")
    (ROOT / "reports" / "static_check.txt").write_text(report, encoding="utf-8")

    def hashable(path: Path) -> bool:
        rel = path.relative_to(ROOT)
        if path.name in HASH_EXCLUDE_NAMES:
            return False
        if path.suffix in HASH_EXCLUDE_SUFFIXES:
            return False
        if "__pycache__" in rel.parts:
            return False
        if rel.parts[:2] == ("reports", "rendered"):
            return False
        if rel == Path("reports/contact_sheet.png"):
            return False
        return path.is_file()

    metadata = {
        "status": status,
        "lean_files": [str(p.relative_to(ROOT)) for p in lean_files],
        "hashes": {
            str(p.relative_to(ROOT)): sha256(p)
            for p in sorted(ROOT.rglob("*"))
            if hashable(p)
        },
        "findings": findings,
    }
    (ROOT / "reports" / "static_check.json").write_text(
        json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    if findings:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
