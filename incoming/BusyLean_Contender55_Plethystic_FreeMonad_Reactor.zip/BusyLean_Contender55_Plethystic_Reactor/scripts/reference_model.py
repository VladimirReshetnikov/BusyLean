#!/usr/bin/env python3
"""Independent executable model for the plethystic reactor.

The implementation deliberately uses ordinary Python tuples/lists rather than
mirroring Lean's recursion clauses line-for-line.  It checks exact small cases,
the polynomial-composition identity, derivative semantics, and the zero-input
reactor calibration.  Full positive inputs are intentionally not expanded: the
intermediate signature itself becomes astronomically large.
"""

from __future__ import annotations

from itertools import product
from pathlib import Path
from typing import Iterable, Sequence

Signature = tuple[int, ...]


def poly_eval(p: Sequence[int], x: int) -> int:
    return sum(pow(x, a) for a in p)


def words(alphabet: Sequence[int], k: int) -> list[tuple[int, ...]]:
    return list(product(alphabet, repeat=k))


def compose(outer: Sequence[int], inner: Sequence[int]) -> Signature:
    return tuple(sum(w) for a in outer for w in words(inner, a))


def derivative(p: Sequence[int]) -> Signature:
    return tuple(a - 1 for a in p for _ in range(a))


def jet(p: Signature, r: int) -> Signature:
    out: list[int] = []
    q = p
    for _ in range(r + 1):
        out.extend(q)
        q = derivative(q)
    return tuple(out)


def iterate(f, k: int, x):
    for _ in range(k):
        x = f(x)
    return x


IDENTITY: Signature = (1,)


def free_step(p: Signature, x: Signature) -> Signature:
    return IDENTITY + compose(p, x)


def free_approx(p: Signature, h: int) -> Signature:
    return iterate(lambda x: free_step(p, x), h, IDENTITY)


def crown(p: Signature, n: int) -> Signature:
    return p + (poly_eval(p, n + 2) + 1,)


def reactor_step(n: int, p: Signature) -> Signature:
    j = jet(p, n + 1)
    return free_approx(crown(j, n), n + 1)


def reactor_seed(n: int) -> Signature:
    return (0, 1, n + 2)


def reactor_state(n: int) -> Signature:
    return iterate(lambda p: reactor_step(n, p), n + 1, reactor_seed(n))


def core_value(n: int) -> int:
    return poly_eval(reactor_state(n), n + 2)


def reactor_value(n: int) -> int:
    return n + 1 + core_value(n)


def formal_derivative_value(p: Sequence[int], x: int) -> int:
    return sum(a * pow(x, a - 1) for a in p if a > 0)


def main() -> None:
    assertions = 0

    assert words((1, 2), 0) == [()]
    assertions += 1
    assert words((1, 2), 2) == [(1, 1), (1, 2), (2, 1), (2, 2)]
    assertions += 1
    assert compose((2,), (1, 3)) == (2, 4, 4, 6)
    assertions += 1
    assert derivative((0, 1, 3)) == (0, 2, 2, 2)
    assertions += 1
    assert free_approx((2,), 2) == (1, 2, 3, 3, 4)
    assertions += 1

    test_signatures: list[Signature] = [
        (),
        (0,),
        (1,),
        (0, 1, 2),
        (2, 2),
        (1, 3),
    ]
    for p in test_signatures:
        for q in test_signatures:
            for x in range(5):
                assert poly_eval(compose(p, q), x) == poly_eval(
                    p, poly_eval(q, x)
                )
                assertions += 1
            assert len(compose(p, q)) == poly_eval(p, len(q))
            assertions += 1

    for p in test_signatures:
        for x in range(1, 6):
            assert poly_eval(derivative(p), x) == formal_derivative_value(p, x)
            assertions += 1

    zero_state = reactor_state(0)
    assert zero_state == (1, 0, 1, 2, 0, 1, 1, 13)
    assertions += 1
    assert core_value(0) == 8206
    assertions += 1
    assert reactor_value(0) == 8207
    assertions += 1

    # Demonstrate why full expansion is not a practical evaluation strategy.
    seed1 = reactor_seed(1)
    jet1 = jet(seed1, 2)
    crown1 = crown(jet1, 1)
    first_free = free_step(crown1, IDENTITY)
    second_stage_shape_count = 1 + poly_eval(crown1, len(first_free))

    lines = [
        "INDEPENDENT REFERENCE MODEL: PASS",
        f"Exact assertions: {assertions}",
        "",
        f"reactorState(0) = {zero_state}",
        f"coreValue(0) = {core_value(0)}",
        f"reactorValue(0) = {reactor_value(0)}",
        "",
        "Polynomial identities checked on a finite test grid:",
        "  eval(P∘Q, x) = eval(P, eval(Q, x))",
        "  shapes(P∘Q)  = eval(P, shapes(Q))",
        "  eval(P', x)  = d/dx eval(P, x)",
        "",
        "Positive-input expansion diagnostic:",
        f"  seed(1) arities = {seed1}",
        f"  jet(seed(1),2) has {len(jet1)} operations",
        f"  crown arity = {crown1[-1]}",
        f"  first free stage has {len(first_free)} operations",
        "  second free stage would have",
        f"    {second_stage_shape_count}",
        "  operations before the outer reactor has completed even one step.",
        "",
        "The program refuses to materialize that list; the Lean definition remains",
        "a finite structural computation and therefore denotes a computable natural.",
    ]
    report = "\n".join(lines) + "\n"
    print(report, end="")

    out = Path(__file__).resolve().parents[1] / "reports" / "reference_model.txt"
    out.write_text(report, encoding="utf-8")


if __name__ == "__main__":
    main()
