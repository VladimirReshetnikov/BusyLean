import Std

/-!
# Finite plethystic container reactor

A finite polynomial container is represented by the list of arities of its
operations.  The list `[a₁, ..., aₖ]` denotes the polynomial

  X ↦ X^a₁ + ... + X^aₖ.

The central operation is container substitution (`compose`).  It keeps the
full arity spectrum rather than only its cardinality: for every outer
operation of arity `a`, choose one inner operation for each of its `a`
positions and add the chosen arities.

The reactor combines four finite operations:

* formal derivative (`derivative`), marking one input position;
* a finite jet (`jet`), retaining all derivatives through a given order;
* a crown operation, adding one operation whose arity is the current
  polynomial's value at a calibration point;
* a finite free-monad approximation (`freeApprox`), repeatedly adjoining the
  variable and substituting the signature into the current term signature.

Every recursion is structural on a natural number or finite list.  The module
is independent of BusyLean's reflection, ordinal-tree, program-language,
large-elimination, and finite-ideal machinery.
-/

namespace BusyLean
namespace Plethystic

/-- A finite nonsymmetric polynomial signature, represented by operation
arities with multiplicity. -/
abbrev Signature := List Nat

/-- Sum of a finite list of naturals. -/
def sumNat : List Nat → Nat
  | [] => 0
  | x :: xs => x + sumNat xs

/-- Repeat `x` exactly `k` times. -/
def repeatNat (x : Nat) : Nat → List Nat
  | 0 => []
  | k + 1 => x :: repeatNat x k

/-- All words of length `k` over a finite alphabet. -/
def words (alphabet : List Nat) : Nat → List (List Nat)
  | 0 => [[]]
  | k + 1 =>
      (words alphabet k).flatMap fun tail =>
        alphabet.map fun head => head :: tail

/-- Evaluate the polynomial represented by a finite arity signature. -/
def polyEval : Signature → Nat → Nat
  | [], _ => 0
  | a :: as, x => x ^ a + polyEval as x

/-- Plethystic/container composition.

For an outer arity `a`, a composite operation chooses `a` inner operations;
its arity is the sum of their arities. -/
def compose (outer inner : Signature) : Signature :=
  outer.flatMap fun a => (words inner a).map sumNat

/-- One formal derivative: an operation of arity `a` gives `a` pointed
operations of arity `a-1`. -/
def derivative (p : Signature) : Signature :=
  p.flatMap fun a => repeatNat (a - 1) a

/-- The finite jet `p + p' + ... + p^(r)`. -/
def jet : Signature → Nat → Signature
  | p, 0 => p
  | p, r + 1 => p ++ jet (derivative p) r

/-- Generic finite iteration at an arbitrary type. -/
def iterate {α : Type} (f : α → α) : Nat → α → α
  | 0, x => x
  | k + 1, x => iterate f k (f x)

/-- The identity container, representing one variable. -/
def identity : Signature := [1]

/-- One stage in the free-monad/tree-term approximation: `X + P(X)`. -/
def freeStep (p x : Signature) : Signature := identity ++ compose p x

/-- Terms over `p` of height at most `h`, retaining their leaf arities. -/
def freeApprox (p : Signature) (h : Nat) : Signature :=
  iterate (freeStep p) h identity

/-- Add one operation whose arity is determined by the current finite
signature itself. -/
def crown (p : Signature) (n : Nat) : Signature :=
  p ++ [polyEval p (n + 2) + 1]

/-- One self-indexed plethystic reactor step.

The jet exposes all pointed contexts through order `n+1`; the crown feeds the
current population back as a new arity; and `n+1` free-monad stages close the
result under bounded tree substitution. -/
def reactorStep (n : Nat) (p : Signature) : Signature :=
  let j := jet p (n + 1)
  let c := crown j n
  freeApprox c (n + 1)

/-- Initial signature: a nullary constant, the variable, and one `(n+2)`-ary
operation. -/
def reactorSeed (n : Nat) : Signature := [0, 1, n + 2]

/-- Iterate the whole reactor `n+1` times. -/
def reactorState (n : Nat) : Signature :=
  iterate (reactorStep n) (n + 1) (reactorSeed n)

/-- The autonomous combinatorial payload: evaluate the final signature's
polynomial at `n+2`. -/
def coreValue (n : Nat) : Nat :=
  polyEval (reactorState n) (n + 2)

/-- A certificate-carrying reactor value.  The additive prefix gives a tiny,
transparent proof of strict progress; essentially all magnitude is in
`coreValue n`. -/
def reactorValue (n : Nat) : Nat := n + Nat.succ (coreValue n)

/-- The reactor is pointwise strictly inflationary. -/
theorem input_lt_reactorValue (n : Nat) : n < reactorValue n := by
  unfold reactorValue
  exact Nat.lt_add_of_pos_right (Nat.zero_lt_succ _)

/-- Iteration of any pointwise inflationary map never decreases its input. -/
theorem le_iterate_of_progressive (f : Nat → Nat)
    (h : ∀ x, x ≤ f x) : ∀ k x, x ≤ iterate f k x
  | 0, x => Nat.le_refl x
  | k + 1, x => Nat.le_trans (h x)
      (le_iterate_of_progressive f h k (f x))

/-- A positive finite orbit of a strictly inflationary map is strictly above
its starting point. -/
theorem lt_iterate_succ_of_progressive (f : Nat → Nat)
    (h : ∀ x, x < f x) (k x : Nat) : x < iterate f (k + 1) x := by
  change x < iterate f k (f x)
  exact Nat.lt_of_lt_of_le (h x)
    (le_iterate_of_progressive f (fun y => Nat.le_of_lt (h y)) k (f x))

/-- Every positive reactor orbit strictly exceeds its starting point. -/
theorem input_lt_reactorOrbit (k n : Nat) :
    n < iterate reactorValue (k + 1) n :=
  lt_iterate_succ_of_progressive reactorValue input_lt_reactorValue k n

/-- A small exact calibration of the mechanism-level payload. -/
@[simp] theorem coreValue_zero : coreValue 0 = 8206 := rfl

/-- The corresponding certificate-carrying value. -/
@[simp] theorem reactorValue_zero : reactorValue 0 = 8207 := rfl

end Plethystic
end BusyLean
