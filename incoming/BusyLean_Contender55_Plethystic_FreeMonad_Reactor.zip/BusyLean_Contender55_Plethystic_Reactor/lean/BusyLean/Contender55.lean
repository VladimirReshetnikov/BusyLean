import BusyLean.Plethystic
import BusyLean.Contender54

/-!
# Contender 55: the self-indexed plethystic free-monad reactor

This module is an adapter over the Contender 54 API.  It is compatible with
either pending Contender 54 implementation because both expose `F54` and
`contender_54` with the same convention.

```
family54 n   := F54 (F54 n)
N            := family54 n
F55 n        := reactorValue^[N+1](N)
contender_55 := F55 (F55 42)
```

The old family supplies only the numerical seed and finite iteration budget.
Every one of the `N+1` growth steps is the new `Plethystic.reactorValue`, based
on finite polynomial containers, plethystic substitution, formal derivatives,
arity feedback, and free-monad closure.  No old-family iterate occurs in the
definition.

**Do not evaluate `contender_55`.**
-/

namespace BusyLean

/-- Contender 54 as an input-indexed family.  At input 42 this is
definitionally `contender_54`. -/
def family54 (n : Nat) : Nat := F54 (F54 n)

/-- The Contender 55 family: `family54 n + 1` iterations of the new reactor,
starting from `family54 n`. -/
def F55 (n : Nat) : Nat :=
  let N := family54 n
  Plethystic.iterate Plethystic.reactorValue (N + 1) N

/-- **Contender 55: Self-Indexed Plethystic Free-Monad Reactor.** -/
def contender_55 : Nat := F55 (F55 42)

end BusyLean
