import BusyLean.Contender55
import BusyLean.Comparison54

/-! # Contender 55: comparison theorems -/

namespace BusyLean

/-- The twice-composed Contender 54 family is strictly inflationary. -/
theorem input_lt_family54 (n : Nat) : n < family54 n :=
  Nat.lt_trans (input_lt_F54 n) (input_lt_F54 (F54 n))

/-- At every input, a positive orbit of the new reactor exceeds its old-family
seed. -/
theorem family54_lt_F55 (n : Nat) : family54 n < F55 n := by
  unfold F55
  exact Plethystic.input_lt_reactorOrbit (family54 n) (family54 n)

/-- `F55` is strictly inflationary. -/
theorem input_lt_F55 (n : Nat) : n < F55 n :=
  Nat.lt_trans (input_lt_family54 n) (family54_lt_F55 n)

/-- The full independent reactor orbit started at `contender_54`, with
`contender_54 + 1` steps, lies strictly below `contender_55`. -/
theorem reactor_orbit_contender_54_lt_contender_55 :
    Plethystic.iterate Plethystic.reactorValue
      (contender_54 + 1) contender_54 < contender_55 := by
  calc
    Plethystic.iterate Plethystic.reactorValue
        (contender_54 + 1) contender_54 = F55 42 := rfl
    _ < F55 (F55 42) := input_lt_F55 (F55 42)
    _ = contender_55 := rfl

/-- **The required strict comparison.** -/
theorem contender_54_lt_contender_55 : contender_54 < contender_55 := by
  calc
    contender_54 = family54 42 := rfl
    _ < F55 42 := family54_lt_F55 42
    _ < F55 (F55 42) := input_lt_F55 (F55 42)
    _ = contender_55 := rfl

/-- Every earlier integrated contender is therefore smaller as well. -/
theorem contender_53_lt_contender_55 : contender_53 < contender_55 :=
  Nat.lt_trans contender_53_lt_contender_54 contender_54_lt_contender_55

end BusyLean
