import BusyLean.Comparison55

#print axioms BusyLean.Plethystic.coreValue
#print axioms BusyLean.Plethystic.reactorValue
#print axioms BusyLean.contender_55
#print axioms BusyLean.contender_54_lt_contender_55
#print axioms BusyLean.reactor_orbit_contender_54_lt_contender_55
