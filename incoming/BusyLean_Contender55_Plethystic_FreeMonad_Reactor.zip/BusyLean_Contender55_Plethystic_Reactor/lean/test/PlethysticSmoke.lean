import BusyLean.Comparison55

namespace BusyLean
namespace Plethystic

example : words [1, 2] 0 = [[]] := rfl
example : words [1, 2] 1 = [[1], [2]] := rfl
example : compose [2] [1, 3] = [2, 4, 4, 6] := rfl
example : derivative [0, 1, 3] = [0, 2, 2, 2] := rfl
example : freeApprox [2] 2 = [1, 2, 3, 3, 4] := rfl
example : coreValue 0 = 8206 := rfl
example : reactorValue 0 = 8207 := rfl

#check input_lt_reactorValue
#check input_lt_reactorOrbit
#check BusyLean.contender_54_lt_contender_55
#check BusyLean.reactor_orbit_contender_54_lt_contender_55

end Plethystic
end BusyLean
