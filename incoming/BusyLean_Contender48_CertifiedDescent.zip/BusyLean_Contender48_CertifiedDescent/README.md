# BusyLean Contender 48 proposal: Certified-Descent Program Envelope

Target repository: `VladimirReshetnikov/BusyLean`

Target commit: `4fe2f34c66324cc2f1c4f343d6c82d09915a6643`

Baseline at that commit: Contender 47, “iterating the self-based iteration.”

## Construction

The proposal introduces a finite universal programming model whose mutually
recursive calls are accepted only through the semantics of a supplied
well-founded `CTree`.  At a successor, every call moves to the unique child; at
a limit, a computed branch selects a child.  Clause selection, branch selection,
and recursive arguments are dynamic.  The interpreter is nevertheless a plain
structural recursion on the certificate tree.

At input `n`:

```text
family47 n      = F47 (F47 n)
certificate48 n = psiTree (family47 n)
envelope48 n    = maximum output of every bounded certified-descent program
F48 n           = 1 + max (family47 n) (envelope48 n)
contender_48    = F48 (F48 42)
```

The finite envelope contains two explicit witnesses before the exhaustive
enumeration:

1. an oracle-iteration program, proving that `F48 n` exceeds `family47`
   iterated `family47 n` times from `family47 n`;
2. a certificate-using accelerator that composes recursive computations down
   Contender 47's iterated-iteration tree.

The construction is computable in principle.  It does not use a halting oracle,
Busy Beaver, `noncomputable`, `partial`, `unsafe`, custom axioms, or the previous
contender constant in its definition.

## Contents

- `article/contender48_certified_descent.tex` - research article source.
- `article/contender48_certified_descent.pdf` - compiled article.
- `lean/BusyLean/CertifiedDescent.lean` - program language, total interpreter,
  enumeration, envelope, and majorization theorems.
- `lean/BusyLean/Contender48.lean` - number definition.
- `lean/BusyLean/Comparison48.lean` - comparison and lower-bound theorems.
- `lean/test/Contender48Smoke.lean` - tiny definitional tests; no contender is
  evaluated.
- `lean/test/Audit48.lean` - proposed axiom audit.
- `patches/integration.patch` - integration changes for the pinned repository.
- `patches/README_INSERT.md` - proposed current-contender README section.
- `scripts/reference_model.py` - independent executable small-instance model.
- `scripts/static_check.py` - archive hygiene and reference-model checks.
- `VALIDATION_REPORT.md` - exact validation status and limitations.
- `BASELINE.md` - pinned repository facts used by the proposal.

## Reproduction in a BusyLean checkout

1. Check out the target commit.
2. Copy `lean/BusyLean/*.lean` into the repository's `BusyLean/` directory.
3. Copy `lean/test/*.lean` into `test/`.
4. Apply `patches/integration.patch` from the repository root.
5. Run:

```bash
lake build BusyLean.Contender48
lake build BusyLean.Comparison48
lake env lean test/Contender48Smoke.lean
lake env lean test/Audit48.lean
python3 scripts/check.py
```

The pinned toolchain is Lean 4.34.0.

## Validation status

The TeX article was compiled and the PDF was rendered and visually inspected.
The Python reference model and static checks pass.  This execution environment
does not contain Lean, Lake, or Elan, so the Lean files have **not** been
kernel-replayed here.  No claim of CI or kernel validation is made; see
`VALIDATION_REPORT.md`.
