import BusyLean.Comparison48

/-! Small executable equations only.  This file never evaluates a contender. -/

namespace BusyLean.CertifiedDescentSmoke

open BusyLean
open BusyLean.Ordinal
open BusyLean.CertifiedDescent

/-- A finite unary certificate. -/
def chain : Nat → CTree
  | 0 => .zero
  | n + 1 => .succ (chain n)

/-- A countable limit certificate whose branch `i` is a chain of length `i`. -/
def omegaTree : CTree := .lim chain

def plusOne (n : Nat) : Nat := n + 1

example : value (orbitProgram 3) plusOne (chain 7) 4 = 7 := by
  rfl

example : value (descentProgram 3) plusOne .zero 4 = 5 := by
  rfl

example : value (descentProgram 3) plusOne (chain 1) 4 = 8 := by
  rfl

/-- Dynamic mutual dispatch: clause zero calls clause one at the child. -/
def mutualProgram : Program :=
  [.call (.lit 1) (.lit 0) (.add (.var 0) (.lit 1)),
   .add (.var 0) (.lit 10)]

example : value mutualProgram plusOne (chain 1) 3 = 14 := by
  rfl

example : orbit plusOne 5 9 = 14 := by
  rfl

end BusyLean.CertifiedDescentSmoke
