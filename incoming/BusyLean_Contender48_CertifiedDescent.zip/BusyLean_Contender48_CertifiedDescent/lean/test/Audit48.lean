import BusyLean.Comparison48

/-! Run with `lake env lean test/Audit48.lean` after overlaying the proposal. -/

#print axioms BusyLean.CertifiedDescent.run
#print axioms BusyLean.CertifiedDescent.value_orbitProgram
#print axioms BusyLean.CertifiedDescent.program_le_envelope
#print axioms BusyLean.CertifiedDescent.orbit_le_envelope
#print axioms BusyLean.CertifiedDescent.descent_le_envelope
#print axioms BusyLean.contender_48
#print axioms BusyLean.family47_lt_F48
#print axioms BusyLean.envelope48_lt_F48
#print axioms BusyLean.certified_program_lt_F48
#print axioms BusyLean.orbit47_lt_F48
#print axioms BusyLean.descent48_lt_F48
#print axioms BusyLean.contender_47_lt_contender_48
