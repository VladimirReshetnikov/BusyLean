import BusyLean.Contender48
import BusyLean.Comparison47

/-! # Contender 48: comparison and universal-majorant theorems -/

namespace BusyLean

/-- Contender 47's family is inflationary. -/
theorem input_lt_family47 (n : Nat) : n < family47 n :=
  Nat.lt_trans (input_lt_F47 n) (input_lt_F47 (F47 n))

/-- The new family strictly exceeds the whole previous family pointwise. -/
theorem family47_lt_F48 (n : Nat) : family47 n < F48 n :=
  Nat.lt_succ_of_le (BigNumber.le_maxN_left _ _)

/-- The certified-descent envelope is strictly below the guarded successor. -/
theorem envelope48_lt_F48 (n : Nat) : envelope48 n < F48 n :=
  Nat.lt_succ_of_le (BigNumber.le_maxN_right _ _)

/-- Every bounded certified-descent program is strictly below `F48`. -/
theorem certified_program_lt_F48 {n : Nat}
    {program : CertifiedDescent.Program}
    (hprogram : program ∈ CertifiedDescent.programsAt (family47 n)) :
    CertifiedDescent.value program family47 (certificate48 n) (family47 n) <
      F48 n :=
  Nat.lt_of_le_of_lt
    (CertifiedDescent.program_le_envelope family47 (certificate48 n)
      (family47 n) (family47 n) hprogram)
    (envelope48_lt_F48 n)

/-- A concrete large lower bound: `F48 n` exceeds `family47` iterated
`family47 n` times, beginning at `family47 n`. -/
theorem orbit47_lt_F48 (n : Nat) :
    CertifiedDescent.orbit family47 (family47 n) (family47 n) < F48 n :=
  Nat.lt_of_le_of_lt
    (CertifiedDescent.orbit_le_envelope family47 (certificate48 n)
      (family47 n) (family47 n))
    (envelope48_lt_F48 n)

/-- The canonical certificate-using accelerator is strictly below `F48`. -/
theorem descent48_lt_F48 (n : Nat) :
    CertifiedDescent.value
      (CertifiedDescent.descentProgram (family47 n))
      family47 (certificate48 n) (family47 n) < F48 n :=
  Nat.lt_of_le_of_lt
    (CertifiedDescent.descent_le_envelope family47 (certificate48 n)
      (family47 n) (family47 n))
    (envelope48_lt_F48 n)

/-- The new family is itself inflationary. -/
theorem input_lt_F48 (n : Nat) : n < F48 n :=
  Nat.lt_trans (input_lt_family47 n) (family47_lt_F48 n)

/-- **The required comparison:** Contender 47 is strictly smaller. -/
theorem contender_47_lt_contender_48 : contender_47 < contender_48 :=
  Nat.lt_trans (family47_lt_F48 42) (input_lt_F48 (F48 42))

/-- The current proposal also inherits the complete strict comparison chain. -/
theorem contender_46_lt_contender_48 : contender_46 < contender_48 :=
  Nat.lt_trans contender_46_lt_contender_47
    contender_47_lt_contender_48

end BusyLean
