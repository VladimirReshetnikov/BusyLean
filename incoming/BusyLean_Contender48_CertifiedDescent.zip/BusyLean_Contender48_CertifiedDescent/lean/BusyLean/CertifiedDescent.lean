import BusyLean.Contender47
import BigNumber.Proofs

/-!
# Certified-descent programs

A program is a finite list of mutually recursive clauses.  Besides ordinary
arithmetic and primitive recursion on naturals, a clause may call another
clause.  The interpreter does not run such a call at the same rank: it moves to
a strict child of a supplied `CTree`.  Consequently every program is total by
structural recursion on the certificate tree, even when its call graph is
cyclic and the selected clause, branch, and argument are computed at run time.

This file contains only constructive definitions.  It does not evaluate any
BusyLean contender.
-/

namespace BusyLean.CertifiedDescent

open BusyLean.Ordinal

/-- Expressions for a finite mutually recursive certified-descent program. -/
inductive Code where
  | lit (k : Nat)
  | var (i : Nat)
  | oracle (arg : Code)
  | call (clause branch arg : Code)
  | add (left right : Code)
  | mul (left right : Code)
  | max (left right : Code)
  | ifZero (test yes no : Code)
  | let1 (value body : Code)
  | nrec (count zero step : Code)
  deriving DecidableEq

/-- Clause zero is the entry point. -/
abbrev Program := List Code

/-- Head-based environment lookup, with zero as the total default. -/
def lookup : List Nat → Nat → Nat
  | [], _ => 0
  | x :: _, 0 => x
  | _ :: xs, i + 1 => lookup xs i

/-- Total selection of a clause. -/
def bodyAt : Program → Nat → Code
  | [], _ => .lit 0
  | c :: _, 0 => c
  | _ :: cs, i + 1 => bodyAt cs i

/-- Evaluate one expression relative to an oracle and a recursive-call handler.

For `nrec count zero step`, the step environment begins with the predecessor
index and accumulator, followed by the old environment.  Thus variables zero
and one denote the index and accumulator, respectively.
-/
def eval (g : Nat → Nat) (recur : Nat → Nat → Nat → Nat)
    (env : List Nat) : Code → Nat
  | .lit k => k
  | .var i => lookup env i
  | .oracle arg => g (eval g recur env arg)
  | .call clause branch arg =>
      recur (eval g recur env clause) (eval g recur env branch)
        (eval g recur env arg)
  | .add left right => eval g recur env left + eval g recur env right
  | .mul left right => eval g recur env left * eval g recur env right
  | .max left right => Nat.max (eval g recur env left) (eval g recur env right)
  | .ifZero test yes no =>
      if eval g recur env test = 0 then eval g recur env yes
      else eval g recur env no
  | .let1 value body => eval g recur (eval g recur env value :: env) body
  | .nrec count zero step =>
      Nat.rec (eval g recur env zero)
        (fun i acc => eval g recur (i :: acc :: env) step)
        (eval g recur env count)
termination_by structural code => code

/-- Interpret a program over a well-founded certificate tree.

At a successor every call moves to the unique child.  At a limit the program's
computed branch selects a child.  At zero and the two higher-supremum constructors
with empty branch index types, recursive calls return zero.  The definition is accepted by
structural recursion on the tree, so termination is part of its kernel term.
-/
def run (program : Program) (g : Nat → Nat) : CTree → Nat → List Nat → Nat
  | .zero, clause, env =>
      eval g (fun _ _ _ => 0) env (bodyAt program clause)
  | .succ child, clause, env =>
      eval g (fun next _ arg => run program g child next (arg :: env))
        env (bodyAt program clause)
  | .lim children, clause, env =>
      eval g (fun next branch arg =>
        run program g (children branch) next (arg :: env))
        env (bodyAt program clause)
  | .supL _, clause, env =>
      eval g (fun _ _ _ => 0) env (bodyAt program clause)
  | .supH _, clause, env =>
      eval g (fun _ _ _ => 0) env (bodyAt program clause)
termination_by structural tree => tree

/-- Run clause zero with a one-cell input environment. -/
def value (program : Program) (g : Nat → Nat) (tree : CTree) (input : Nat) : Nat :=
  run program g tree 0 [input]

/-- Forward iteration of an arbitrary total function. -/
def orbit (g : Nat → Nat) (fuel input : Nat) : Nat :=
  Nat.rec input (fun _ acc => g acc) fuel

/-- A compact program that iterates the oracle `fuel` times on its input. -/
def orbitCode (fuel : Nat) : Code :=
  .nrec (.lit fuel) (.var 0) (.oracle (.var 1))

/-- The one-clause oracle-iteration program. -/
def orbitProgram (fuel : Nat) : Program := [orbitCode fuel]

/-- A canonical certificate-using accelerator.

Starting from `g(input)`, it performs `fuel` recursive calls.  Call number `i`
chooses branch `i`, sends the current accumulator to clause zero, and retains at
least `g(input)`.  On a successor this iterates the child computation; on a
limit it composes computations from the first `fuel` branches.
-/
def descentCode (fuel : Nat) : Code :=
  .nrec (.lit fuel) (.oracle (.var 0))
    (.max (.oracle (.var 2))
      (.call (.lit 0) (.var 0) (.var 1)))

/-- The canonical one-clause certificate-using program. -/
def descentProgram (fuel : Nat) : Program := [descentCode fuel]

/-- All expression trees of construction depth at most `n` (with duplication). -/
def codesUpTo : Nat → List Code
  | 0 => []
  | n + 1 =>
      let es := codesUpTo n
      let pairs := BigNumber.cross es es
      let triples := BigNumber.cross pairs es
      (BigNumber.natsUpTo (n + 1)).map Code.lit ++
      (BigNumber.natsUpTo (n + 1)).map Code.var ++
      es.map Code.oracle ++
      triples.map (fun p => Code.call p.1.1 p.1.2 p.2) ++
      pairs.map (fun p => Code.add p.1 p.2) ++
      pairs.map (fun p => Code.mul p.1 p.2) ++
      pairs.map (fun p => Code.max p.1 p.2) ++
      triples.map (fun p => Code.ifZero p.1.1 p.1.2 p.2) ++
      pairs.map (fun p => Code.let1 p.1 p.2) ++
      triples.map (fun p => Code.nrec p.1.1 p.1.2 p.2)

/-- Programs of length at most `n` over a fixed finite alphabet. -/
def programsUpTo (alphabet : List Code) : Nat → List Program
  | 0 => [[]]
  | n + 1 =>
      let programs := programsUpTo alphabet n
      programs ++ (BigNumber.cross alphabet programs).map
        (fun p => p.1 :: p.2)

/-- The two canonical witnesses followed by the exhaustive finite enumeration. -/
def programsAt (fuel : Nat) : List Program :=
  orbitProgram fuel :: descentProgram fuel ::
    programsUpTo (codesUpTo fuel) fuel

/-- The certified-descent envelope at a finite syntax budget. -/
def envelope (g : Nat → Nat) (tree : CTree) (fuel input : Nat) : Nat :=
  BigNumber.maximum (fun program => value program g tree input)
    (programsAt fuel)

/-- The compact oracle-iteration program has the advertised semantics. -/
theorem eval_orbitCode (g : Nat → Nat)
    (recur : Nat → Nat → Nat → Nat) (env : List Nat) (fuel : Nat) :
    eval g recur env (orbitCode fuel) = orbit g fuel (lookup env 0) := by
  rfl

/-- The tree is irrelevant to a program that makes no recursive calls. -/
theorem value_orbitProgram (g : Nat → Nat) (tree : CTree)
    (fuel input : Nat) :
    value (orbitProgram fuel) g tree input = orbit g fuel input := by
  cases tree <;> rfl

/-- A member's score is bounded by the finite maximum. -/
theorem le_maximum_of_mem {α : Type} (score : α → Nat) :
    ∀ {x : α} {xs : List α}, x ∈ xs →
      score x ≤ BigNumber.maximum score xs := by
  intro x xs hx
  induction xs with
  | nil => cases hx
  | cons y ys ih =>
      have h : x = y ∨ x ∈ ys := List.mem_cons.mp hx
      cases h with
      | inl hxy =>
          subst x
          exact BigNumber.le_maxN_left _ _
      | inr hmem =>
          exact Nat.le_trans (ih hmem) (BigNumber.le_maxN_right _ _)

/-- Every enumerated program is bounded by the envelope. -/
theorem program_le_envelope (g : Nat → Nat) (tree : CTree)
    (fuel input : Nat) {program : Program}
    (hprogram : program ∈ programsAt fuel) :
    value program g tree input ≤ envelope g tree fuel input :=
  le_maximum_of_mem _ hprogram

/-- The envelope already dominates a `fuel`-fold iterate of its oracle. -/
theorem orbit_le_envelope (g : Nat → Nat) (tree : CTree)
    (fuel input : Nat) :
    orbit g fuel input ≤ envelope g tree fuel input := by
  have hprogram : orbitProgram fuel ∈ programsAt fuel := by
    simp [programsAt]
  have h := program_le_envelope g tree fuel input hprogram
  simpa only [value_orbitProgram] using h

/-- The canonical tree-using accelerator is also part of the envelope. -/
theorem descent_le_envelope (g : Nat → Nat) (tree : CTree)
    (fuel input : Nat) :
    value (descentProgram fuel) g tree input ≤
      envelope g tree fuel input := by
  apply program_le_envelope
  simp [programsAt]

end BusyLean.CertifiedDescent
