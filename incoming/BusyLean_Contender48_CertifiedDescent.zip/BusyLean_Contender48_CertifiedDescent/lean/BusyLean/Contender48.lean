import BusyLean.CertifiedDescent

/-!
# Contender 48: the certified-descent program envelope

```
family47 n      := F47 (F47 n)
certificate48 n := psiTree (family47 n)
envelope48 n    := maximum value of every bounded certified-descent program
F48 n           := succ (max (family47 n) (envelope48 n))
contender_48    := F48 (F48 42)
```

The new operation is not another tree-language layer.  The tree is a totality
certificate for an enumerated universe of finite mutually recursive programs.
Every dynamic recursive call must move to a strict child, so the interpreter is
structurally total.  The finite maximum therefore has Busy-Beaver-like flavor
without an undecidable halting predicate.

**Do not evaluate `contender_48`.**
-/

namespace BusyLean

open BusyLean.Ordinal

/-- Contender 47's construction as a function of its input.
`family47 42` is definitionally the previous entry. -/
def family47 (n : Nat) : Nat := F47 (F47 n)

/-- Contender 47's iterated-iteration tree, now used as a descent-certificate
    object. -/
def certificate48 (n : Nat) : CTree := psiTree (family47 n)

/-- Universal finite maximum of certified-descent computations at the
self-generated budget, input, and certificate. -/
def envelope48 (n : Nat) : Nat :=
  CertifiedDescent.envelope family47 (certificate48 n)
    (family47 n) (family47 n)

/-- Contender 48's pointwise family. -/
def F48 (n : Nat) : Nat :=
  Nat.succ (BigNumber.maxN (family47 n) (envelope48 n))

/-- **Contender 48.**  Never evaluate it. -/
def contender_48 : Nat := F48 (F48 42)

end BusyLean
