# Strength notes and open problems

## What is rigorously gained

The proposal does more than append a successor to the old entry.  The bound
`orbit47_lt_F48` makes the gap explicit:

```text
orbit family47 (family47 n) (family47 n) < F48 n.
```

Thus even the first canonical program in the envelope iterates the entire
Contender 47 family a Contender-47-sized number of times.  The second canonical
program additionally uses the full iterated-iteration `psiTree` as a descent certificate.
Finally, `certified_program_lt_F48` majorizes every program in the finite
bounded universe, not just these witnesses.

## Why it is not a forbidden Busy Beaver

The usual Busy Beaver maximum ranges over machines whose halting is undecidable.
Here the semantic interface itself enforces totality.  A recursive call cannot
remain at the current rank: it is interpreted only at a strict child of a
well-founded tree.  The maximum is over a finite, decidable syntax list, and
all values are produced by a total Lean function.

## Relation to existing BusyLean mechanisms

Contender 47 turns the self-based iteration itself into a parameterized
operator and then iterates that operator along `univTree46`, producing
`psiTree`.  The certified-descent envelope instead enumerates recursion
schemes and uses `psiTree` as evidence that their dynamic call graphs terminate.  This is a change from "programs produce
indices" to "indices certify whole programs."

The distinction is conceptual and formally visible in the universal-majorant
theorem.  It is not yet a non-interpretability result: System FT2 or FLT2 may be
able to encode substantial fragments of the machine.

## High-value follow-up questions

1. Formalize an interpreter from the certified-descent language into System
   FT2 and determine the exact overhead, or prove that a natural bounded
   fragment cannot preserve the envelope.
2. Replace the single tree certificate by a lexicographic or multiset of trees,
   formalizing a genuine size-change termination certificate.
3. Enumerate certificate transformers together with programs, while retaining
   a structurally recursive checker.
4. Add higher-type closures or continuations and prove a normalization theorem
   for the resulting certificate-governed language.
5. Establish an ordinal or provably-total-function calibration for the
   canonical descent accelerator.
6. Mechanize a source-to-source compiler from general mutually recursive
   equations with an explicit ranking proof into the present core.
7. Prove a subterm or simulation theorem showing that the envelope subsumes
   the fixed `hier` construction on the same tree.
