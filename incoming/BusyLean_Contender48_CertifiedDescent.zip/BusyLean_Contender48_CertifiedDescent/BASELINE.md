# Pinned baseline

The proposal was designed against BusyLean commit
`4fe2f34c66324cc2f1c4f343d6c82d09915a6643` (2026-10-13).

At that commit the repository's current entry is Contender 47:

```lean
def family46 (n : Nat) : Nat := F46 (F46 n)

def thetaFrom (N : Nat) (B : Ordinal.CTree → Ordinal.CTree) :
    Ordinal.CTree → Ordinal.CTree → Ordinal.CTree
  | .zero => B
  | .succ a => fun t => Ordinal.metaBoostC (closeU N) t
      (thetaFrom N B a) t
  | .lim f => fun t => .lim fun i => thetaFrom N B (f i) t
  | .supL _ => B
  | .supH _ => B

def psi (N : Nat) : Ordinal.CTree → Ordinal.CTree → Ordinal.CTree
  | .zero => metaJump N
  | .succ a => fun t => thetaFrom N (psi N a) t t
  | .lim f => fun t => .lim fun i => psi N (f i) t
  | .supL _ => metaJump N
  | .supH _ => metaJump N

def psiTree (N : Nat) : Ordinal.CTree :=
  .lim fun i => if i = 0 then univTree46 N
    else psi N (univTree46 N) (univTree46 N)

def F47 (n : Nat) : Nat :=
  Ordinal.hier family46 (psiTree (family46 n)) (family46 n)

def contender_47 : Nat := F47 (F47 42)
```

The repository proves `contender_46_lt_contender_47`. Its rules require a
closed computable `Nat`, prohibit noncomputable escape hatches, permit only
`propext` and `Quot.sound`, prohibit direct use of the previous contender
constant in the new definition, and set separate 15-second definition and
60-second proof budgets on Lean 4.34.0.

Contender 47 parameterizes Contender 45's self-based iteration by an arbitrary
base operator (`thetaFrom`), then iterates that entire operator construction
again (`psi`) along Contender 46's `univTree46`. The resulting `psiTree` is the
current strongest tree and is consumed by the fixed hierarchy over
`family46`.

A further design constraint is the repository's correction that a bounded
ladder sees only a finite truncation of an atom order. The present proposal
does not claim strength merely from a taller atom order. It gives the actual
`psiTree` a different semantic role: a structural termination certificate for
a universal finite program envelope.
