## Proposed current contender: Contender 48

```lean
def family47 (n : Nat) : Nat := F47 (F47 n)
def certificate48 (n : Nat) : CTree := psiTree (family47 n)
def envelope48 (n : Nat) : Nat :=
  CertifiedDescent.envelope family47 (certificate48 n)
    (family47 n) (family47 n)
def F48 (n : Nat) : Nat :=
  Nat.succ (BigNumber.maxN (family47 n) (envelope48 n))
def contender_48 : Nat := F48 (F48 42)

theorem contender_47_lt_contender_48 : contender_47 < contender_48
```

`CertifiedDescent` is a finite universal language of mutually recursive
programs.  Clause, branch, and argument selection are computed at runtime, but
every recursive call is interpreted at a strict child of a supplied `CTree`.
The interpreter is therefore structurally total.  `envelope48` takes the
maximum output of every program at the self-generated syntax budget over
Contender 47's iterated-iteration tree.

The explicit theorem `orbit47_lt_F48` shows that `F48 n` exceeds `family47`
iterated `family47 n` times from `family47 n`; `certified_program_lt_F48`
majorizes every enumerated certified-descent program.
