#!/usr/bin/env python3
"""Executable small-instance model of the certified-descent interpreter.

This is not a substitute for Lean kernel checking.  It is an independent
semantic smoke test for the equations used in the proposal.  It intentionally
uses tiny budgets and never constructs or evaluates a BusyLean contender.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable, Sequence, Tuple


# ---------------------------------------------------------------------------
# Countable well-founded trees used only at tiny finite examples here.


class Tree:
    pass


@dataclass(frozen=True)
class Zero(Tree):
    pass


@dataclass(frozen=True)
class Succ(Tree):
    child: Tree


@dataclass(frozen=True)
class Lim(Tree):
    child: Callable[[int], Tree]


ZERO = Zero()


def chain(n: int) -> Tree:
    if n < 0:
        raise ValueError("chain length must be nonnegative")
    t: Tree = ZERO
    for _ in range(n):
        t = Succ(t)
    return t


# ---------------------------------------------------------------------------
# Codes.  A tuple's first component is the constructor tag.

Code = Tuple
Program = Tuple[Code, ...]


def lit(k: int) -> Code:
    return ("lit", k)


def var(i: int) -> Code:
    return ("var", i)


def oracle(a: Code) -> Code:
    return ("oracle", a)


def call(clause: Code, branch: Code, arg: Code) -> Code:
    return ("call", clause, branch, arg)


def add(a: Code, b: Code) -> Code:
    return ("add", a, b)


def mul(a: Code, b: Code) -> Code:
    return ("mul", a, b)


def max_code(a: Code, b: Code) -> Code:
    return ("max", a, b)


def if_zero(test: Code, yes: Code, no: Code) -> Code:
    return ("ifZero", test, yes, no)


def let1(value: Code, body: Code) -> Code:
    return ("let1", value, body)


def nrec(count: Code, zero: Code, step: Code) -> Code:
    return ("nrec", count, zero, step)


def lookup(env: Sequence[int], i: int) -> int:
    return env[i] if 0 <= i < len(env) else 0


def body_at(program: Program, i: int) -> Code:
    return program[i] if 0 <= i < len(program) else lit(0)


def eval_code(
    g: Callable[[int], int],
    recur: Callable[[int, int, int], int],
    env: Tuple[int, ...],
    code: Code,
) -> int:
    tag = code[0]
    if tag == "lit":
        return code[1]
    if tag == "var":
        return lookup(env, code[1])
    if tag == "oracle":
        return g(eval_code(g, recur, env, code[1]))
    if tag == "call":
        return recur(
            eval_code(g, recur, env, code[1]),
            eval_code(g, recur, env, code[2]),
            eval_code(g, recur, env, code[3]),
        )
    if tag == "add":
        return eval_code(g, recur, env, code[1]) + eval_code(g, recur, env, code[2])
    if tag == "mul":
        return eval_code(g, recur, env, code[1]) * eval_code(g, recur, env, code[2])
    if tag == "max":
        return max(eval_code(g, recur, env, code[1]), eval_code(g, recur, env, code[2]))
    if tag == "ifZero":
        branch = code[2] if eval_code(g, recur, env, code[1]) == 0 else code[3]
        return eval_code(g, recur, env, branch)
    if tag == "let1":
        value = eval_code(g, recur, env, code[1])
        return eval_code(g, recur, (value, *env), code[2])
    if tag == "nrec":
        count = eval_code(g, recur, env, code[1])
        acc = eval_code(g, recur, env, code[2])
        for i in range(count):
            acc = eval_code(g, recur, (i, acc, *env), code[3])
        return acc
    raise ValueError(f"unknown code tag: {tag!r}")


def run(
    program: Program,
    g: Callable[[int], int],
    tree: Tree,
    clause: int,
    env: Tuple[int, ...],
) -> int:
    body = body_at(program, clause)
    if isinstance(tree, Zero):
        return eval_code(g, lambda _q, _b, _x: 0, env, body)
    if isinstance(tree, Succ):
        return eval_code(
            g,
            lambda q, _b, x: run(program, g, tree.child, q, (x, *env)),
            env,
            body,
        )
    if isinstance(tree, Lim):
        return eval_code(
            g,
            lambda q, b, x: run(program, g, tree.child(b), q, (x, *env)),
            env,
            body,
        )
    raise TypeError(f"unsupported tree: {tree!r}")


def value(program: Program, g: Callable[[int], int], tree: Tree, x: int) -> int:
    return run(program, g, tree, 0, (x,))


def orbit(g: Callable[[int], int], fuel: int, x: int) -> int:
    for _ in range(fuel):
        x = g(x)
    return x


def orbit_program(fuel: int) -> Program:
    return (nrec(lit(fuel), var(0), oracle(var(1))),)


def descent_program(fuel: int) -> Program:
    return (
        nrec(
            lit(fuel),
            oracle(var(0)),
            max_code(oracle(var(2)), call(lit(0), var(0), var(1))),
        ),
    )


def codes_up_to(n: int) -> list[Code]:
    if n == 0:
        return []
    es = codes_up_to(n - 1)
    pairs = [(a, b) for a in es for b in es]
    triples = [(a, b, c) for a, b in pairs for c in es]
    atoms = [lit(k) for k in range(n)] + [var(k) for k in range(n)]
    return (
        atoms
        + [oracle(a) for a in es]
        + [call(a, b, c) for a, b, c in triples]
        + [add(a, b) for a, b in pairs]
        + [mul(a, b) for a, b in pairs]
        + [max_code(a, b) for a, b in pairs]
        + [if_zero(a, b, c) for a, b, c in triples]
        + [let1(a, b) for a, b in pairs]
        + [nrec(a, b, c) for a, b, c in triples]
    )


def programs_up_to(alphabet: Sequence[Code], n: int) -> list[Program]:
    programs: list[Program] = [()]
    for _ in range(n):
        old = list(programs)
        programs.extend((a, *p) for a in alphabet for p in old)
    return programs


def programs_at(fuel: int) -> list[Program]:
    return [orbit_program(fuel), descent_program(fuel), *programs_up_to(codes_up_to(fuel), fuel)]


def envelope(g: Callable[[int], int], tree: Tree, fuel: int, x: int) -> int:
    return max((value(p, g, tree, x) for p in programs_at(fuel)), default=0)


def run_tests() -> None:
    plus_one = lambda n: n + 1

    assert value(orbit_program(3), plus_one, chain(7), 4) == 7
    assert value(descent_program(3), plus_one, ZERO, 4) == 5
    assert value(descent_program(3), plus_one, chain(1), 4) == 8

    mutual: Program = (
        call(lit(1), lit(0), add(var(0), lit(1))),
        add(var(0), lit(10)),
    )
    assert value(mutual, plus_one, chain(1), 3) == 14

    omega = Lim(chain)
    # On a limit, the step index selects the branch.  The exact value is less
    # important than consistency and termination, but recording it catches
    # environment-order and branch-selection regressions.
    assert value(descent_program(3), plus_one, omega, 1) == 20

    for fuel in range(3):
        for x in range(4):
            assert value(orbit_program(fuel), plus_one, chain(2), x) == orbit(plus_one, fuel, x)
            env = envelope(plus_one, chain(2), fuel, x)
            assert orbit(plus_one, fuel, x) <= env
            for p in programs_at(fuel):
                assert value(p, plus_one, chain(2), x) <= env

    print("PASS: certified-descent reference model")
    print("  orbit, descent, mutual dispatch, and limit-branch tests passed")
    print("  exhaustive envelope check passed for fuel <= 2 and input <= 3")


if __name__ == "__main__":
    run_tests()
