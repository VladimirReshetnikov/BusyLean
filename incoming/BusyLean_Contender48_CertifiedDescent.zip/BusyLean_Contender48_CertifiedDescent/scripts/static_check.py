#!/usr/bin/env python3
"""Static hygiene checks for the proposal archive.

This script cannot replace `lake build` or the Lean kernel.  It checks the
submission-specific syntactic rules that are easy to validate without Lean.
"""

from __future__ import annotations

import hashlib
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LEAN = ROOT / "lean"

FORBIDDEN = [
    r"\bsorry\b",
    r"\bsorryAx\b",
    r"\baxiom\b",
    r"\bnoncomputable\b",
    r"\bpartial\b",
    r"\bunsafe\b",
    r"\bopaque\b",
    r"\bnative_decide\b",
    r"\bimplemented_by\b",
    r"\bextern\b",
    r"#eval\b",
    r"run_cmd\b",
]


def fail(message: str) -> None:
    raise SystemExit(f"FAIL: {message}")


def main() -> None:
    lean_files = sorted(LEAN.rglob("*.lean"))
    if not lean_files:
        fail("no Lean files found")

    for path in lean_files:
        text = path.read_text(encoding="utf-8")
        for pattern in FORBIDDEN:
            if re.search(pattern, text):
                fail(f"forbidden token {pattern!r} in {path.relative_to(ROOT)}")
        for number, line in enumerate(text.splitlines(), start=1):
            if len(line) > 100:
                fail(f"line longer than 100 columns: {path.relative_to(ROOT)}:{number}")

    definition_text = "\n".join(
        (LEAN / "BusyLean" / name).read_text(encoding="utf-8")
        for name in ["CertifiedDescent.lean", "Contender48.lean"]
    )
    for forbidden_name in [
        "contender_47",
        "contender_44",
        "contender_43",
        "BigNumber.contender_6",
    ]:
        if forbidden_name in definition_text:
            fail(f"definition closure source mentions forbidden constant {forbidden_name}")

    required = {
        "CertifiedDescent.lean": ["def run", "def envelope", "theorem program_le_envelope"],
        "Contender48.lean": ["def family47", "def F48", "def contender_48"],
        "Comparison48.lean": ["theorem orbit47_lt_F48", "theorem contender_47_lt_contender_48"],
    }
    for filename, needles in required.items():
        text = (LEAN / "BusyLean" / filename).read_text(encoding="utf-8")
        for needle in needles:
            if needle not in text:
                fail(f"missing {needle!r} in {filename}")

    result = subprocess.run(
        [sys.executable, str(ROOT / "scripts" / "reference_model.py")],
        check=False,
        text=True,
        capture_output=True,
    )
    if result.returncode != 0:
        sys.stdout.write(result.stdout)
        sys.stderr.write(result.stderr)
        fail("reference model failed")

    digest = hashlib.sha256()
    for path in lean_files:
        digest.update(path.relative_to(ROOT).as_posix().encode())
        digest.update(path.read_bytes())

    print(result.stdout, end="")
    print(f"PASS: {len(lean_files)} Lean files passed static hygiene checks")
    print(f"Lean-source bundle SHA-256: {digest.hexdigest()}")
    print("NOTE: Lean 4.34.0 kernel replay is still required on an equipped host")


if __name__ == "__main__":
    main()
