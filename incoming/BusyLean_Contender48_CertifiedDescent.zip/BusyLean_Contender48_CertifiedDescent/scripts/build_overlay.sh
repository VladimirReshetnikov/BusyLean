#!/usr/bin/env bash
set -euo pipefail

# Run this from the root of a BusyLean checkout at the target commit after
# copying the proposal's lean/BusyLean files into BusyLean/ and lean/test files
# into test/, and after applying patches/integration.patch.

lake build BusyLean.Contender48
lake build BusyLean.Comparison48
lake env lean test/Contender48Smoke.lean
lake env lean test/Audit48.lean
python3 scripts/check.py
