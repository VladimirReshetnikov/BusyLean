# Package manifest

## Primary deliverables

- `article/contender48_certified_descent.tex` - 22-page research article source.
- `article/contender48_certified_descent.pdf` - compiled, rendered, and inspected article.
- `lean/BusyLean/CertifiedDescent.lean` - new finite program language, total
  tree-descending interpreter, finite enumeration, envelope, and generic
  majorization theorems.
- `lean/BusyLean/Contender48.lean` - closed natural-number definition.
- `lean/BusyLean/Comparison48.lean` - pointwise domination, explicit
  previous-family-sized orbit lower bound, and `C47 < C48`.

## Tests and audits

- `lean/test/Contender48Smoke.lean` - small definitional equations; no contender evaluation.
- `lean/test/Audit48.lean` - proposed kernel axiom reports.
- `scripts/reference_model.py` - independent executable semantics for small instances.
- `scripts/static_check.py` - source hygiene, formatting, declaration, and model checks.
- `scripts/build_overlay.sh` - replay commands for a patched BusyLean checkout.

## Integration material

- `patches/integration.patch` - imports, current-contender build target, and audit additions.
- `patches/README_INSERT.md` - concise repository README section.
- `BASELINE.md` - exact pinned C47 definitions and design constraints.
- `research/strength_notes.md` - strength analysis, limitations, and follow-up program.

## Reproducibility and validation

- `README.md` - construction summary and complete reproduction instructions.
- `VALIDATION_REPORT.md` - exact claim boundary and environment limitations.
- `REFERENCE_MODEL_OUTPUT.txt` - executable-model result.
- `STATIC_CHECK_OUTPUT.txt` - static checker result and Lean-source digest.
- `PATCH_DRY_RUN.txt` - integration-patch dry-run result.
- `LATEX_BUILD_REPORT.txt` - final TeX build result.
- `PDF_INFO.txt`, `PDF_FONTS.txt`, `PDF_PREFLIGHT.txt`,
  `PDF_RENDER_REPORT.txt` - PDF validation records.
- `CHECKSUMS.sha256` - SHA-256 digest for every other file in this directory tree.

## Frozen target

All names and comparisons target BusyLean commit
`4fe2f34c66324cc2f1c4f343d6c82d09915a6643`, where Contender 47 is the
installed baseline.  The package intentionally does not chase later moving
branch heads.
