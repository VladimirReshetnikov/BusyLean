# Validation report

## Reproducibility target

- Repository: `VladimirReshetnikov/BusyLean`
- Pinned commit: `4fe2f34c66324cc2f1c4f343d6c82d09915a6643`
- Baseline entry at that commit: Contender 47
- Intended toolchain: Lean 4.34.0
- Proposed entry: Contender 48

The snapshot is intentionally frozen.  BusyLean was receiving new contenders
while this package was being prepared, so all comparisons, patches, and source
names are relative to the commit above rather than to a moving branch head.

## Completed checks

- Ran `scripts/reference_model.py` successfully.  It checks:
  - the oracle-iteration program;
  - the certificate-using descent program;
  - dynamic mutual clause dispatch;
  - computed branch selection at a limit;
  - exhaustive envelope majorization for all generated programs at fuel at
    most 2 and inputs at most 3.
- Ran `scripts/static_check.py` successfully.  It checks:
  - absence of `sorry`, custom `axiom`, `noncomputable`, `partial`, `unsafe`,
    `opaque`, `native_decide`, `extern`, `implemented_by`, and elaborator-time
    execution;
  - absence of previous contender constants from definition source files;
  - 100-column source formatting;
  - required declarations and theorem statements;
  - the independent reference-model suite.
- Final Lean-source bundle SHA-256 reported by the static checker:
  `dd2abaeecea79197a01c2d0ea90a8abb130b962ad12345457dda2f49e7e8f824`.
- Dry-ran `patches/integration.patch` against synthetic files containing the
  exact pinned context hunks.  All three hunks applied in dry-run mode.
- Compiled the LaTeX article with `latexmk`/`pdflatex` under halt-on-error.
- Scanned the final log: no unresolved references, undefined citations,
  package warnings, or overfull/underfull boxes.
- Ran PDF metadata, font, and preflight checks.  The final PDF has 22 pages,
  opens normally, is not encrypted, and embeds all listed fonts.
- Rendered every PDF page at 200 DPI and visually inspected the full contact
  sheet plus representative theorem, table, source-appendix, and bibliography
  pages.  No clipping, overlap, black squares, or broken glyphs were observed.
- Tested the final ZIP archive with `unzip -t` after checksums were generated.

Machine-readable outputs are preserved in `REFERENCE_MODEL_OUTPUT.txt`,
`STATIC_CHECK_OUTPUT.txt`, `PATCH_DRY_RUN.txt`, `LATEX_BUILD_REPORT.txt`, and
the `PDF_*.txt` reports.

## Not completed in this environment

This runtime has no `lean`, `lake`, or `elan` executable.  No suitable external
Lean compiler integration was available.  Therefore:

- the Lean files were not elaborated by Lean 4.34.0 here;
- theorem axiom reports were not produced here;
- the repository timing budgets were not measured here;
- the integration patch was not replayed against a complete local checkout.

The package is consequently an **integration-ready research proposal**, not a
claim of kernel-checked acceptance.  The exact replay commands are in
`README.md` and `scripts/build_overlay.sh`.

## Mathematical claim levels

### Encoded as proposed Lean theorems

- Every enumerated program is bounded by the finite envelope.
- The envelope contains both the oracle-orbit witness and the canonical
  tree-sensitive descent accelerator.
- The envelope dominates a `family47(n)`-fold iterate of `family47` begun at
  `family47(n)`.
- `F48` strictly dominates `family47` pointwise.
- `contender_47 < contender_48`.

### Established metatheoretically by the definition's shape

- Natural recursion in expressions is primitive recursion.
- Every mutually recursive program call is interpreted at a strict child of
  the supplied certificate tree.
- Enumeration is finite at every finite budget.
- The resulting closed natural number is computable in principle.

### Deliberately not claimed

- A proof-theoretic ordinal calibration of the new envelope.
- A non-interpretability theorem separating the machine from FT2 or FLT2.
- Practical feasibility of evaluating the number.
- Kernel acceptance or contest timing before replay on the pinned toolchain.
