#!/usr/bin/env bash
set -euo pipefail

# Run from the root of a BusyLean checkout after copying the proposal files.
required_toolchain="leanprover/lean4:v4.34.0"
actual_toolchain="$(tr -d '\r\n' < lean-toolchain)"
if [[ "$actual_toolchain" != "$required_toolchain" ]]; then
  echo "warning: expected $required_toolchain, found $actual_toolchain" >&2
fi

proposal_files=(
  BusyLean/Ordinal/TreeMetaLanguage.lean
  BusyLean/Contender38.lean
  BusyLean/Comparison38.lean
)

if grep -RInE '\b(sorry|admit|axiom|unsafe|partial)\b|Classical\.choice|noncomputable' \
    "${proposal_files[@]}"; then
  echo "forbidden token found" >&2
  exit 1
fi

lake build BusyLean.Ordinal.TreeMetaLanguage
lake build BusyLean.Contender38
lake build BusyLean.Comparison38
lake env lean test/Contender38Audit.lean | tee contender38-audit.log
