# Research notes: first-class meta-closure over the ladder jump

## Snapshot

- Repository: `VladimirReshetnikov/BusyLean`
- Base commit: `b36822b1212e93693225b8886ebd8b743146c176`
- Base tree: `d5ad8bb3a7610bcaa7ae2b2b99b9f114903fa2ce`
- Incumbent: kernel-checked Contender 37
- Toolchain: Lean 4.34.0

## Conceptual move

Contender 37 defines a ladder jump

`jump n t = FLT.bootT family36 n t t`

and then stacks the lower System-T tree language over that jump:

`stackOver (jump n) (bootTree n) (bootTree n)`.

This is already a transfinite hierarchy of languages, but its successor clause
is fixed externally: apply `langLift` once to the preceding primitive.

The proposed successor adds an orthogonal closure. Its typed meta-language has
constants

- `seed : tree`,
- `base : tree -> tree`, interpreted by `boost31`, and
- `lang : (tree -> tree) -> (tree -> tree)`, interpreted by `langLift`.

For seed `s`, `metaLangLift s t` joins `P t` over all closed meta-programs
`P : tree -> tree` and all finite syntax bounds. `metaStack` iterates this join
along a tree; `metaStep t = metaStack t t t`; `metaTower` iterates the
self-rebased diagonal; `metaClosedTree s` embeds `s` and `metaTower s s`.

At input `n`:

- `family37 n = F37 (F37 n)`;
- `metaJumpBase n = metaClosedTree (jumpTree n)`;
- `metaJumpTree n = FLT.bootT family37 n (metaJumpBase n) (metaJumpBase n)`.

Thus the incumbent's jump-and-language-stack tree is first meta-closed and then
the System-FLT ladder-builds-ladder operation is rerun from and along the
enlarged tree, with a stronger oracle family.

## Formal target

The comparison uses only repository-generic facts:

1. finite prefix/program maxima make `mjTransformer` progressive;
2. `wDiagonalLift_preservesProgressive` gives `family37 n < F38 n`;
3. `input_lt_F37` twice gives `n < family37 n`;
4. therefore `contender_37 < contender_38`.

No exact ordinal calibration or program monotonicity is used.

## Validation risks

- Elaborating the dependent raw type checker in `TreeMetaLanguage.lean`.
- Ensuring the direct semantic interpreter accepts `langLift` at its higher
  simple type without universe issues.
- Clean-build timing of the additional enumeration definitions.
- Axiom output staying within `{propext, Quot.sound}`.
- Rebase conflicts if the rapidly changing repository advances past the pinned
  commit.

## Follow-on work

- Prove explicit address/program embeddings from `jumpTree` to `metaJumpTree`.
- Reconstruct the incumbent `stackOver (jump n)` orbit as concrete
  meta-language programs.
- Internalize a stratified fragment of `FLT.ladderTree` as object-level data.
- Move the meta-language from finite simple types to tree-indexed type codes.
- Develop an extensional tree semantics and calibrate against autonomous or
  recursively Mahlo-style progressions.
