## Current contender: Contender 38

```lean
def family37 (n : Nat) : Nat := F37 (F37 n)
def metaJumpBase (n : Nat) : Ordinal.CTree :=
  Ordinal.metaClosedTree (jumpTree n)
def metaJumpTree (n : Nat) : Ordinal.CTree :=
  FLT.bootT family37 n (metaJumpBase n) (metaJumpBase n)

def F38 (n : Nat) : Nat :=
  wDiagonalLift (schedule38 n) (rank38 n) mjTransformer
    (fun _ => family37) n n
def contender_38 : Nat := F38 (F38 42)

theorem contender_37_lt_contender_38 : contender_37 < contender_38
```

Contender 38 closes the incumbent `jumpTree n` under a typed meta-language in
which `langLift` itself is first-class, then reruns the System-FLT
ladder-builds-ladder bootstrap from and along that meta-closed tree using
Contender 37's family as oracle. The result remains an ordinary inductive tree,
so address well-foundedness is structural.
