import BusyLean.Comparison38

#check BusyLean.contender_38
#check BusyLean.contender_37_lt_contender_38
#check BusyLean.family37_lt_F38
#check BusyLean.mjvalue_lt_F38
#check BusyLean.metaJumpTree
#check BusyLean.Ordinal.metaClosedTree

#print axioms BusyLean.contender_38
#print axioms BusyLean.contender_37_lt_contender_38
#print axioms BusyLean.family37_lt_F38
#print axioms BusyLean.mjvalue_lt_F38
