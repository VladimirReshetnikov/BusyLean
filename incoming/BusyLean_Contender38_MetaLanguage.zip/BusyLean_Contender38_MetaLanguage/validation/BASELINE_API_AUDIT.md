# Baseline API audit

Pinned repository state:

- commit `b36822b1212e93693225b8886ebd8b743146c176`
- tree `d5ad8bb3a7610bcaa7ae2b2b99b9f114903fa2ce`
- incumbent `Contender 37`
- toolchain `leanprover/lean4:v4.34.0`

APIs checked against GitHub source:

- `Ordinal.CTree`, `Ordinal.Addr`, `Ordinal.addr_wf`, `Ordinal.addrUpTo`;
- `Ordinal.TL.Ty`, `TL.Var`, `TL.Env`, `TL.lookup`, `TL.tysUpTo`,
  `TL.natIter`, and `TL.treeIter`;
- `Ordinal.boost31` and `Ordinal.langLift`;
- `FLT.bootT` and the incumbent `jumpTree`;
- `FL.wfUniv`, `FL.sn_of_typed`, `FL.infer_sound`, `FL.ctmsUpTo`;
- `W.wDiagonalLift_preservesProgressive` and
  `W.wDiagonalLift_strictlyInflationary`;
- incumbent growth theorem `input_lt_F37` and comparison theorem
  `contender_36_lt_contender_37`.

The proposed source is pinned because `main` advanced repeatedly while the
artifact was being prepared.
