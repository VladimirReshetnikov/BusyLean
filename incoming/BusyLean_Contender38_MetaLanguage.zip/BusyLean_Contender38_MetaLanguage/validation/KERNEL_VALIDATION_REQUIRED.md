# Kernel validation required

The artifact container did not have Lean 4.34.0, so the proposed modules have
not been claimed as kernel checked here.

From a clean checkout of BusyLean commit
`b36822b1212e93693225b8886ebd8b743146c176`, copy the proposal files, apply the
root import patch, and run:

```bash
scripts/validate.sh
```

The script builds:

```text
BusyLean.Ordinal.TreeMetaLanguage
BusyLean.Contender38
BusyLean.Comparison38
```

and then runs `test/Contender38Audit.lean`, which prints axioms for the closed
number and principal comparison theorems. Acceptance requires no
`Classical.choice` or new postulates; imported dependencies may report only the
repository-permitted `propext` and `Quot.sound`.
