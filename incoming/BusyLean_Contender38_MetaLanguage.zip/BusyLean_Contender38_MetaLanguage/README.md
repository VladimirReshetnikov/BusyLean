# BusyLean Contender 38 proposal

## Result

This package proposes **Contender 38**, relative to BusyLean commit
`b36822b1212e93693225b8886ebd8b743146c176`, whose incumbent is the
kernel-checked Contender 37.

```lean
def family37 (n : Nat) : Nat := F37 (F37 n)

def metaJumpBase (n : Nat) : Ordinal.CTree :=
  Ordinal.metaClosedTree (jumpTree n)

def metaJumpTree (n : Nat) : Ordinal.CTree :=
  FLT.bootT family37 n (metaJumpBase n) (metaJumpBase n)

def F38 (n : Nat) : Nat :=
  wDiagonalLift (schedule38 n) (rank38 n) mjTransformer
    (fun _ => family37) n n

def contender_38 : Nat := F38 (F38 42)
```

The proposed comparison theorem is:

```lean
theorem contender_37_lt_contender_38 : contender_37 < contender_38
```

This is not a successor trick. Contender 37 stacks the lower tree language over
Contender 36's System-FLT ladder jump, with one prescribed `langLift` at every
successor stage. Contender 38 first subjects the complete incumbent
`jumpTree n` to a typed meta-language where `langLift` is a first-class
higher-order value. Programs can compose it with lower constructions, pass it
as an argument, and iterate the resulting operators by natural and tree
recursion. It then reruns the System-FLT ladder-builds-ladder bootstrap from and
along the meta-closed tree, with the strictly stronger oracle `family37`.
Finally, W-ranked hyperreflection is seeded by the complete Contender 37
family.

## Files

- `BusyLean/Ordinal/TreeMetaLanguage.lean` - first-class language-transformer
  meta-language and tree-recursive universal closure.
- `BusyLean/Contender38.lean` - meta-closed System-FLT bootstrap, ladder
  evaluator, reflection transformer, W-ranked amplifier, and closed number.
- `BusyLean/Comparison38.lean` - pointwise domination and final comparison.
- `test/Contender38Audit.lean` - declaration and axiom audit.
- `scripts/validate.sh` and `.github/workflows/contender38-validation.yml` -
  reproducible Lean 4.34.0 validation.
- `integration/` - root import patch and README snippet.
- `article/contender38.tex` and `article/contender38.pdf` - research article.
- `SOURCE_SNAPSHOT.json`, `validation/`, and `MANIFEST.sha256` - provenance and
  QA artifacts.

## Integration

From a checkout of the pinned BusyLean commit:

```bash
cp -R BusyLean/. /path/to/BusyLean/BusyLean/
cp test/Contender38Audit.lean /path/to/BusyLean/test/
cp scripts/validate.sh /path/to/BusyLean/scripts/
cp .github/workflows/contender38-validation.yml \
  /path/to/BusyLean/.github/workflows/
cd /path/to/BusyLean
patch -p1 < /path/to/package/integration/BusyLean.lean.patch
scripts/validate.sh
```

## Validation status

The source was designed line-for-line against the pinned APIs and statically
audited for placeholders and noncomputable escape hatches. The artifact
container did not contain Lean 4.34.0, and the official Linux distribution was
larger than the connector's download limit. This package therefore **does not
claim a completed kernel check of the new modules**. The validation script and
workflow are the acceptance gate. The PDF was compiled, preflighted, rendered,
and visually inspected.

## Constructivity

Every new definition uses finite lists at finite bounds, an intrinsically typed
total interpreter, inductive countable trees, and structural recursion. The
proposal source contains no `noncomputable`, `Classical.choice`, user `axiom`,
`sorry`, `admit`, `unsafe`, or `partial`. Imported normalization may report only
the repository-permitted propositional axioms `propext` and `Quot.sound`; the
audit rules out new postulates and choice. The closed natural is computable in
principle, although reduction to a numeral is wholly infeasible.
