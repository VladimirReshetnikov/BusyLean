import BusyLean.Contender38
import BusyLean.Comparison37

/-! # Contender 38: comparison theorems -/

namespace BusyLean

open BusyLean.W

theorem lt_reflectMJFamily {fs : Family} {n m : Nat}
    (h : m <= BigNumber.maxN (prefixMax (fun i => fs i n) n)
      (BigNumber.maximum (FL.mjvalue n (packFamily fs) n)
        (FL.mjLadderUpTo n))) :
    m < reflectMJFamily fs n := by
  show m < n + 1 + _
  have hM : forall M : Nat, M + 1 <= n + 1 + M := fun M => by
    rw [Nat.add_comm M 1]
    exact Nat.add_le_add_right (Nat.le_add_left 1 n) M
  exact Nat.lt_of_le_of_lt h
    (Nat.lt_of_lt_of_le (Nat.lt_succ_self _) (hM _))

theorem oracle_lt_reflectMJFamily (fs : Family) {i n : Nat}
    (hi : i <= n) :
    fs i n < reflectMJFamily fs n :=
  lt_reflectMJFamily
    (Nat.le_trans (le_prefixMax (fun j => fs j n) hi)
      (BigNumber.le_maxN_left _ _))

theorem mjvalue_lt_reflectMJFamily (fs : Family) {n : Nat}
    {t : FL.CTm (Ordinal.Addr (metaJumpTree n))}
    (ht : t ∈ FL.mjLadderUpTo n) :
    FL.mjvalue n (packFamily fs) n t < reflectMJFamily fs n :=
  lt_reflectMJFamily
    (Nat.le_trans (le_maximum (FL.mjvalue n (packFamily fs) n) ht)
      (BigNumber.le_maxN_right _ _))

theorem mjTransformer_progressive : Progressive mjTransformer :=
  fun seed _ _ _ hi => oracle_lt_reflectMJFamily seed hi

/-- At every input, `F38` exceeds Contender 37's family. -/
theorem family37_lt_F38 (n : Nat) : family37 n < F38 n :=
  ((wDiagonalLift_preservesProgressive (schedule38 n) (rank38 n))
    mjTransformer mjTransformer_progressive)
    (fun _ => family37) 0 n n (Nat.zero_le n)

theorem raw_reflection_lt_F38 (n : Nat) :
    reflectMJFamily (fun _ => family37) n < F38 n :=
  (wDiagonalLift_strictlyInflationary (schedule38 n) (rank38 n))
    mjTransformer mjTransformer_progressive (fun _ => family37)
      n n n (Nat.le_refl n)

/-- Every enumerated ladder program over `metaJumpTree n`, run with the packed
seed, is below `F38 n`. -/
theorem mjvalue_lt_F38 {n : Nat}
    {t : FL.CTm (Ordinal.Addr (metaJumpTree n))}
    (ht : t ∈ FL.mjLadderUpTo n) :
    FL.mjvalue n (packFamily (fun _ => family37)) n t < F38 n :=
  Nat.lt_trans (mjvalue_lt_reflectMJFamily (fun _ => family37) ht)
    (raw_reflection_lt_F38 n)

theorem input_lt_family37 (n : Nat) : n < family37 n :=
  Nat.lt_trans (input_lt_F37 n) (input_lt_F37 (F37 n))

theorem input_lt_F38 (n : Nat) : n < F38 n :=
  Nat.lt_trans (input_lt_family37 n) (family37_lt_F38 n)

/-- **The required comparison**: Contender 37 is strictly smaller than
Contender 38. -/
theorem contender_37_lt_contender_38 : contender_37 < contender_38 :=
  Nat.lt_trans (family37_lt_F38 42) (input_lt_F38 (F38 42))

theorem contender_36_lt_contender_38 : contender_36 < contender_38 :=
  Nat.lt_trans contender_36_lt_contender_37 contender_37_lt_contender_38

end BusyLean
