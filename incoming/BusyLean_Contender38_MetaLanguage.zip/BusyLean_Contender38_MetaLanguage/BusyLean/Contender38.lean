import BusyLean.Ordinal.TreeMetaLanguage
import BusyLean.Contender37

/-!
# Contender 38: meta-closed ladder jumps

```
contender_38 := F38 (F38 42)
F38 n        := wDiagonalLift (schedule38 n) (rank38 n)
                  mjTransformer (fun _ => family37) n n
```

Contender 37 treats Contender 36's System-FLT bootstrap as a jump on trees and
stacks the lower System-T tree language over that jump along `bootTree n`.
The stacking operation is still prescribed externally: successor stages apply
one fixed transformer `langLift`.

Contender 38 first closes the complete incumbent tree `jumpTree n` under a
typed meta-language in which `langLift` itself is a first-class higher-order
constant.  Closed programs can pass it as data, compose it with `boost31`, and
iterate such combinations by natural and tree recursion.  The universal join
of all closed meta-programmed tree endomorphisms is iterated along the seed and
then through a self-rebased outer diagonal.

The System-FLT ladder-builds-ladder bootstrap is then rerun from and along this
meta-closed tree, relative to the stronger oracle
`family37 n = F37 (F37 n)`.  The resulting `metaJumpTree n` is an ordinary
inductive countable tree, so its address order is structurally well-founded and
the existing transfinite ladder normalization applies unchanged.

The numeric amplifier is the W-ranked lift hierarchy, seeded with the complete
Contender 37 family.

**Do not evaluate `contender_38`.**
-/

namespace BusyLean

/-- Contender 37 as a family: `family37 42 = contender_37`. -/
def family37 (n : Nat) : Nat := F37 (F37 n)

/-- The incumbent jump-and-language-stack tree, closed under the first-class
language-transformer meta-language and its transfinite self-bootstrap. -/
def metaJumpBase (n : Nat) : Ordinal.CTree :=
  Ordinal.metaClosedTree (jumpTree n)

/-- Rerun the System-FLT ladder-builds-ladder bootstrap from and along the
meta-closed incumbent tree, with the stronger oracle `family37`. -/
def metaJumpTree (n : Nat) : Ordinal.CTree :=
  FLT.bootT family37 n (metaJumpBase n) (metaJumpBase n)

end BusyLean

namespace BusyLean.FL

open Ordinal

theorem sn_erase_metajumptree {f : Nat -> Nat} (L : Nat) {fuel : Nat}
    {t : CTm (Addr (metaJumpTree L))}
    (h : infer fuel [] [] t = some Ty.nat) : F.SN f (erase t) :=
  sn_of_typed (wfUniv f (addr_wf (metaJumpTree L)))
    (infer_sound fuel t (goodCtx_nil []) h).1

/-- The value of a program over the addresses of `metaJumpTree L`, relative to
the oracle `f`. -/
def mjvalue (L : Nat) (f : Nat -> Nat) (fuel : Nat)
    (t : CTm (Addr (metaJumpTree L))) : Nat :=
  match h : infer fuel [] [] t with
  | some A =>
      if hA : A = Ty.nat then
        F.decode (F.nf f
          ⟨erase t, sn_erase_metajumptree L (h.trans (congrArg some hA))⟩)
      else 0
  | none => 0

/-- Programs of depth at most `n` over the addresses of `metaJumpTree n`. -/
def mjLadderUpTo (n : Nat) : List (CTm (Addr (metaJumpTree n))) :=
  ctmsUpTo (addrUpTo (metaJumpTree n) n) n

end BusyLean.FL

namespace BusyLean

open BigNumber (WTree)
open BusyLean.W

/-- Reflection over the meta-closed ladder jump, with a countable oracle
family. -/
def reflectMJFamily (fs : Family) (n : Nat) : Nat :=
  n + 1 + BigNumber.maxN (prefixMax (fun i => fs i n) n)
    (BigNumber.maximum (FL.mjvalue n (packFamily fs) n)
      (FL.mjLadderUpTo n))

def mjTransformer : Transformer := fun fs _ n => reflectMJFamily fs n

def schedule38 (n : Nat) : WTree Nat :=
  Autonomous.realize
    (Autonomous.hyper (family37 n + 42) (Autonomous.encode (schedule37 n)))

def rank38 (n : Nat) : WTree Nat :=
  Autonomous.realize
    (Autonomous.hyper (family37 n + 42) (Autonomous.encode (schedule38 n)))

/-- W-ranked hyperreflection of the meta-closed ladder jumps, seeded with
Contender 37's family. -/
def F38 (n : Nat) : Nat :=
  wDiagonalLift (schedule38 n) (rank38 n) mjTransformer
    (fun _ => family37) n n

/-- **Contender 38.** Never evaluate it. -/
def contender_38 : Nat := F38 (F38 42)

end BusyLean
