import BusyLean.Ordinal.TreeLanguage3

/-!
# A meta-language for tree-language transformers

Contender 37 stacks the transformer `langLift` externally over the
System-FLT ladder jump, along a tree ordinal.  This module attacks a remaining
language-level bottleneck: it internalizes `langLift` itself as a first-class
higher-order constant of a typed language.

The tree meta-language is Goedel's System T over naturals and countable tree
ordinals, with three distinguished closed constants:

* `seed : tree`, supplied by the surrounding construction;
* `base : tree -> tree`, Contender 31's operator `boost31`;
* `lang : (tree -> tree) -> (tree -> tree)`, the whole lower tree-language
  transformer `langLift`.

Programs can combine `langLift` at higher types, pass it as an argument, and
iterate it by natural or tree recursion.  `metaLangLift seed` joins every
closed `tree -> tree` program of every finite size.  We iterate that universal
operator along a tree (`metaStack`) and then iterate the self-rebased diagonal
`t |-> metaStack t t t` along a tree (`metaTower`).

Everything below is total: the interpreter is structural recursion on typed
terms; enumeration is finite at every bound; and all generated ordinals are
ordinary inductive trees.  No choice principle is used.
-/

namespace BusyLean.Ordinal

namespace TML

/-- Intrinsically typed terms for the tree meta-language. -/
inductive Tm : List TL.Ty -> TL.Ty -> Type where
  | var : TL.Var Γ a -> Tm Γ a
  | lam : Tm (a :: Γ) b -> Tm Γ (.arr a b)
  | app : Tm Γ (.arr a b) -> Tm Γ a -> Tm Γ b
  | zero : Tm Γ .nat
  | succ : Tm Γ .nat -> Tm Γ .nat
  | natRec : Tm Γ a -> Tm Γ (.arr a a) -> Tm Γ .nat -> Tm Γ a
  | tzero : Tm Γ .tree
  | tsucc : Tm Γ .tree -> Tm Γ .tree
  | tlim : Tm Γ (.arr .nat .tree) -> Tm Γ .tree
  | treeRec : Tm Γ a -> Tm Γ (.arr a a) ->
      Tm Γ (.arr (.arr .nat a) a) -> Tm Γ .tree -> Tm Γ a
  | seed : Tm Γ .tree
  | base : Tm Γ (.arr .tree .tree)
  | lang : Tm Γ (.arr (.arr .tree .tree) (.arr .tree .tree))

/-- The semantic interpreter.  Intrinsic typing makes this plain structural
recursion into Lean values. -/
def Tm.eval (seedTree : CTree) : Tm Γ a -> TL.Env Γ -> a.den
  | .var v, ρ => v.get ρ
  | .lam t, ρ => fun x => t.eval seedTree (x, ρ)
  | .app t u, ρ => (t.eval seedTree ρ) (u.eval seedTree ρ)
  | .zero, _ => (0 : Nat)
  | .succ t, ρ => Nat.succ (t.eval seedTree ρ)
  | .natRec z s n, ρ =>
      TL.natIter (z.eval seedTree ρ) (s.eval seedTree ρ) (n.eval seedTree ρ)
  | .tzero, _ => (Tre.zero : CTree)
  | .tsucc t, ρ => (Tre.succ (t.eval seedTree ρ) : CTree)
  | .tlim f, ρ => (Tre.lim (f.eval seedTree ρ) : CTree)
  | .treeRec z s l t, ρ =>
      TL.treeIter (z.eval seedTree ρ) (s.eval seedTree ρ)
        (l.eval seedTree ρ) (t.eval seedTree ρ)
  | .seed, _ => seedTree
  | .base, _ => boost31
  | .lang, _ => langLift

/-! ## Raw syntax and type checking -/

/-- Raw terms.  Lambdas carry the type of their bound variable. -/
inductive Raw where
  | var : Nat -> Raw
  | lam : TL.Ty -> Raw -> Raw
  | app : Raw -> Raw -> Raw
  | zero : Raw
  | succ : Raw -> Raw
  | natRec : Raw -> Raw -> Raw -> Raw
  | tzero : Raw
  | tsucc : Raw -> Raw
  | tlim : Raw -> Raw
  | treeRec : Raw -> Raw -> Raw -> Raw -> Raw
  | seed : Raw
  | base : Raw
  | lang : Raw

/-- Cast an intrinsically typed term after a decidable type-equality test. -/
def cast? {Γ : List TL.Ty} {a : TL.Ty} (b : TL.Ty)
    (t : Tm Γ a) : Option (Tm Γ b) :=
  if h : a = b then some (h ▸ t) else none

/-- Type inference for raw meta-language terms. -/
def infer (Γ : List TL.Ty) : Raw -> Option (Sigma fun a => Tm Γ a)
  | .var n => (TL.lookup Γ n).map fun ⟨a, v⟩ => ⟨a, .var v⟩
  | .lam a r => (infer (a :: Γ) r).map fun ⟨b, t⟩ => ⟨.arr a b, .lam t⟩
  | .app r s => do
      let ⟨ab, t⟩ <- infer Γ r
      let ⟨_, u⟩ <- infer Γ s
      match ab, t with
      | .arr a b, t => do
          let u' <- cast? a u
          pure ⟨b, .app t u'⟩
      | _, _ => none
  | .zero => some ⟨.nat, .zero⟩
  | .succ r => do
      let ⟨_, t⟩ <- infer Γ r
      let t' <- cast? .nat t
      pure ⟨.nat, .succ t'⟩
  | .natRec z s n => do
      let ⟨a, tz⟩ <- infer Γ z
      let ⟨_, ts⟩ <- infer Γ s
      let ⟨_, tn⟩ <- infer Γ n
      let ts' <- cast? (.arr a a) ts
      let tn' <- cast? .nat tn
      pure ⟨a, .natRec tz ts' tn'⟩
  | .tzero => some ⟨.tree, .tzero⟩
  | .tsucc r => do
      let ⟨_, t⟩ <- infer Γ r
      let t' <- cast? .tree t
      pure ⟨.tree, .tsucc t'⟩
  | .tlim r => do
      let ⟨_, t⟩ <- infer Γ r
      let t' <- cast? (.arr .nat .tree) t
      pure ⟨.tree, .tlim t'⟩
  | .treeRec z s l r => do
      let ⟨a, tz⟩ <- infer Γ z
      let ⟨_, ts⟩ <- infer Γ s
      let ⟨_, tl⟩ <- infer Γ l
      let ⟨_, tr⟩ <- infer Γ r
      let ts' <- cast? (.arr a a) ts
      let tl' <- cast? (.arr (.arr .nat a) a) tl
      let tr' <- cast? .tree tr
      pure ⟨a, .treeRec tz ts' tl' tr'⟩
  | .seed => some ⟨.tree, .seed⟩
  | .base => some ⟨.arr .tree .tree, .base⟩
  | .lang =>
      some ⟨.arr (.arr .tree .tree) (.arr .tree .tree), .lang⟩

/-- Raw terms of size at most `n`, with variables below `n`. -/
def rawsUpTo : Nat -> List Raw
  | 0 => []
  | n + 1 =>
      let rs := rawsUpTo n
      let ts := TL.tysUpTo n
      (List.range n).map .var ++ [.zero, .tzero, .seed, .base, .lang] ++
      ts.flatMap (fun a => rs.map (.lam a)) ++
      rs.flatMap (fun r => rs.map (.app r)) ++
      rs.map .succ ++ rs.map .tsucc ++ rs.map .tlim ++
      rs.flatMap (fun z => rs.flatMap fun s => rs.map (.natRec z s)) ++
      rs.flatMap (fun z => rs.flatMap fun s =>
        rs.flatMap fun l => rs.map (.treeRec z s l))

/-- Closed tree-valued programs of size at most `m`, evaluated at `seedTree`. -/
def treesUpTo (seedTree : CTree) (m : Nat) : List CTree :=
  (rawsUpTo m).filterMap fun r =>
    match infer [] r with
    | some ⟨.tree, t⟩ => some (t.eval seedTree ())
    | _ => none

/-- Closed tree endomorphisms of size at most `m`, evaluated at `seedTree`. -/
def funsUpTo (seedTree : CTree) (m : Nat) : List (CTree -> CTree) :=
  (rawsUpTo m).filterMap fun r =>
    match infer [] r with
    | some ⟨.arr .tree .tree, t⟩ => some (t.eval seedTree ())
    | _ => none

end TML

/-- The universal endomorphism generated by the meta-language over `seed`.
For every program size and every closed tree endomorphism at that size, one
branch applies the endomorphism to `t`. -/
def metaLangLift (seed t : CTree) : CTree :=
  .lim fun m => .lim fun i =>
    (((TML.funsUpTo seed m)[i]?).map (fun f => f t)).getD .zero

/-- Iterate the universal meta-language endomorphism along a tree ordinal. -/
def metaStack (seed : CTree) : CTree -> CTree -> CTree
  | .zero => fun t => t
  | .succ a => fun t => metaLangLift seed (metaStack seed a t)
  | .lim f => fun t => .lim fun i => metaStack seed (f i) t
  | .supL _ => fun t => t
  | .supH _ => fun t => t

/-- Self-rebased diagonal: the same tree supplies the language seed, iteration
height, and argument. -/
def metaStep (t : CTree) : CTree := metaStack t t t

/-- Iterate the self-rebased diagonal along a tree ordinal. -/
def metaTower : CTree -> CTree -> CTree
  | .zero => fun t => t
  | .succ a => fun t => metaStep (metaTower a t)
  | .lim f => fun t => .lim fun i => metaTower (f i) t
  | .supL _ => fun t => t
  | .supH _ => fun t => t

/-- Close a seed tree under the transfinite self-bootstrap of the
meta-language.  Branch zero embeds the seed unchanged. -/
def metaClosedTree (seed : CTree) : CTree :=
  .lim fun i => if i = 0 then seed else metaTower seed seed

end BusyLean.Ordinal
