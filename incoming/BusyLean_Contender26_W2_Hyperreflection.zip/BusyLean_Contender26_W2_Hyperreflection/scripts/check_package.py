#!/usr/bin/env python3
"""Static integrity checks; deliberately not a substitute for Lean."""

from __future__ import annotations

import hashlib
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
LIBRARY = [
    ROOT / "BusyLean" / "SecondOrderHyperReflection.lean",
    ROOT / "BusyLean" / "SecondOrderHyperReflectionFacts.lean",
    ROOT / "BusyLean" / "Contender26.lean",
    ROOT / "BusyLean" / "Comparison26.lean",
]
REQUIRED = LIBRARY + [
    ROOT / "test" / "Contender26Audit.lean",
    ROOT / "article" / "contender26.tex",
    ROOT / "article" / "contender26.pdf",
    ROOT / "README.md",
    ROOT / "VALIDATION.md",
    ROOT / "notes" / "repository_snapshot.md",
    ROOT / "patches" / "integration.patch",
]

FORBIDDEN = [
    r"\bnoncomputable\b",
    r"\bpartial\b",
    r"\bunsafe\b",
    r"\baxiom\b",
    r"\bopaque\b",
    r"\bextern\b",
    r"\bsorry\b",
    r"\badmit\b",
    r"implemented_by",
    r"#eval",
]


def strip_comments(text: str) -> str:
    """Remove the non-nested comments used by the package's Lean sources."""
    text = re.sub(r"/-.*?-/", "", text, flags=re.S)
    text = re.sub(r"--.*", "", text)
    return text


def sha256(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def check_balanced(source: str, path: pathlib.Path) -> bool:
    failed = False
    for left, right, label in [("(", ")", "parentheses"), ("[", "]", "brackets")]:
        if source.count(left) != source.count(right):
            print(f"Unbalanced {label} in {path.relative_to(ROOT)}")
            failed = True
    return failed


def main() -> int:
    missing = [str(path.relative_to(ROOT)) for path in REQUIRED if not path.is_file()]
    if missing:
        print("Missing required files:")
        print("\n".join(f"  - {path}" for path in missing))
        return 1

    failed = False
    for path in LIBRARY:
        source = strip_comments(path.read_text(encoding="utf-8"))
        for pattern in FORBIDDEN:
            if re.search(pattern, source):
                print(f"FORBIDDEN token {pattern!r} in {path.relative_to(ROOT)}")
                failed = True
        failed |= check_balanced(source, path)

    contender_path = ROOT / "BusyLean" / "Contender26.lean"
    contender = strip_comments(contender_path.read_text(encoding="utf-8"))
    if "contender_25" in contender:
        print("Contender26.lean directly mentions incumbent constant contender_25")
        failed = True
    if "def contender_26 : Nat := F26 (F26 42)" not in contender:
        print("Canonical contender_26 definition was not found")
        failed = True

    comparison = strip_comments(
        (ROOT / "BusyLean" / "Comparison26.lean").read_text(encoding="utf-8")
    )
    for theorem_name in [
        "family25_lt_F26",
        "F25_lt_F26",
        "avalue_lt_F26",
        "contender_25_lt_contender_26",
    ]:
        if f"theorem {theorem_name}" not in comparison:
            print(f"Missing theorem {theorem_name}")
            failed = True

    print("Static source scan:", "FAILED" if failed else "passed")
    print("SHA-256 inventory:")
    for path in sorted(item for item in ROOT.rglob("*") if item.is_file()):
        if path.name in {"SHA256SUMS", ".DS_Store"}:
            continue
        print(f"{sha256(path)}  {path.relative_to(ROOT).as_posix()}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
