# BusyLean Contender 26: W2-ranked hyperreflection

This package proposes a constructive Lean natural number that formally targets
the live BusyLean incumbent, Contender 25, at repository commit
`c2f81dcb0f59d6cab513dc36fd9f1a1c17ff1516`.

## Core idea

Contender 25 combines the repository's strongest integrated object language—
reflection over finite addresses in the collapsed tree ordinal `bigTree n`—
with a W-tree-ranked hierarchy at the type

```text
TransformerLift = Transformer -> Transformer.
```

Contender 26 retains that language and moves one full operator type upward:

```text
HyperLift = TransformerLift -> TransformerLift.
```

`w2DiagonalLift` recursively splices child-rank hyperlifts, uses the result to
pre-amplify the base lift, and traverses an autonomous W-tree schedule with the
same higher-order operation. The candidate seeds this second-order hierarchy
with Contender 25's W-ranked lift evaluated at `family25 n`, where
`family25 n = F25 (F25 n)`.

This differs materially from the previously reviewed finite-rank second-order
proposal P26: the outer hierarchy here has an arbitrary W-tree rank, the seed
is the live incumbent's full W-ranked amplifier at a self-amplified input, and
the base transformer is the newer address/collapsed-tree language.

## Proposed definition

```lean
def family25 (n : Nat) : Nat := F25 (F25 n)

def seedLift26 (n : Nat) : TransformerLift :=
  wDiagonalLift (schedule25 (family25 n)) (rank25 (family25 n))

def finalLift26 (n : Nat) : TransformerLift :=
  w2DiagonalLift (schedule26 n) (rank26 n) (seedLift26 n)

def F26 (n : Nat) : Nat :=
  finalLift26 n aTransformer (fun _ => family25) n n

def contender_26 : Nat := F26 (F26 42)
```

The central intended theorem is supplied in `Comparison26.lean`:

```lean
theorem contender_25_lt_contender_26 :
  contender_25 < contender_26
```

The proof factors through generic higher-type strict-growth lemmas and the
existing formal theorem chain. It also gives the pointwise results
`family25 n < F26 n` and `F25 n < F26 n`, and carries forward the bound for
every visible program over the address language `Addr (bigTree n)`.

## Files

- `BusyLean/SecondOrderHyperReflection.lean` — higher-type definitions.
- `BusyLean/SecondOrderHyperReflectionFacts.lean` — generic growth theorems.
- `BusyLean/Contender26.lean` — proposed number.
- `BusyLean/Comparison26.lean` — dominance and address-program bounds.
- `test/Contender26Audit.lean` — kernel/axiom audit commands.
- `patches/integration.patch` — patch against the recorded baseline.
- `article/contender26.tex` and `article/contender26.pdf` — research article.
- `VALIDATION.md` — exact validation status and commands.
- `scripts/check_package.py` — static checks and checksum inventory.

## Integration and validation

Apply `patches/integration.patch` at the recorded baseline, or copy the four
library files and add their imports to `BusyLean.lean`. Then run:

```bash
lake env lean BusyLean/SecondOrderHyperReflection.lean
lake env lean BusyLean/SecondOrderHyperReflectionFacts.lean
lake env lean BusyLean/Contender26.lean
lake env lean BusyLean/Comparison26.lean
lake env lean test/Contender26Audit.lean
python scripts/check.py
```

Do not evaluate `contender_26`.

See `VALIDATION.md`: the artifact was statically checked and its article was
compiled and visually inspected in this environment, but Lean 4.34.0 was not
available locally, so the supplied Lean proof has not been kernel-elaborated
here. This limitation is stated rather than hidden.
