# Repository snapshot used for this proposal

- Repository: `VladimirReshetnikov/BusyLean`
- Default branch: `main`
- Baseline commit: `c2f81dcb0f59d6cab513dc36fd9f1a1c17ff1516`
- Snapshot date: 2026-10-13
- Lean toolchain: `leanprover/lean4:v4.34.0`
- Integrated incumbent: `BusyLean.contender_25`

The incumbent is

```lean
def family24 (n : Nat) : Nat := F24 (F24 n)
def F25 (n : Nat) : Nat :=
  wDiagonalLift (schedule25 n) (rank25 n)
    aTransformer (fun _ => family24) n n
def contender_25 : Nat := F25 (F25 42)
```

Its object language reflects typed programs over finite addresses in
`Ordinal.bigTree n`; its formal comparison theorem is

```lean
theorem contender_24_lt_contender_25 : contender_24 < contender_25
```

The repository changed twice while this artifact was being developed. Drafts
targeting Contenders 23 and 24 were discarded. Every final artifact is rebased
to the live Contender 25 baseline above.
