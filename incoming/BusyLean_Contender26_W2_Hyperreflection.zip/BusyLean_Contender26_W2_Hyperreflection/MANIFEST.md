# Package manifest

## Research article

- `article/contender26.tex` — complete LaTeX source.
- `article/contender26.pdf` — compiled 20-page article.

## Lean proposal

- `BusyLean/SecondOrderHyperReflection.lean` — higher-type W2 definitions.
- `BusyLean/SecondOrderHyperReflectionFacts.lean` — generic preservation and
  strict-growth theorems.
- `BusyLean/Contender26.lean` — instantiated candidate over live Contender 25.
- `BusyLean/Comparison26.lean` — pointwise, program-level, and final numerical
  comparisons.
- `test/Contender26Audit.lean` — axiom and signature audit commands.

## Integration and reproducibility

- `patches/integration.patch` — patch against BusyLean commit
  `c2f81dcb0f59d6cab513dc36fd9f1a1c17ff1516`.
- `scripts/build_article.sh` — article build command.
- `scripts/check_package.py` — static integrity checker.
- `notes/repository_snapshot.md` — exact incumbent snapshot.
- `VALIDATION.md` — validation boundaries and maintainer commands.
- `validation/static_checks.txt` — static check receipt.
- `validation/patch_check.txt` — patch-application receipt.
- `validation/pdf_check.txt` — PDF compilation/render inspection receipt.
- `SHA256SUMS` — cryptographic inventory of package files.

## Central declarations

```lean
def contender_26 : Nat := F26 (F26 42)

theorem contender_25_lt_contender_26 :
  contender_25 < contender_26
```

No file evaluates `contender_26`.
