import BusyLean.SecondOrderHyperReflection
import BusyLean.Contender25

/-!
# Contender 26: W2-ranked hyperreflection over Contender 25

```
family25 n    := F25 (F25 n)
seedLift26 n  := wDiagonalLift (schedule25 (family25 n))
                              (rank25 (family25 n))
finalLift26 n := w2DiagonalLift (schedule26 n) (rank26 n) (seedLift26 n)
F26 n         := finalLift26 n aTransformer (fun _ => family25) n n
contender_26  := F26 (F26 42)
```

Contender 25 uses the address language over collapsed tree ordinals and a
W-ranked hierarchy at

    TransformerLift = Transformer -> Transformer.

This construction retains that strongest integrated language and raises the
amplifier one full operator type:

    HyperLift = TransformerLift -> TransformerLift.

The second-order hierarchy is itself W-tree-ranked. Its seed at input `n` is
Contender 25's W-ranked amplifier evaluated at the much larger input
`family25 n`. The outer schedule and rank are autonomous notations stacked
above the incumbent rank at that amplified input.

**Do not evaluate `contender_26`.**
-/

namespace BusyLean

open BigNumber (WTree)
open BusyLean.W

/-- Contender 25 as a function of its input; `family25 42 = contender_25`. -/
def family25 (n : Nat) : Nat := F25 (F25 n)

/-- One autonomous jump, with height controlled by Contender 25's family. -/
def advance26 (n : Nat) (a : WTree Nat) : WTree Nat :=
  Autonomous.realize
    (Autonomous.hyper (family25 n + 42) (Autonomous.encode a))

/-- The incumbent W-ranked lift, moved to the self-amplified input. -/
def seedLift26 (n : Nat) : TransformerLift :=
  wDiagonalLift (schedule25 (family25 n)) (rank25 (family25 n))

/-- The second-order schedule starts above the incumbent rank at the amplified
input. -/
def schedule26 (n : Nat) : WTree Nat :=
  advance26 n (rank25 (family25 n))

/-- The second-order rank is another autonomous jump above its schedule. -/
def rank26 (n : Nat) : WTree Nat :=
  advance26 n (schedule26 n)

/-- The final transformer lift after W2-ranked hyperreflection. -/
def finalLift26 (n : Nat) : TransformerLift :=
  w2DiagonalLift (schedule26 n) (rank26 n) (seedLift26 n)

/-- The input-indexed family underlying Contender 26. -/
def F26 (n : Nat) : Nat :=
  finalLift26 n aTransformer (fun _ => family25) n n

/-- **Contender 26.** Never evaluate it. -/
def contender_26 : Nat := F26 (F26 42)

end BusyLean
