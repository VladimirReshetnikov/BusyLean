import BusyLean.SecondOrderHyperReflection
import BusyLean.TreeHyperReflectionFacts

/-!
# Growth theorems for second-order W-ranked hyperreflection

The proof discipline is the same as in `TreeHyperReflectionFacts`: no
monotonicity in oracle families is assumed.  Such monotonicity is false because
reflected programs may inspect and branch on oracle values.  Every inequality
below follows an explicit occurrence of a base object, a selected splice
coordinate, or a visible W-tree child.
-/

namespace BusyLean

open BigNumber (WTree)
open BusyLean.W

/-- The two properties required of a transformer lift. -/
def AdmissibleLift (lift : TransformerLift) : Prop :=
  PreservesProgressive lift ∧ StrictlyInflationary lift

/-- A hyperlift maps admissible lifts to admissible lifts. -/
def PreservesAdmissible (hyper : HyperLift) : Prop :=
  forall lift : TransformerLift,
    AdmissibleLift lift -> AdmissibleLift (hyper lift)

/-- A hyperlift strictly exceeds its input lift, pointwise at every progressive
base transformer and every visible numerical coordinate. -/
def StrictlyInflationaryHyper (hyper : HyperLift) : Prop :=
  forall lift : TransformerLift, AdmissibleLift lift ->
    forall base : Transformer, Progressive base ->
      forall (seed : Family) (i o n : Nat), i <= n ->
        lift base seed i n < hyper lift base seed o n

/-- Splicing admissible lifts produces an admissible lift. -/
theorem spliceLifts_admissible {lifts : Nat -> TransformerLift}
    (hlifts : forall i, AdmissibleLift (lifts i)) :
    AdmissibleLift (spliceLifts lifts) := by
  constructor
  · exact spliceLifts_preservesProgressive (fun i => (hlifts i).1)
  · exact spliceLifts_strictlyInflationary (fun i => (hlifts i).2)

/-- The autonomous higher-type step preserves admissibility. -/
theorem liftTransformerLift_preservesAdmissible :
    PreservesAdmissible liftTransformerLift := by
  intro lift hlift
  constructor
  · intro base hbase
    change Progressive (stageLift lift (lift base) index)
    exact stageLift_progressive lift hlift.1
      (lift base) (hlift.1 base hbase) index
  · intro base hbase seed i o n hi
    change base seed i n < stageLift lift (lift base) index seed o n
    have hfirst : base seed i n < lift base seed i n :=
      hlift.2 base hbase seed i i n hi
    have hsecond : lift base seed i n <
        stageLift lift (lift base) index seed o n :=
      base_lt_stageLift lift hlift.1 hlift.2
        (lift base) (hlift.1 base hbase) index seed i o n hi
    exact Nat.lt_trans hfirst hsecond

/-- The autonomous higher-type step strictly exceeds its input lift. -/
theorem liftTransformerLift_strictlyInflationary :
    StrictlyInflationaryHyper liftTransformerLift := by
  intro lift hlift base hbase seed i o n hi
  change lift base seed i n < stageLift lift (lift base) index seed o n
  exact base_lt_stageLift lift hlift.1 hlift.2
    (lift base) (hlift.1 base hbase) index seed i o n hi

/-- Splicing hyperlifts preserves admissibility when every component does. -/
theorem spliceHyperLifts_preservesAdmissible
    {hypers : Nat -> HyperLift}
    (hhypers : forall i, PreservesAdmissible (hypers i)) :
    PreservesAdmissible (spliceHyperLifts hypers) := by
  intro base hbase
  change AdmissibleLift (spliceLifts (fun i => hypers i base))
  exact spliceLifts_admissible (fun i => hhypers i base hbase)

/-- Splicing strictly inflationary hyperlifts is strictly inflationary.

Output coordinate `o` selects component `o`; no comparison between distinct
components and no oracle monotonicity are needed.
-/
theorem spliceHyperLifts_strictlyInflationary
    {hypers : Nat -> HyperLift}
    (hhypers : forall i, StrictlyInflationaryHyper (hypers i)) :
    StrictlyInflationaryHyper (spliceHyperLifts hypers) := by
  intro lift hlift base hbase seed i o n hi
  change lift base seed i n < hypers o lift base seed 0 n
  exact hhypers o lift hlift base hbase seed i 0 n hi

/-- A hyperlift stage preserves admissibility. -/
theorem stageHyperLift_admissible (hyper : HyperLift)
    (hhyper : PreservesAdmissible hyper)
    (base : TransformerLift) (hbase : AdmissibleLift base) :
    (a : WTree Nat) -> AdmissibleLift (stageHyperLift hyper base a)
  | .leaf => hhyper base hbase
  | .node f => by
      apply hhyper
      exact spliceLifts_admissible
        (fun i => stageHyperLift_admissible hyper hhyper base hbase (f i))

/-- If the local hyperlift is strict, every higher-type tree stage strictly
exceeds its base lift.

The node case follows child zero, observes that this child is coordinate zero
of the splice, and then applies strictness of the parent hyperlift.
-/
theorem baseLift_lt_stageHyperLift (hyper : HyperLift)
    (hpres : PreservesAdmissible hyper)
    (hstrict : StrictlyInflationaryHyper hyper)
    (base : TransformerLift) (hbase : AdmissibleLift base) :
    (a : WTree Nat) -> forall (op : Transformer), Progressive op ->
      forall (seed : Family) (i o n : Nat), i <= n ->
        base op seed i n < stageHyperLift hyper base a op seed o n
  | .leaf, op, hop, seed, i, o, n, hi =>
      hstrict base hbase op hop seed i o n hi
  | .node f, op, hop, seed, i, o, n, hi => by
      have hchild :
          base op seed i n <
            stageHyperLift hyper base (f 0) op seed 0 n :=
        baseLift_lt_stageHyperLift hyper hpres hstrict base hbase
          (f 0) op hop seed i 0 n hi
      let lower : TransformerLift :=
        spliceLifts (fun j => stageHyperLift hyper base (f j))
      have hlower : AdmissibleLift lower := by
        apply spliceLifts_admissible
        intro j
        exact stageHyperLift_admissible hyper hpres base hbase (f j)
      have hparent : lower op seed 0 n < hyper lower op seed o n :=
        hstrict lower hlower op hop seed 0 o n (Nat.zero_le n)
      change stageHyperLift hyper base (f 0) op seed 0 n <
        stageHyperLift hyper base (.node f) op seed o n at hparent
      exact Nat.lt_trans hchild hparent

/-- Every W2 rank preserves admissibility. -/
theorem w2DiagonalLift_preservesAdmissible (schedule : WTree Nat) :
    (rank : WTree Nat) ->
      PreservesAdmissible (w2DiagonalLift schedule rank)
  | .leaf => liftTransformerLift_preservesAdmissible
  | .node f => by
      let lower : HyperLift :=
        spliceHyperLifts (fun i => w2DiagonalLift schedule (f i))
      have hlower : PreservesAdmissible lower := by
        apply spliceHyperLifts_preservesAdmissible
        intro i
        exact w2DiagonalLift_preservesAdmissible schedule (f i)
      intro base hbase
      change AdmissibleLift (stageHyperLift lower (lower base) schedule)
      exact stageHyperLift_admissible lower hlower
        (lower base) (hlower base hbase) schedule

/-- Every W2 rank strictly exceeds its original base lift. -/
theorem w2DiagonalLift_strictlyInflationary (schedule : WTree Nat) :
    (rank : WTree Nat) ->
      StrictlyInflationaryHyper (w2DiagonalLift schedule rank)
  | .leaf => liftTransformerLift_strictlyInflationary
  | .node f => by
      let lower : HyperLift :=
        spliceHyperLifts (fun i => w2DiagonalLift schedule (f i))
      have hlowerPres : PreservesAdmissible lower := by
        apply spliceHyperLifts_preservesAdmissible
        intro i
        exact w2DiagonalLift_preservesAdmissible schedule (f i)
      have hlowerStrict : StrictlyInflationaryHyper lower := by
        apply spliceHyperLifts_strictlyInflationary
        intro i
        exact w2DiagonalLift_strictlyInflationary schedule (f i)
      intro base hbase op hop seed i o n hi
      change base op seed i n <
        stageHyperLift lower (lower base) schedule op seed o n
      have hfirst : base op seed i n < lower base op seed i n :=
        hlowerStrict base hbase op hop seed i i n hi
      have hbase' : AdmissibleLift (lower base) :=
        hlowerPres base hbase
      have hsecond : lower base op seed i n <
          stageHyperLift lower (lower base) schedule op seed o n :=
        baseLift_lt_stageHyperLift lower hlowerPres hlowerStrict
          (lower base) hbase' schedule op hop seed i o n hi
      exact Nat.lt_trans hfirst hsecond

/-- Every visible child W2 rank is strictly below its parent rank. -/
theorem w2DiagonalLift_child_lt (schedule : WTree Nat)
    (f : Nat -> WTree Nat)
    (base : TransformerLift) (hbase : AdmissibleLift base)
    (op : Transformer) (hop : Progressive op)
    (seed : Family) {i o n : Nat} (hi : i <= n) :
    w2DiagonalLift schedule (f i) base op seed 0 n <
      w2DiagonalLift schedule (.node f) base op seed o n := by
  let lower : HyperLift :=
    spliceHyperLifts (fun j => w2DiagonalLift schedule (f j))
  have hlowerPres : PreservesAdmissible lower := by
    apply spliceHyperLifts_preservesAdmissible
    intro j
    exact w2DiagonalLift_preservesAdmissible schedule (f j)
  have hlowerStrict : StrictlyInflationaryHyper lower := by
    apply spliceHyperLifts_strictlyInflationary
    intro j
    exact w2DiagonalLift_strictlyInflationary schedule (f j)
  have hbase' : AdmissibleLift (lower base) :=
    hlowerPres base hbase
  change lower base op seed i n <
    stageHyperLift lower (lower base) schedule op seed o n
  exact baseLift_lt_stageHyperLift lower hlowerPres hlowerStrict
    (lower base) hbase' schedule op hop seed i o n hi

end BusyLean
