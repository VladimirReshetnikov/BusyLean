import BusyLean.TreeHyperReflection

/-!
# Second-order W-ranked hyperreflection

Contender 25 builds a W-tree-indexed hierarchy of transformer lifts:

    TransformerLift = Transformer -> Transformer.

This module raises the construction by one full operator type.  A `HyperLift`
acts on transformer lifts.  Its autonomous base operation uses a transformer
lift both to pre-amplify a transformer and as the local operation along the
repository's universal W-tree `index`.  The W-ranked diagonal construction then
recurses over an arbitrary rank tree exactly one type level above
`wDiagonalLift`.

All definitions are structural and executable.  This file uses no axioms,
noncomputable definitions, partial functions, unsafe code, or external
implementations.
-/

namespace BusyLean

open BigNumber (WTree)
open BusyLean.W

/-- An operator on transformer lifts. -/
abbrev HyperLift := TransformerLift -> TransformerLift

/-- One autonomous diagonal step at the level of transformer lifts.

The input lift first amplifies the base transformer.  The same lift is then
used at every node of the universal schedule `index`.  This is the exact
higher-type analogue of one successor step of `diagonalLift`.
-/
def liftTransformerLift (lift : TransformerLift) : TransformerLift :=
  fun base => stageLift lift (lift base) index

/-- Assemble a countable family of hyperlifts into one hyperlift.

After a base lift is supplied, output coordinate `i` selects hyperlift `i`
through `spliceLifts`.
-/
def spliceHyperLifts (hypers : Nat -> HyperLift) : HyperLift :=
  fun base => spliceLifts (fun i => hypers i base)

/-- Traverse a W-tree using an arbitrary operation on transformer lifts. -/
def stageHyperLift (hyper : HyperLift) (base : TransformerLift) :
    WTree Nat -> TransformerLift
  | .leaf => hyper base
  | .node f =>
      hyper (spliceLifts (fun i => stageHyperLift hyper base (f i)))

/-- W-ranked diagonal hyperreflection one operator type above `wDiagonalLift`.

A leaf performs one autonomous diagonal step on transformer lifts.  At a node,
all child-rank hyperlifts are spliced into `lower`.  The parent uses `lower`
both to pre-amplify the base lift and as the local operation along `schedule`.
-/
def w2DiagonalLift (schedule : WTree Nat) : WTree Nat -> HyperLift
  | .leaf => liftTransformerLift
  | .node f =>
      let lower : HyperLift :=
        spliceHyperLifts (fun i => w2DiagonalLift schedule (f i))
      fun base => stageHyperLift lower (lower base) schedule

end BusyLean
