import BusyLean.Contender26
import BusyLean.SecondOrderHyperReflectionFacts
import BusyLean.Comparison25

/-! # Contender 26: comparison theorems -/

namespace BusyLean

open BusyLean.W

/-- The incumbent W-ranked lift is admissible at every amplified input. -/
theorem seedLift26_admissible (n : Nat) :
    AdmissibleLift (seedLift26 n) := by
  constructor
  · exact wDiagonalLift_preservesProgressive
      (schedule25 (family25 n)) (rank25 (family25 n))
  · exact wDiagonalLift_strictlyInflationary
      (schedule25 (family25 n)) (rank25 (family25 n))

/-- The W2-ranked result is an admissible transformer lift. -/
theorem finalLift26_admissible (n : Nat) :
    AdmissibleLift (finalLift26 n) :=
  (w2DiagonalLift_preservesAdmissible (schedule26 n) (rank26 n))
    (seedLift26 n) (seedLift26_admissible n)

/-- The new second-order amplifier strictly exceeds its Contender-25-level
seed lift, pointwise over every progressive base transformer. -/
theorem seedLift26_lt_finalLift26 (n : Nat)
    (base : Transformer) (hbase : Progressive base)
    (seed : Family) {i o m : Nat} (hi : i <= m) :
    seedLift26 n base seed i m < finalLift26 n base seed o m :=
  (w2DiagonalLift_strictlyInflationary (schedule26 n) (rank26 n))
    (seedLift26 n) (seedLift26_admissible n)
    base hbase seed i o m hi

/-- At every input, `F26` exceeds Contender 25's entire self-composed family. -/
theorem family25_lt_F26 (n : Nat) : family25 n < F26 n := by
  exact ((finalLift26_admissible n).1
    aTransformer aTransformer_progressive)
    (fun _ => family25) 0 n n (Nat.zero_le n)

/-- The incumbent family itself is pointwise below the new family. -/
theorem F25_lt_F26 (n : Nat) : F25 n < F26 n :=
  Nat.lt_trans (input_lt_F25 (F25 n)) (family25_lt_F26 n)

/-- One raw address-language reflection step is below `F26`. -/
theorem raw_reflection_lt_F26 (n : Nat) :
    reflectAFamily (fun _ => family25) n < F26 n := by
  exact (finalLift26_admissible n).2
    aTransformer aTransformer_progressive
    (fun _ => family25) n n n (Nat.le_refl n)

/-- Every address-language program visible at input `n` is below `F26 n`. -/
theorem avalue_lt_F26 {n : Nat}
    {t : FL.CTm (Ordinal.Addr (Ordinal.bigTree n))}
    (ht : t ∈ FL.addrLadderUpTo n) :
    FL.avalue n (packFamily (fun _ => family25)) n t < F26 n :=
  Nat.lt_trans
    (avalue_lt_reflectAFamily (fun _ => family25) ht)
    (raw_reflection_lt_F26 n)

/-- The input is below Contender 25's self-composed family. -/
theorem input_lt_family25 (n : Nat) : n < family25 n :=
  Nat.lt_trans (input_lt_F25 n) (input_lt_F25 (F25 n))

/-- The new family is strictly inflationary in its numerical input. -/
theorem input_lt_F26 (n : Nat) : n < F26 n :=
  Nat.lt_trans (input_lt_family25 n) (family25_lt_F26 n)

/-- **Required comparison:** the live repository contender is strictly smaller
than Contender 26. -/
theorem contender_25_lt_contender_26 : contender_25 < contender_26 :=
  Nat.lt_trans (family25_lt_F26 42) (input_lt_F26 (F26 42))

/-- Consequently every earlier integrated contender is also smaller. -/
theorem contender_24_lt_contender_26 : contender_24 < contender_26 :=
  Nat.lt_trans contender_24_lt_contender_25 contender_25_lt_contender_26

end BusyLean
