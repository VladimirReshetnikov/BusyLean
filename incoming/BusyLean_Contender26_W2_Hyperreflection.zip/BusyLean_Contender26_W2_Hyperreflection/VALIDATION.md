# Validation status

## Completed in the artifact environment

1. The live repository baseline was re-read after it changed twice during the
   work. The final package targets commit
   `c2f81dcb0f59d6cab513dc36fd9f1a1c17ff1516`, whose integrated incumbent is
   Contender 25.
2. The proposal was checked against the current interfaces of
   `Contender25.lean`, `Comparison25.lean`, `wDiagonalLift`, `stageLift`,
   `PreservesProgressive`, `StrictlyInflationary`, `aTransformer_progressive`,
   `avalue_lt_reflectAFamily`, and `input_lt_F25`.
3. `scripts/check_package.py` passed its static checks:
   - required-file inventory;
   - forbidden-token scan over the four library modules;
   - direct-incumbent-constant scan;
   - basic delimiter-corruption check;
   - required-theorem inventory.
4. The integration patch was tested with `git apply --check` against a
   synthetic tree containing the exact baseline `BusyLean.lean` import list.
5. The LaTeX article compiled successfully to PDF.
6. The PDF was rendered to page images and visually inspected for clipping,
   overlap, missing glyphs, and broken listings.
7. SHA-256 checksums were generated for the final package.

## Not completed in this environment

Lean and Lake were not installed, and external network access from the build
container was unavailable. Therefore the four proposed library files were
**not** elaborated by Lean 4.34.0 here. No claim of kernel validation, exact
axiom output, build timing, or dependency-closure audit is made.

The proof architecture follows accepted BusyLean modules one operator type
higher and is designed to avoid oracle monotonicity, but a maintainer should
treat kernel elaboration as the remaining gate.

## Required maintainer commands

From a BusyLean checkout at the recorded baseline after applying the patch:

```bash
lake env lean BusyLean/SecondOrderHyperReflection.lean
lake env lean BusyLean/SecondOrderHyperReflectionFacts.lean
lake env lean BusyLean/Contender26.lean
lake env lean BusyLean/Comparison26.lean
lake env lean test/Contender26Audit.lean
python scripts/check.py
```

The expected key statement is:

```lean
#check @BusyLean.contender_25_lt_contender_26
```

The contender must never be evaluated.
