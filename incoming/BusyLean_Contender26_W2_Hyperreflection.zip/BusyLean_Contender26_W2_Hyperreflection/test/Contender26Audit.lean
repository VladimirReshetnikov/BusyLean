import BusyLean.Comparison26

/-!
Run after integrating the four library modules and imports:

    lake env lean test/Contender26Audit.lean

The expected axiom footprint should match the repository's current accepted
footprint (`propext` and `Quot.sound`, inherited through normalization
machinery). The contender itself must not be evaluated.
-/

#print axioms BusyLean.contender_26
#print axioms BusyLean.contender_25_lt_contender_26
#print axioms BusyLean.family25_lt_F26
#print axioms BusyLean.F25_lt_F26
#print axioms BusyLean.avalue_lt_F26
#print axioms BusyLean.w2DiagonalLift_preservesAdmissible
#print axioms BusyLean.w2DiagonalLift_strictlyInflationary
#print axioms BusyLean.w2DiagonalLift_child_lt

#check @BusyLean.contender_25_lt_contender_26
#check @BusyLean.seedLift26_lt_finalLift26
#check @BusyLean.family25_lt_F26
#check @BusyLean.F25_lt_F26
#check @BusyLean.avalue_lt_F26
#check @BusyLean.w2DiagonalLift_preservesAdmissible
#check @BusyLean.w2DiagonalLift_strictlyInflationary
#check @BusyLean.w2DiagonalLift_child_lt
