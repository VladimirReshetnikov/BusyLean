# BusyLean baseline

- Repository: `VladimirReshetnikov/BusyLean`
- Inspection date: 2026-10-13
- Baseline commit: `0005b3026f4c6c346dab5ee22a34ce6f4237428b`
- Lean toolchain: `leanprover/lean4:v4.34.0`
- Aggregator terminus: `BusyLean.Contender53`, `BusyLean.Comparison53`
- Incumbent source SHA: `85fa792d1d2b6c71b3cdea03da802fde6ef16e35`
- Comparison source SHA: `2ea8f91b04ed97fca3d32d49144522cd81903325`
- The two commits after the original code snapshot added only archives under `incoming/`; `BusyLean.lean`, `Contender53.lean`, and `Comparison53.lean` remain unchanged.

## Incumbent schematic

```lean
def family52 (n : Nat) : Nat := F52 (F52 n)

def F53 (n : Nat) : Nat :=
  Ordinal.hier
    (reflAlong (stackTree (family52 n)) family52
      (stackTree (family52 n)))
    (stackTree (family52 n)) (family52 n)

def contender_53 : Nat := F53 (F53 42)
```

`Comparison53.lean` proves `input_lt_F53` and
`contender_52_lt_contender_53`.  Contender 54 uses only `input_lt_F53` as its
incumbent interface.

The file `research/baseline/BusyLean.lean` is a captured copy of the baseline
aggregator used for patch validation.  It is included for audit convenience,
not as a replacement for the repository.
