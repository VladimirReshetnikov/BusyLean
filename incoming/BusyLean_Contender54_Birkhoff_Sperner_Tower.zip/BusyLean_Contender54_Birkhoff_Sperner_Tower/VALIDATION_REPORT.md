# Validation report

## Status summary

| Check | Status | Evidence |
|---|---:|---|
| Independent mathematical reference model | PASS | `reports/reference_model.txt` |
| Small Boolean/Dedekind values | PASS | `M(0..4)=2,3,6,20,168` |
| Forbidden-token audit | PASS | `reports/static_check.txt` |
| Independent-engine dependency audit | PASS | `reports/static_check.txt` |
| Full source patch dry run/application | PASS | `reports/patch_check.txt` |
| LaTeX compilation | PASS | `reports/latex_build.txt` |
| Unresolved references / overfull boxes | PASS (none) | final `.log` audit |
| PDF metadata/text extraction | PASS | `reports/pdfinfo.txt`, `reports/article_text.txt` |
| All-page PDF rendering | PASS | `rendered/page-01.png` … `page-15.png` |
| Lean 4.34.0 kernel build | NOT RUN | toolchain unavailable in container |

## Reference model

The Python model uses predecessor bit masks, not the Lean list representation.
It checks the same mathematical transition through an independent encoding.
Assertions cover the first two completion stages through seed size four, exact
width of the first completion, and the two smallest autonomous lifts.

## Static audit limits

The static checker is intentionally labeled as such.  It checks source-level
invariants and obvious escape hatches, but it cannot establish Lean syntax,
type correctness, termination acceptance, or theorem checking.  Only the Lean
kernel can do that.

## Kernel-build disclosure

The container had no `lean`, `lake`, or `elan` executable.  Direct network
installation was unavailable.  Accordingly, no kernel-compilation claim is
made.  `scripts/build_overlay.sh` is the required final integration test in an
environment with the repository's pinned toolchain.

## PDF inspection

The final document has 15 letter-sized pages.  All pages were rendered to PNG
and inspected as a contact sheet, with detailed inspection of the title page,
construction diagram/code page, novelty table, and bibliography/artifact map.
The final LaTeX log contains no overfull box or unresolved-reference warning.
