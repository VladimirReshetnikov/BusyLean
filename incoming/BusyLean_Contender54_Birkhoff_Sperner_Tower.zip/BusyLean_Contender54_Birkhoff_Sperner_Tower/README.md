# BusyLean Contender 54 — Self-Indexed Birkhoff–Sperner Ideal Tower

This research package proposes a new computable-in-principle large number for
`VladimirReshetnikov/BusyLean`, baseline commit
`0005b3026f4c6c346dab5ee22a34ce6f4237428b` (inspected 2026-10-13).
The checked-in incumbent at that baseline is Contender 53.

## Construction

For a finite poset `P`, let `J(P)` be the poset of all order ideals of `P`,
ordered by inclusion.  Starting with the `n`-element antichain `A_n`, define

```text
T_0(n)     = A_n
T_(r+1)(n) = J(T_r(n))
t_r(n)     = |T_r(n)|
β_BS(n)    = 1 + n + t_(n+2)(n)
```

The first completion is the Boolean lattice (`t_1(n)=2^n`); the second has
Dedekind-number cardinality (`t_2(n)=M(n)`).  Later stages preserve the full
comparability relation, so this is not scalar iteration of `M`.

With `family53 n := F53 (F53 n)`, the proposal is

```lean
def F54 (n : Nat) : Nat :=
  natIterate birkhoffSpernerLift
    (Nat.succ (family53 n)) (family53 n)

def contender_54 : Nat := F54 (F54 42)
```

The supplied theorem chain is designed to establish
`contender_53 < contender_54` without assuming monotonicity of `F53`.

## Why the amplifier is independent

`lean/BusyLean/FiniteIdeals.lean` imports no BusyLean module and contains no
reference to `F53`, any contender, ordinal trees, reflection, syntax/program
enumeration, semantic truth, or an oracle.  It uses only total structural
recursion on naturals and lists.  The incumbent supplies a numerical seed and
iteration budget, not the growth mechanism.

## Package map

- `article/contender54_birkhoff_sperner_tower.tex` — full research article.
- `article/contender54_birkhoff_sperner_tower.pdf` — compiled 15-page PDF.
- `lean/BusyLean/FiniteIdeals.lean` — executable finite-poset engine.
- `lean/BusyLean/Contender54.lean` — contender definitions.
- `lean/BusyLean/Comparison54.lean` — strict comparison chain.
- `lean/test/AntichainSmoke.lean` — exact small evaluations.
- `lean/test/Audit54.lean` — theorem and axiom checks.
- `scripts/reference_model.py` — independent bit-mask implementation.
- `scripts/static_check.py` — source/novelty/escape-hatch audit.
- `scripts/build_overlay.sh` — copy, build, smoke-test, and theorem-audit script.
- `patches/integration.patch` — full Git-style source patch.
- `research/` — baseline, novelty, and growth notes.
- `reports/` — captured validation outputs.
- `SHA256SUMS.txt` — integrity manifest.

## Validation status

Completed:

1. Independent exact model reproduces `2, 3, 6, 20, 168` at the second
   ideal-completion stage for seed sizes `0` through `4`.
2. Static audit rejects `axiom`, `sorry`, `admit`, `unsafe`, `partial`,
   `noncomputable`, `Classical.choice`, and `native_decide`.
3. The full patch applies cleanly to the captured 139-line baseline aggregator.
4. LaTeX compilation, PDF metadata inspection, text extraction, and all-page
   rendering succeeded without overfull boxes or unresolved references.

Outstanding:

- The current container did not include Lean 4.34.0, `lake`, or `elan`, and had
  no network route for installing them.  No Lean kernel-build claim is made.
  Run the overlay script in a checkout with the repository toolchain installed.

## Reproduction

```bash
python3 scripts/reference_model.py
python3 scripts/static_check.py
scripts/build_overlay.sh /path/to/BusyLean
```

The final command mutates the supplied checkout by copying three source modules
and appending three imports to `BusyLean.lean`; use a disposable branch.
