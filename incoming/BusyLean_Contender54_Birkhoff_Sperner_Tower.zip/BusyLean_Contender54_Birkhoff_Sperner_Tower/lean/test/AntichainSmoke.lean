import BusyLean.FiniteIdeals

open BusyLean.FiniteIdeals

-- Exact small values.  The second completion gives the Dedekind numbers.
#eval towerCard 0 0  -- 0
#eval towerCard 1 0  -- 1
#eval towerCard 2 0  -- 2
#eval towerCard 1 1  -- 2
#eval towerCard 2 1  -- 3
#eval towerCard 1 2  -- 4
#eval towerCard 2 2  -- 6
#eval towerCard 1 3  -- 8
#eval towerCard 2 3  -- 20

#eval birkhoffSpernerLift 0  -- 3
#eval birkhoffSpernerLift 1  -- 6
