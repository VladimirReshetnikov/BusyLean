import BusyLean.Comparison54

#check BusyLean.FiniteIdeals.idealCompletion
#check BusyLean.FiniteIdeals.birkhoffSpernerLift
#check BusyLean.F54
#check BusyLean.contender_54
#check BusyLean.family53_lt_F54
#check BusyLean.contender_53_lt_contender_54

#print axioms BusyLean.input_lt_birkhoffSpernerLift
#print axioms BusyLean.family53_lt_F54
#print axioms BusyLean.contender_53_lt_contender_54
