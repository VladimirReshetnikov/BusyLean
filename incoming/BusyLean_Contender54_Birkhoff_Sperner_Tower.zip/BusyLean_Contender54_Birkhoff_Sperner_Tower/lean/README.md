# Lean overlay layout

Copy the three files in `BusyLean/` into the repository's `BusyLean/`
directory and append these imports to the root `BusyLean.lean`:

```lean
import BusyLean.FiniteIdeals
import BusyLean.Contender54
import BusyLean.Comparison54
```

The two files in `test/` are standalone commands to run with `lake env lean`.
The archive-level script `scripts/build_overlay.sh` performs these steps and
then runs the library build, small evaluations, and `#print axioms` checks.

The intended repository toolchain is Lean 4.34.0.  The sources were statically
audited but not kernel-compiled in the package-generation container because the
Lean toolchain was unavailable there.
