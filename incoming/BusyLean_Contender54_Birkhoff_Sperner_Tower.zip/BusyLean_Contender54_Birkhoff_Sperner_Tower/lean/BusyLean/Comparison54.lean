import BusyLean.Contender54
import BusyLean.Comparison53
import BigNumber.Proofs

/-! # Contender 54: strict comparison theorems -/

namespace BusyLean

open FiniteIdeals

/-- The autonomous lift strictly increases every input. -/
theorem input_lt_birkhoffSpernerLift (n : Nat) :
    n < birkhoffSpernerLift n := by
  unfold birkhoffSpernerLift
  exact Nat.lt_succ_of_le
    (BigNumber.le_add n (towerCard (Nat.succ (Nat.succ n)) n))

/-- A positive number of iterations of a strictly inflationary map increases. -/
theorem input_lt_natIterate_succ (f : Nat → Nat)
    (hf : ∀ x, x < f x) :
    ∀ k x, x < natIterate f (Nat.succ k) x
  | 0, x => hf x
  | Nat.succ k, x =>
      Nat.lt_trans (hf x) (input_lt_natIterate_succ f hf k (f x))

/-- The doubled Contender-53 family is inflationary. -/
theorem input_lt_family53 (n : Nat) : n < family53 n := by
  unfold family53
  exact Nat.lt_trans (input_lt_F53 n) (input_lt_F53 (F53 n))

/-- At every input, `F54` exceeds the doubled Contender-53 family. -/
theorem family53_lt_F54 (n : Nat) : family53 n < F54 n := by
  unfold F54
  exact input_lt_natIterate_succ
    birkhoffSpernerLift input_lt_birkhoffSpernerLift
    (family53 n) (family53 n)

/-- `F54` strictly exceeds its own input. -/
theorem input_lt_F54 (n : Nat) : n < F54 n :=
  Nat.lt_trans (input_lt_family53 n) (family53_lt_F54 n)

/-- **Required comparison:** Contender 53 is strictly smaller than Contender 54. -/
theorem contender_53_lt_contender_54 : contender_53 < contender_54 :=
  Nat.lt_trans (family53_lt_F54 42) (input_lt_F54 (F54 42))

/-- Hence the previous two incumbents are also strictly below Contender 54. -/
theorem contender_52_lt_contender_54 : contender_52 < contender_54 :=
  Nat.lt_trans contender_52_lt_contender_53 contender_53_lt_contender_54

end BusyLean
