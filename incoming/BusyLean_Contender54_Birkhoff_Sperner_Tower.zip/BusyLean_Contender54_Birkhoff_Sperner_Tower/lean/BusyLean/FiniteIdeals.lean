/-!
# Executable finite ideal completion

A deliberately small, dependency-free implementation of finite posets and their
lattices of order ideals.  The carrier of a finite poset is represented by the
initial segment `0, ..., card - 1`; the relation is a Boolean program.

Every definition is total and executable.  In particular, there is no use of
`noncomputable`, `unsafe`, `partial`, an axiom, or classical choice.
-/

namespace BusyLean.FiniteIdeals

/-- Boolean equality on natural numbers, defined by structural recursion. -/
def eqNatB : Nat → Nat → Bool
  | 0, 0 => true
  | Nat.succ a, Nat.succ b => eqNatB a b
  | _, _ => false

/-- Boolean membership in a list of natural numbers. -/
def memNatB (x : Nat) : List Nat → Bool
  | [] => false
  | y :: ys => eqNatB x y || memNatB x ys

/-- Universal Boolean quantification over a finite list. -/
def allB {α : Type} (p : α → Bool) : List α → Bool
  | [] => true
  | x :: xs => p x && allB p xs

/-- Boolean filtering, kept local so the executable core uses only recursion. -/
def filterB {α : Type} (p : α → Bool) : List α → List α
  | [] => []
  | x :: xs =>
      match p x with
      | true => x :: filterB p xs
      | false => filterB p xs

/-- The consecutive list `start, ..., start + count - 1`. -/
def rangeFrom : Nat → Nat → List Nat
  | _, 0 => []
  | start, Nat.succ count => start :: rangeFrom (Nat.succ start) count

/-- The initial segment `0, ..., n - 1`. -/
def range (n : Nat) : List Nat := rangeFrom 0 n

/-- A defaulted list lookup, again defined without library dependencies. -/
def nthD {α : Type} : List α → Nat → α → α
  | [], _, fallback => fallback
  | x :: _, 0, _ => x
  | _ :: xs, Nat.succ i, fallback => nthD xs i fallback

/-- The list of all sublists, with no duplicated positions. -/
def powerset {α : Type} : List α → List (List α)
  | [] => [[]]
  | x :: xs =>
      let tailPowerset := powerset xs
      tailPowerset ++ tailPowerset.map (fun ys => x :: ys)

/-- Boolean inclusion for lists that encode finite subsets of naturals. -/
def subsetNatB (xs ys : List Nat) : Bool :=
  allB (fun x => memNatB x ys) xs

/-- Boolean implication. -/
def impliesB (a b : Bool) : Bool := (!a) || b

/--
A finite relation presentation.  Only indices below `card` are regarded as
carrier elements.  The construction is executable even before order laws are
proved; our seed is a genuine antichain, and ideal completion preserves the
intended order semantically.
-/
structure FPoset where
  card : Nat
  leB : Nat → Nat → Bool

/-- The `n`-element antichain. -/
def antichain (n : Nat) : FPoset where
  card := n
  leB := eqNatB

/-- Test whether a represented subset is a lower set (order ideal). -/
def isIdeal (P : FPoset) (xs : List Nat) : Bool :=
  allB
    (fun x =>
      allB
        (fun y => impliesB (P.leB y x && memNatB x xs) (memNatB y xs))
        (range P.card))
    (range P.card)

/-- Exhaustively enumerate all order ideals of a finite relation presentation. -/
def ideals (P : FPoset) : List (List Nat) :=
  filterB (isIdeal P) (powerset (range P.card))

/--
Replace `P` by its poset of order ideals, ordered by inclusion.  The elements
of the new carrier are indices into the exhaustively enumerated ideal list.
-/
def idealCompletion (P : FPoset) : FPoset :=
  let js := ideals P
  { card := js.length
    leB := fun i j => subsetNatB (nthD js i []) (nthD js j []) }

/-- Iterate ideal completion a prescribed finite number of times. -/
def iterateCompletion : Nat → FPoset → FPoset
  | 0, P => P
  | Nat.succ k, P => iterateCompletion k (idealCompletion P)

/-- Cardinality of the `k`th ideal-completion stage above an `n`-antichain. -/
def towerCard (k n : Nat) : Nat :=
  (iterateCompletion k (antichain n)).card

/-- Ordinary scalar iteration, with the iterate applied before the recursive call. -/
def natIterate (f : Nat → Nat) : Nat → Nat → Nat
  | 0, x => x
  | Nat.succ k, x => natIterate f k (f x)

/--
The autonomous Birkhoff--Sperner lift.  At input `n` it builds the ideal tower
of height `n + 2` above the `n`-antichain, adds its cardinality to `n`, and then
adds one.  The final successor is a proof-friendly guard; asymptotically the
order-ideal tower is the substantive term.
-/
def birkhoffSpernerLift (n : Nat) : Nat :=
  Nat.succ (n + towerCard (Nat.succ (Nat.succ n)) n)

end BusyLean.FiniteIdeals
