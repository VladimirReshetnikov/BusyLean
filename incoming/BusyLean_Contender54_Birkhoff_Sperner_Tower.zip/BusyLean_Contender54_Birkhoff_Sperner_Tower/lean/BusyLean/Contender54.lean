import BusyLean.Contender53
import BusyLean.FiniteIdeals

/-!
# Contender 54: self-indexed Birkhoff--Sperner ideal tower

The incumbent is used only to choose a seed and finite iteration budget.  The
amplifier itself is the independent executable finite-order construction in
`FiniteIdeals.lean`.
-/

namespace BusyLean

open FiniteIdeals

/-- The doubled Contender-53 family; at input 42 this is `contender_53`. -/
def family53 (n : Nat) : Nat := F53 (F53 n)

/--
Apply the autonomous Birkhoff--Sperner lift `family53 n + 1` times, starting at
`family53 n`.
-/
def F54 (n : Nat) : Nat :=
  natIterate birkhoffSpernerLift (Nat.succ (family53 n)) (family53 n)

/-- The submitted large number. -/
def contender_54 : Nat := F54 (F54 42)

end BusyLean
