# Manifest

## Primary deliverables

- `article/contender54_birkhoff_sperner_tower.tex`
- `article/contender54_birkhoff_sperner_tower.pdf`
- `lean/BusyLean/FiniteIdeals.lean`
- `lean/BusyLean/Contender54.lean`
- `lean/BusyLean/Comparison54.lean`
- `patches/integration.patch`

## Tests and reproducibility

- `lean/test/AntichainSmoke.lean`
- `lean/test/Audit54.lean`
- `scripts/reference_model.py`
- `scripts/static_check.py`
- `scripts/build_overlay.sh`

## Research documentation

- `README.md`
- `BASELINE.md`
- `VALIDATION_REPORT.md`
- `research/novelty_audit.md`
- `research/growth_notes.md`
- `research/baseline/BusyLean.lean`
- `patches/README_INSERT.md`

## Generated evidence

- `reports/reference_model.txt`
- `reports/static_check.txt`
- `reports/patch_check.txt`
- `reports/latex_build.txt`
- `reports/pdfinfo.txt`
- `reports/article_text.txt`
- `reports/pdf_render.txt`
- `rendered/contact-sheet.png`
- `rendered/page-01.png` through `rendered/page-15.png`
- `SHA256SUMS.txt`
