#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "usage: $0 /path/to/BusyLean-checkout" >&2
  exit 2
fi

REPO=$(cd "$1" && pwd)
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)

if [[ ! -f "$REPO/BusyLean.lean" || ! -f "$REPO/lakefile.toml" ]]; then
  echo "not a BusyLean checkout: $REPO" >&2
  exit 2
fi

cp "$HERE/lean/BusyLean/FiniteIdeals.lean" "$REPO/BusyLean/FiniteIdeals.lean"
cp "$HERE/lean/BusyLean/Contender54.lean" "$REPO/BusyLean/Contender54.lean"
cp "$HERE/lean/BusyLean/Comparison54.lean" "$REPO/BusyLean/Comparison54.lean"

for imp in \
  'import BusyLean.FiniteIdeals' \
  'import BusyLean.Contender54' \
  'import BusyLean.Comparison54'
do
  grep -qxF "$imp" "$REPO/BusyLean.lean" || printf '%s\n' "$imp" >> "$REPO/BusyLean.lean"
done

mkdir -p "$REPO/BusyLeanTest"
cp "$HERE/lean/test/AntichainSmoke.lean" "$REPO/BusyLeanTest/AntichainSmoke.lean"
cp "$HERE/lean/test/Audit54.lean" "$REPO/BusyLeanTest/Audit54.lean"

cd "$REPO"
echo "== lake build BusyLean =="
lake build BusyLean

echo "== smoke evaluation =="
lake env lean BusyLeanTest/AntichainSmoke.lean

echo "== theorem/axiom audit =="
lake env lean BusyLeanTest/Audit54.lean
