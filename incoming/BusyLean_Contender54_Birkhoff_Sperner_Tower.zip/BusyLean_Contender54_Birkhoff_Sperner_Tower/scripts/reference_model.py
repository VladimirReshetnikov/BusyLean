#!/usr/bin/env python3
"""Independent exact reference model for the finite ideal-completion core.

The implementation uses integer bit masks rather than the Lean list encoding.
Agreement on small instances therefore cross-checks the mathematical algorithm,
not merely a transliteration of the Lean source.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import comb
from typing import Iterable, Sequence


@dataclass(frozen=True)
class Poset:
    """Finite poset by predecessor masks: pred[x] = {y : y <= x}."""

    pred: tuple[int, ...]

    @property
    def card(self) -> int:
        return len(self.pred)


def antichain(n: int) -> Poset:
    if n < 0:
        raise ValueError("n must be nonnegative")
    return Poset(tuple(1 << i for i in range(n)))


def is_ideal(p: Poset, subset: int) -> bool:
    """A set is an ideal iff it contains every predecessor of each member."""
    for x, pred_x in enumerate(p.pred):
        if subset & (1 << x) and pred_x & ~subset:
            return False
    return True


def ideals(p: Poset) -> tuple[int, ...]:
    return tuple(s for s in range(1 << p.card) if is_ideal(p, s))


def ideal_completion(p: Poset) -> Poset:
    js = ideals(p)
    # In the inclusion order, predecessors of ideal j are ideals i subset j.
    preds: list[int] = []
    for j in js:
        mask = 0
        for i_index, i in enumerate(js):
            if i & ~j == 0:
                mask |= 1 << i_index
        preds.append(mask)
    return Poset(tuple(preds))


def iterate_completion(k: int, p: Poset) -> Poset:
    if k < 0:
        raise ValueError("k must be nonnegative")
    for _ in range(k):
        p = ideal_completion(p)
    return p


def tower_card(k: int, n: int) -> int:
    return iterate_completion(k, antichain(n)).card


def birkhoff_sperner_lift(n: int, *, max_card: int = 25) -> int:
    """Exact lift for tiny n; abort before infeasible powerset enumeration."""
    p = antichain(n)
    for stage in range(n + 2):
        if p.card > max_card:
            raise RuntimeError(
                f"stage {stage}: carrier size {p.card} exceeds exact-test cap {max_card}"
            )
        p = ideal_completion(p)
    return n + p.card + 1


def width_bruteforce(p: Poset) -> int:
    """Exact width for very small posets by exhaustive subset search."""
    n = p.card
    best = 0
    for s in range(1 << n):
        size = s.bit_count()
        if size <= best:
            continue
        members = [i for i in range(n) if s & (1 << i)]
        ok = True
        for a_pos, a in enumerate(members):
            for b in members[a_pos + 1 :]:
                a_le_b = bool(p.pred[b] & (1 << a))
                b_le_a = bool(p.pred[a] & (1 << b))
                if a_le_b or b_le_a:
                    ok = False
                    break
            if not ok:
                break
        if ok:
            best = size
    return best


def central_binomial_lower_orbit(n: int, steps: int) -> list[int]:
    values = [n]
    for _ in range(steps):
        w = values[-1]
        values.append(comb(w, w // 2))
    return values


def main() -> None:
    expected_stage1 = {0: 1, 1: 2, 2: 4, 3: 8, 4: 16}
    expected_stage2 = {0: 2, 1: 3, 2: 6, 3: 20, 4: 168}

    print("Independent finite-ideal-completion reference model")
    print("===================================================")
    print()
    print("k=1 gives Boolean-lattice cardinalities; k=2 gives Dedekind numbers.")
    print(" n | T_0 | T_1 | T_2 | expected T_2")
    print("---+-----+-----+-----+-------------")
    for n in range(5):
        t0 = tower_card(0, n)
        t1 = tower_card(1, n)
        t2 = tower_card(2, n)
        assert t0 == n
        assert t1 == expected_stage1[n]
        assert t2 == expected_stage2[n]
        print(f" {n} | {t0:3d} | {t1:3d} | {t2:3d} | {expected_stage2[n]:11d}")

    print()
    print("Exact autonomous lifts that remain small enough to execute:")
    lift0 = birkhoff_sperner_lift(0)
    lift1 = birkhoff_sperner_lift(1)
    assert lift0 == 3
    assert lift1 == 6
    print(f"  beta(0) = {lift0}")
    print(f"  beta(1) = {lift1}")

    print()
    print("Structural checks:")
    for n in range(5):
        p0 = antichain(n)
        p1 = ideal_completion(p0)
        assert p1.card == 1 << n
        if p1.card <= 16:
            width = width_bruteforce(p1)
            target = comb(n, n // 2)
            assert width == target
            print(
                f"  width(J(A_{n})) = {width} = binom({n}, floor({n}/2))"
            )

    print()
    orbit = central_binomial_lower_orbit(4, 3)
    print("Width lower-bound orbit from n=4:")
    print("  " + " -> ".join(map(str, orbit)))
    print()
    print("All reference assertions passed.")


if __name__ == "__main__":
    main()
