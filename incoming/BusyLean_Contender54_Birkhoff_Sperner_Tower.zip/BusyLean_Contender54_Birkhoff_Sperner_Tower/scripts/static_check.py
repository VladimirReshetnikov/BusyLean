#!/usr/bin/env python3
"""Static, dependency, and novelty audit for the Contender 54 overlay.

This does not replace Lean kernel checking.  It catches forbidden escape hatches,
accidental incumbent calls inside the independent engine, missing patch targets,
and several easy source-structure mistakes.
"""
from __future__ import annotations

from pathlib import Path
import hashlib
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
LEAN = ROOT / "lean" / "BusyLean"

FORBIDDEN = {
    "sorry": re.compile(r"\bsorry\b"),
    "admit": re.compile(r"\badmit\b"),
    "axiom": re.compile(r"\baxiom\b"),
    "unsafe": re.compile(r"\bunsafe\b"),
    "partial": re.compile(r"\bpartial\b"),
    "noncomputable": re.compile(r"\bnoncomputable\b"),
    "Classical.choice": re.compile(r"\bClassical\.choice\b"),
    "native_decide": re.compile(r"\bnative_decide\b"),
}

# Words excluded specifically from the independent amplifier source.  Comments
# are stripped first, so explanatory prose cannot create false positives.
ENGINE_FORBIDDEN = [
    "F53",
    "contender_53",
    "CTree",
    "reflect",
    "reflAlong",
    "hier",
    "oracle",
    "SystemFT",
    "PrimLanguage",
]


def strip_comments(text: str) -> str:
    # Adequate for this source: remove nested-looking block comments greedily by
    # repeated innermost elimination, then line comments.
    old = None
    while old != text:
        old = text
        text = re.sub(r"/-.*?-/", "", text, flags=re.S)
    text = re.sub(r"--.*", "", text)
    return text


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def main() -> int:
    errors: list[str] = []
    lean_files = sorted((ROOT / "lean").rglob("*.lean"))
    if not lean_files:
        errors.append("no Lean files found")

    for path in lean_files:
        source = path.read_text(encoding="utf-8")
        code = strip_comments(source)
        for label, pattern in FORBIDDEN.items():
            if pattern.search(code):
                errors.append(f"{path.relative_to(ROOT)} contains forbidden token {label}")
        if code.count("namespace ") < code.count("end "):
            errors.append(f"{path.relative_to(ROOT)} has more `end` tokens than namespaces")

    engine_path = LEAN / "FiniteIdeals.lean"
    engine = strip_comments(engine_path.read_text(encoding="utf-8"))
    for token in ENGINE_FORBIDDEN:
        if re.search(rf"\b{re.escape(token)}\b", engine):
            errors.append(f"independent engine mentions forbidden incumbent token {token}")
    if re.search(r"^\s*import\s+BusyLean\.", engine, flags=re.M):
        errors.append("independent engine imports another BusyLean module")

    comparison = (LEAN / "Comparison54.lean").read_text(encoding="utf-8")
    required_theorems = [
        "input_lt_birkhoffSpernerLift",
        "input_lt_natIterate_succ",
        "input_lt_family53",
        "family53_lt_F54",
        "input_lt_F54",
        "contender_53_lt_contender_54",
    ]
    for theorem in required_theorems:
        if not re.search(rf"\btheorem\s+{re.escape(theorem)}\b", comparison):
            errors.append(f"missing theorem {theorem}")

    contender = (LEAN / "Contender54.lean").read_text(encoding="utf-8")
    for definition in ["family53", "F54", "contender_54"]:
        if not re.search(rf"\bdef\s+{re.escape(definition)}\b", contender):
            errors.append(f"missing definition {definition}")

    patch = (ROOT / "patches" / "integration.patch")
    if patch.exists():
        patch_text = patch.read_text(encoding="utf-8")
        for import_name in [
            "BusyLean.FiniteIdeals",
            "BusyLean.Contender54",
            "BusyLean.Comparison54",
        ]:
            if f"+import {import_name}" not in patch_text:
                errors.append(f"integration patch omits {import_name}")

    print("Contender 54 static audit")
    print("==========================")
    print(f"root: {ROOT}")
    print(f"Lean files: {len(lean_files)}")
    for path in lean_files:
        print(f"  {sha256(path)}  {path.relative_to(ROOT)}")
    print()
    if errors:
        print("FAILED")
        for error in errors:
            print(f"  - {error}")
        return 1
    print("PASS")
    print("  no forbidden proof or execution escape hatches")
    print("  finite-ideal engine is independent of incumbent/reflection modules")
    print("  expected definitions and comparison theorem chain are present")
    print("  integration-patch imports are present when the patch exists")
    print()
    print("This is a static audit, not a Lean kernel build.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
