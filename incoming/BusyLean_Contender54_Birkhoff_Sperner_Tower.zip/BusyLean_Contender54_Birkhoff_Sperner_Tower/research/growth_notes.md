# Growth notes for the Birkhoff–Sperner tower

Let `J(P)` be the inclusion poset of order ideals of a finite poset `P`.
Let `A_n` be the `n`-element antichain, `T_0(n)=A_n`, and
`T_(r+1)(n)=J(T_r(n))`.

## Exact first stages

- `|T_0(n)| = n`.
- `T_1(n)` is the Boolean lattice `B_n`, so `|T_1(n)| = 2^n`.
- `|T_2(n)| = M(n)`, the Dedekind number.

## Antichain embedding lemma

For an antichain `A` in `P`, define

```text
Φ_A(S) = ↓S = {x : x ≤ a for some a in S},  S ⊆ A.
```

If `↓S ⊆ ↓T` and `s ∈ S`, then `s ≤ t` for some `t ∈ T`; antichainness forces
`s=t`, hence `s∈T`.  Thus `Φ_A` is an order embedding of the Boolean lattice
`2^A` into `J(P)`.

Writing `w(P)` for width, this gives

```text
|J(P)| ≥ 2^(w(P))
w(J(P)) ≥ binom(w(P), floor(w(P)/2)).
```

The second inequality uses the middle layer of the embedded Boolean lattice.

## Iterated lower-width orbit

Set

```text
a_0(n) = n
a_(r+1)(n) = binom(a_r(n), floor(a_r(n)/2)).
```

Then `width(T_r(n)) ≥ a_r(n)` and
`|T_(r+1)(n)| ≥ 2^(a_r(n))`.  For `n=4`, the lower-width orbit starts

```text
4 → 6 → 20 → 184756 → binom(184756, 92378) → ...
```

The elementary estimate

```text
binom(m, floor(m/2)) ≥ 2^m / (m+1)
```

shows that the logarithm of each new width is almost the previous width.

## Conservative one-stage lower bound

The submitted lift is

```text
β_BS(n) = 1 + n + |T_(n+2)(n)|.
```

Since ideal-completion cardinalities strictly increase for finite posets,

```text
β_BS(n) > |T_(n+2)(n)| ≥ |T_2(n)| = M(n)
        ≥ 2^(binom(n, floor(n/2))).
```

This discards `n` later ideal-completion stages and all but the first outer
application, so it is intentionally very conservative.

## Submitted self-indexing

With `S(n)=F53(F53(n))`,

```text
F54(n) = β_BS^[S(n)+1](S(n))
C54    = F54(F54(42)).
```

At `N=S(42)=C53`, the first application already computes an ideal tower of
height `N+2`; `F54(42)` performs `N+1` autonomous lifts at increasing inputs.
