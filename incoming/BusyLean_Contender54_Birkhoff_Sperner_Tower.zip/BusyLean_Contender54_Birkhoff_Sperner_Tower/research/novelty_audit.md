# Mechanism-level novelty audit

## Audit target

The independent engine is `lean/BusyLean/FiniteIdeals.lean`.  The question is
not whether the final natural number mentions the incumbent—it must compare to
the incumbent—but whether its substantive amplifier is independently defined.

## Negative dependency result

After stripping comments, the engine contains none of the following tokens:

- `F53`, `contender_53`, or any contender import;
- `CTree`, `hier`, `reflAlong`, `reflect`, or `oracle`;
- `SystemFT`, `PrimLanguage`, a syntax datatype, or a program evaluator;
- `axiom`, `sorry`, `admit`, `unsafe`, `partial`, `noncomputable`,
  `Classical.choice`, or `native_decide`.

The engine imports no `BusyLean.*` module.  Its state is an explicit finite
relation presentation `(card, leB)` and its transition enumerates lower sets.

## Repository search result

At the inspected baseline, repository searches found no code matches for
`antichain`, and no matches for the combined terms `Dedekind`, `Birkhoff`,
`idealCompletion`, or `isIdeal`.  Absence of a term is not by itself a proof of
mathematical novelty, but it supports the stronger architectural observation:
no existing contender uses iterated finite ideal lattices as its growth engine.

## Non-factorization argument

The transition retains genuine state.  Posets of the same cardinality can have
very different ideal counts:

- a `q`-element chain has `q+1` ideals;
- a `q`-element antichain has `2^q` ideals.

Therefore `P ↦ |J(P)|` does not factor through `|P|`.  The third and later
stages cannot be reconstructed by scalar Dedekind iteration alone.  This is the
central distinction from ordinary exponent towers or `n ↦ M(n)` iteration.

## Separation of roles

- `FiniteIdeals.lean`: independent order-theoretic amplifier.
- `Contender54.lean`: uses `family53 n` only as seed and finite counter.
- `Comparison54.lean`: proves strictness by arithmetic transitivity.

The final `+1+n` guard in `birkhoffSpernerLift` makes strict inflation trivial
to certify for all small inputs.  It is not the source of magnitude: the tower
term alone is already at least the Dedekind lower bound
`2^(binom(n, floor(n/2)))`.
