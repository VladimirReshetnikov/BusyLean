# Validation ledger

## Scope and pinned comparison target

This package targets the exact BusyLean repository state

`961ee2bbd8039dcf9832edd9d28272db8ba181ac`

where the accepted predecessor is Contender 49. The integration patch must be
replayed at that commit. A later repository head requires rebasing, renumbering,
and a fresh predecessor theorem.

The repository declares Lean `leanprover/lean4:v4.34.0`, a 15-second budget for
the new definition module, a 60-second budget for the remaining proof/library
build, and the permitted axiom set `{propext, Quot.sound}`.

## Completed checks

### 1. Source-integrity audit

Command:

```bash
python3 scripts/static_check50.py
```

Result:

```text
PASS: Contender 50 source-integrity checks completed
```

The checker verifies the presence of the intended semantic-resource pipeline,
two-pass reflection, FT2 and FLT2 reader re-entry, dynamic `closeU`,
first-class use under `metaBoostC`, lifting through `iterOf`/the tree-indexed
iteration hierarchy, the successor-base final hierarchy, and the fourfold-family
lower-bound theorem. It also checks balanced comments and delimiters and rejects
explicit `axiom` declarations and `Classical.choice`. This is a source audit,
not a substitute for Lean elaboration.

### 2. Python syntax and executable finite model

The three Python files compile with `python3 -m py_compile`. Running

```bash
python3 notes/finite_model.py
```

reproduces `notes/finite_model_output.txt` byte-for-byte. The model checks the
arithmetic spine on finite toy trees: the first semantic budget is above the
triple calibrator iterate, the second reflected budget is strictly larger than
the first, and the final successor-base step is strictly larger again. It is a
sanity model, not a model of the full Lean tree languages.

Recorded output:

```text
calibrating family: g(n) = n + 1
explicit parameter N = 0
g(g(g(N))) = 3

semantic_budget(zero                  ) =          6  [strictly above g^3(N): True]
semantic_budget(one                   ) =          8  [strictly above g^3(N): True]
semantic_budget(two                   ) =         26  [strictly above g^3(N): True]
semantic_budget(limit[zero,one,two]   ) =         26  [strictly above g^3(N): True]

first reflected budget  = 8
second reflected budget = 22
second > first: True
successor-base hierarchy at second budget = 23
final > second: True
```

### 3. Exact-baseline integration-patch replay

A synthetic Git repository was initialized with the exact pinned versions of
`BusyLean.lean` and `scripts/check.py`. Their Git blob identifiers were checked
against the pinned repository data:

```text
BusyLean.lean       339572dba4559a08fe0d6894077f8250f3741987
scripts/check.py    b48c150a4fe1fd9c66c7c5bccf3dfca10b1c06fb
```

The following completed successfully:

```bash
git apply --check integration/contender50.patch
git apply integration/contender50.patch
git diff --check
python3 scripts/static_check50.py
python3 -m py_compile scripts/check.py scripts/static_check50.py
```

Every newly added file was then compared byte-for-byte with the corresponding
file in this package. The patch itself parses to these changes:

```text
2   0  BusyLean.lean
126 0  BusyLean/Comparison50.lean
191 0  BusyLean/Contender50.lean
11  7  scripts/check.py
117 0  scripts/static_check50.py
118 0  test/Audit50.lean
37  0  test/ResourceReflectionSmoke.lean
```

### 4. Mathematical proof-spine review

The supplied comparison source follows this conservative chain.

1. `semanticOracle50 g t m = treeReflect g t (g m)`. Contender 49's inherited
   strictness theorem gives `g(g m) < semanticOracle50 g t m`.
2. `semanticBudget50 g N t = semanticOracle50 g t (g N)`, hence
   `g(g(g N)) < semanticBudget50 g N t`.
3. Specializing `N` to `family49 n` gives
   `family49^4(n) < budget50 (family49 n) t`.
4. A second reflection uses the first budget as its explicit parameter, so it
   is strictly larger than that first budget.
5. `F50` reads the resulting tree with the strictly inflationary base
   `Nat.succ`, hence it strictly exceeds its entry value.
6. `family49 42` is definitionally `contender_49`; the outer application
   `F50 (F50 42)` closes the required contest comparison.

This review checks the intended theorem decomposition and use of inherited
lemmas. Only Lean kernel replay can certify that the terms elaborate exactly as
written.

### 5. Article and PDF

`article/contender50.tex` was compiled with

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error contender50.tex
```

Completed checks:

- 21 pages, US Letter, PDF 1.7;
- unencrypted and opens successfully;
- no LaTeX errors, undefined references, overfull boxes, or underfull boxes;
- all fonts reported embedded by `pdffonts`;
- all 21 pages rendered at 180 dpi and visually inspected;
- the full-page architecture diagram was separately inspected at full size;
- no clipping, missing glyphs, unreadable code, or broken page composition was
  observed.

Temporary LaTeX build files and rendered inspection images are deliberately not
included in the final archive.

## Checks not completed in the authoring environment

Lean, Lake, and Elan were not installed in the authoring container. Therefore
none of the following is claimed as completed here:

- Lean elaboration of `BusyLean/Contender50.lean`;
- kernel acceptance of `BusyLean/Comparison50.lean`;
- kernel acceptance of `contender_49_lt_contender_50` or the stronger
  `family49_fourfold_lt_F50` theorem;
- clean-build timing against the 15-second and 60-second budgets;
- kernel-reported axiom closure;
- the forbidden closed-contender dependency audit;
- execution of `test/ResourceReflectionSmoke.lean`.

The package supplies `scripts/check50.py`, a patched repository checker, the
supplemental `test/Audit50.lean`, and exact replay instructions. A proposal
should be called accepted or repository-ready only after those authoritative
checks pass on a machine with Lean 4.34.0.

## Validation conclusion

The artifact is a serious, reproducible research proposal with a complete Lean
source candidate, comparison proof source, exact-pin integration patch, static
checks, executable finite sanity model, and inspected article. Its formal
status is **proposed, pending Lean kernel and timing validation**.
