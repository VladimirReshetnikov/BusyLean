# Integration patch

`contender50.patch` targets BusyLean commit:

`961ee2bbd8039dcf9832edd9d28272db8ba181ac`

Apply it from the root of a clean checkout at that commit:

```bash
git apply --check contender50.patch
git apply contender50.patch
python3 scripts/static_check50.py
python3 scripts/check.py
lake env lean test/ResourceReflectionSmoke.lean
```

The patch adds Contender 50 and its comparison, imports them from `BusyLean.lean`, advances the checker from Contender 49 to Contender 50, and adds the supplemental smoke and axiom/dependency audits. Existing mathematical modules are not modified.

Do not apply the patch to a later head without rebasing and renumbering. The exact pin is part of the formal comparison target.
