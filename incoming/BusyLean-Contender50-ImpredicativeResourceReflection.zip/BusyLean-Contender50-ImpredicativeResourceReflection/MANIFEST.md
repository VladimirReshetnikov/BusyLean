# Artifact manifest

This archive is pinned to BusyLean commit
`961ee2bbd8039dcf9832edd9d28272db8ba181ac` and proposes Contender 50 above
Contender 49.

## Primary deliverables

| Path | Purpose |
|---|---|
| `BusyLean/Contender50.lean` | Complete proposed Lean definition of semantic-resource-reflective Contender 50. |
| `BusyLean/Comparison50.lean` | Generic strictness lemmas, fourfold-family lower bound, and required comparison `contender_49_lt_contender_50`. |
| `article/contender50.tex` | Full research article source. |
| `article/contender50.pdf` | Compiled 21-page article. |
| `integration/contender50.patch` | Repository integration patch for the exact pinned commit. |

## Validation and reproduction

| Path | Purpose |
|---|---|
| `README.md` | Executive overview, novelty claim, package layout, and validation boundary. |
| `REPRODUCE.md` | Exact checkout, patch, build, audit, smoke-test, and article-rebuild instructions. |
| `VALIDATION.md` | Completed checks, proof-spine review, and explicit pending Lean/kernel gates. |
| `metadata.json` | Machine-readable pin, toolchain, budgets, axiom policy, and theorem names. |
| `scripts/static_check50.py` | Cheap source-integrity audit; explicitly not a Lean substitute. |
| `scripts/check50.py` | Standalone clean-build, timing, existing-audit, and supplemental-audit driver. |
| `test/Audit50.lean` | Axiom reports and forbidden closed-contender dependency check. |
| `test/ResourceReflectionSmoke.lean` | Cheap definitional smoke tests that avoid evaluating enormous reflected universes. |
| `integration/README.md` | Patch scope and integration warning. |

## Research notes and diagrams

| Path | Purpose |
|---|---|
| `notes/repository_snapshot.md` | Audited repository pin and inherited BusyLean mechanisms. |
| `notes/theorem_map.md` | Lean theorem-to-mathematics map and scope of the conservative lower bound. |
| `notes/finite_model.py` | Executable finite sanity model of the resource-escalation arithmetic. |
| `notes/finite_model_output.txt` | Recorded output expected from the finite model. |
| `notes/dependency_graph.dot` | Graphviz source for the architecture diagram. |
| `notes/dependency_graph.svg` | Vector diagram for browser inspection. |
| `notes/dependency_graph.pdf` | Diagram embedded in the article. |
| `article/Makefile` | Convenience target for rebuilding the article. |

## Integrity file

`SHA256SUMS` lists SHA-256 digests for every other file in the package. It does
not include itself.

## Validation status

Static, patch-replay, Python, finite-model, LaTeX, PDF-preflight, and visual PDF
checks are complete. Lean elaboration, kernel theorem checking, axiom closure,
smoke-test execution, and contest-budget timing remain pending because the
authoring environment did not contain Lean, Lake, or Elan. See `VALIDATION.md`.
