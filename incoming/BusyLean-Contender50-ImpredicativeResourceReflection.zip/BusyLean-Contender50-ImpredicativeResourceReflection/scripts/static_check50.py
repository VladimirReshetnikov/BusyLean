#!/usr/bin/env python3
"""Cheap source-integrity checks for Contender 50; not a Lean substitute."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parent.parent
FILES = [ROOT / "BusyLean" / "Contender50.lean",
         ROOT / "BusyLean" / "Comparison50.lean"]

required = {
    "Contender50.lean": [
        "def semanticOracle50", "treeReflect g t (g m)",
        "def semanticBudget50", "def family49", "def budget50",
        "def levelOperator50", "iterLevel d t (metaJump d) t",
        "FT2.jumpF", "FLT2.jumpL", "def secondBudget50", "closeU d",
        "def reflectiveClose50", "def reflectiveThetaFrom50",
        "def reflectiveIterLevel50", "iterOf (reflectiveIterLevel50 N k)",
        "Ordinal.metaBoostC (reflectiveClose50 N)",
        "def resourceTree50", "Ordinal.hier Nat.succ", "def contender_50",
    ],
    "Comparison50.lean": [
        "theorem tripleCalibration_lt_semanticBudget50",
        "theorem budget50_lt_secondBudget50",
        "theorem budget50_lt_reflectiveSecondBudget50",
        "theorem family49_fourfold_lt_F50",
        "theorem contender_49_lt_contender_50",
    ],
}


def strip_comments_and_strings(text: str) -> str:
    out: list[str] = []
    i = 0
    depth = 0
    in_string = False
    while i < len(text):
        if depth:
            if text.startswith("/-", i):
                depth += 1
                i += 2
            elif text.startswith("-/", i):
                depth -= 1
                i += 2
            else:
                i += 1
        elif in_string:
            if text[i] == "\\" and i + 1 < len(text):
                i += 2
            elif text[i] == '"':
                in_string = False
                i += 1
            else:
                i += 1
        elif text.startswith("/-", i):
            depth = 1
            i += 2
        elif text.startswith("--", i):
            j = text.find("\n", i)
            i = len(text) if j < 0 else j
        elif text[i] == '"':
            in_string = True
            i += 1
        else:
            out.append(text[i])
            i += 1
    if depth or in_string:
        raise ValueError("unterminated comment or string")
    return "".join(out)


def check_delimiters(text: str, label: str) -> None:
    clean = strip_comments_and_strings(text)
    pairs = {")": "(", "]": "[", "}": "{"}
    stack: list[tuple[str, int]] = []
    for pos, ch in enumerate(clean):
        if ch in "([{":
            stack.append((ch, pos))
        elif ch in pairs:
            if not stack or stack[-1][0] != pairs[ch]:
                sys.exit(f"{label}: mismatched delimiter {ch!r} at stripped offset {pos}")
            stack.pop()
    if stack:
        sys.exit(f"{label}: unclosed delimiters {stack[-5:]}")


for path in FILES:
    text = path.read_text(encoding="utf-8")
    missing = [needle for needle in required[path.name] if needle not in text]
    if missing:
        sys.exit(f"{path.name}: missing {missing}")
    if "Classical.choice" in text or re.search(r"(?m)^\s*axiom\b", text):
        sys.exit(f"{path.name}: forbidden classical or axiomatic declaration")
    if text.count("/-") != text.count("-/"):
        sys.exit(f"{path.name}: unbalanced block comments")
    if text.count("namespace ") != text.count("\nend "):
        sys.exit(f"{path.name}: namespace/end count mismatch")
    check_delimiters(text, path.name)

contender = FILES[0].read_text(encoding="utf-8")
if "semanticBudget50 family49 (budget50 N t) (firstUniverse50 N t)" not in contender:
    sys.exit("second budget no longer reflects firstUniverse50 at the first budget")
if "Ordinal.metaBoostC (reflectiveClose50 N)" not in contender:
    sys.exit("dynamic closure is not first-class under metaBoostC")
if "iterOf (reflectiveIterLevel50 N k)" not in contender:
    sys.exit("dynamic closure was not lifted through the iteration-level hierarchy")
if "closeU e (levelOperator50 e c) (reentryLadder50 N t)" not in contender:
    sys.exit("second universe-collapsing reader re-entry is absent")
body = contender.split("def contender_50", 1)[1]
if "contender_49" in body:
    sys.exit("contender_50 directly mentions contender_49")

comparison = FILES[1].read_text(encoding="utf-8")
if "family49 (family49 (family49 (family49 n))) < F50 n" not in comparison:
    sys.exit("strong fourfold-family bound is absent")

print("PASS: Contender 50 source-integrity checks completed")
