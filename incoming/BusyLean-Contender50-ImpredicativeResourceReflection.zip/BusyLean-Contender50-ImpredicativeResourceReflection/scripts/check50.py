#!/usr/bin/env python3
"""Clean-build Contender 50, enforce BusyLean budgets, and run both audits."""
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BUILD_DIRS = [ROOT / ".lake" / "build",
              ROOT / "proposals" / "P5-w-reflection" / "lean" / ".lake" / "build"]
PERMITTED = {"propext", "Quot.sound"}
PREVIOUS = "BusyLean.Comparison49"
CURRENT_DEF = "BusyLean.Contender50"
DEFINITION_BUDGET = 15.0
PROOF_BUDGET = 60.0
LAKE = shutil.which("lake") or "lake"


def run(args):
    return subprocess.run([LAKE, *args], cwd=ROOT, capture_output=True, text=True)


def timed_build(label, target, budget):
    start = time.monotonic()
    build = run(["build", *target])
    elapsed = time.monotonic() - start
    if build.returncode != 0:
        print(build.stdout, build.stderr)
        sys.exit(f"FAIL: {label} build failed")
    note = f"(budget {budget:.0f} s)" if budget else "(accepted earlier; not budgeted)"
    print(f"{label}: {elapsed:.1f} s {note}")
    if budget and elapsed > budget:
        sys.exit(f"FAIL: {label} exceeds the budget")
    return elapsed


def main():
    for d in BUILD_DIRS:
        shutil.rmtree(d, ignore_errors=True)

    total = timed_build("previous contender", [PREVIOUS], None)
    total += timed_build("definitions", [CURRENT_DEF], DEFINITION_BUDGET)
    total += timed_build("proofs", [], PROOF_BUDGET)
    print(f"total clean build: {total:.1f} s")

    outputs = []
    for audit_file in ["test/Audit.lean", "test/Audit50.lean"]:
        audit = run(["env", "lean", audit_file])
        out = audit.stdout + audit.stderr
        print(out)
        if audit.returncode != 0:
            sys.exit(f"FAIL: {audit_file} did not run cleanly")
        outputs.append(out)
    out = "\n".join(outputs)
    reports = re.findall(r"'([^']+)' (?:depends on axioms: \[([^\]]*)\]|does not depend)", out)
    bad = [(name, axs) for name, axs in reports
           if axs and set(a.strip() for a in axs.split(",")) - PERMITTED]
    if not reports or bad:
        sys.exit(f"FAIL: forbidden axioms: {bad}")
    print(f"PASS: {len(reports)} declarations audited, axioms within {sorted(PERMITTED)}")


if __name__ == "__main__":
    main()
