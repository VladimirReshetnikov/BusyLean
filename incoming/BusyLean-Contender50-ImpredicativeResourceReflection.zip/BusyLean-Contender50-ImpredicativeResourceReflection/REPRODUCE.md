# Reproducing and checking Contender 50

## 1. Prepare the exact repository state

```bash
git clone https://github.com/VladimirReshetnikov/BusyLean.git
cd BusyLean
git checkout 961ee2bbd8039dcf9832edd9d28272db8ba181ac
```

The pin declares Lean `leanprover/lean4:v4.34.0` and has Contender 49 as the accepted entry.

## 2. Apply the integration patch

From the BusyLean repository root:

```bash
git apply --check /path/to/BusyLean-Contender50-ImpredicativeResourceReflection/integration/contender50.patch
git apply /path/to/BusyLean-Contender50-ImpredicativeResourceReflection/integration/contender50.patch
```

The patch:

1. imports `BusyLean.Contender50` and `BusyLean.Comparison50` from `BusyLean.lean`;
2. adds the definition and comparison modules;
3. adds `test/ResourceReflectionSmoke.lean` and `test/Audit50.lean`;
4. advances `scripts/check.py` from Contender 49 to Contender 50 and runs the supplemental audit; and
5. adds `scripts/static_check50.py`.

## 3. Run the non-kernel source audit

```bash
python3 scripts/static_check50.py
```

It checks required declarations, balanced comments and delimiters, absence of explicit axioms and `Classical.choice`, use of `treeReflect` as the dynamic selector, two-pass re-reflection, first-class closure under `metaBoostC`, lifting through `iterLevel`, reader re-entry, and presence of the strong fourfold-family lower bound. It is not a Lean substitute.

## 4. Run the authoritative BusyLean checker

```bash
python3 scripts/check.py
```

The patched checker performs:

- the already accepted predecessor build (`BusyLean.Comparison49`), uncharged to the proposal;
- the timed definition build (`BusyLean.Contender50`) under the 15-second budget;
- the remaining proof/library build under the 60-second budget;
- the existing repository audit; and
- the supplemental Contender 50 axiom and dependency-closure audit.

The permitted axiom set is `{propext, Quot.sound}`.

## 5. Run the semantic smoke test

```bash
lake env lean test/ResourceReflectionSmoke.lean
```

The smoke test uses definitional equalities only. It deliberately does not evaluate `treeReflect` at a nontrivial reflected bound, which would enumerate and normalize an enormous finite FT2 program universe.

## 6. Inspect the key declarations

```bash
lake env lean BusyLean/Comparison50.lean
lake env lean test/Audit50.lean
```

Required theorem:

```lean
#check @BusyLean.contender_49_lt_contender_50
```

Stronger pointwise theorem:

```lean
#check @BusyLean.family49_fourfold_lt_F50
```

## 7. Rebuild the article

From this package's `article` directory:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error contender50.tex
```

The article depends on the two Lean files and `notes/dependency_graph.pdf`. PDF compilation does not validate Lean semantics.

## Acceptance criteria

Treat the proposal as repository-ready only after all of the following pass on the target machine:

- Lean elaborates every new module;
- `contender_49_lt_contender_50` is kernel accepted;
- the definition and proof builds fit the 15-second and 60-second budgets;
- all reported axioms lie in `{propext, Quot.sound}`;
- the forbidden closed-contender dependency audit passes; and
- the smoke test runs successfully.
