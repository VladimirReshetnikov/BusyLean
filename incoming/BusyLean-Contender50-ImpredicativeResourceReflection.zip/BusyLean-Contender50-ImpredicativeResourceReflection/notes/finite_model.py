#!/usr/bin/env python3
"""Finite sanity model for Contender 50's arithmetic spine.

This is not a model of System FT2, System FLT2, normalization, relative
collapse, universes, or the iteration-level hierarchy.  A small finite
``program_values`` list stands in for the values of bounded FT2 nat programs.
The script checks only the inequalities used by the generic comparison proof:

  g(g(m)) < semantic_oracle(g,t,m),
  g(g(g(N))) < semantic_budget(g,N,t),
  first_budget < second_budget,
  and entry < hier(succ, tree, entry).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Sequence, Union


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Succ:
    child: "Tree"


@dataclass(frozen=True)
class Lim:
    branches: Sequence["Tree"]


Tree = Union[Zero, Succ, Lim]
ZERO = Zero()


def iterate(f: Callable[[int], int], count: int, x: int) -> int:
    for _ in range(count):
        x = f(x)
    return x


def hier(g: Callable[[int], int], tree: Tree, m: int) -> int:
    if isinstance(tree, Zero):
        return g(m)
    if isinstance(tree, Succ):
        lower = lambda x: hier(g, tree.child, x)
        return iterate(lower, m + 1, m)
    assert isinstance(tree, Lim)
    values = []
    for i in range(m + 1):
        branch = tree.branches[i] if i < len(tree.branches) else ZERO
        values.append(hier(g, branch, m))
    return max(values)


def finite_program_values(g: Callable[[int], int], tree: Tree, m: int) -> list[int]:
    """Toy values for a few tree-reading number programs.

    The real ``treeReflect`` enumerates every FT2 term of bounded depth and
    normalizes the well-typed nat programs.  These values merely make the role
    of the maximum executable in a tiny model.
    """
    return [0, g(m), hier(lambda x: x + 1, tree, m)]


def tree_reflect(g: Callable[[int], int], tree: Tree, m: int) -> int:
    maximum = max([g(m), *finite_program_values(g, tree, m)])
    return m + 1 + maximum


def semantic_oracle(g: Callable[[int], int], tree: Tree, m: int) -> int:
    return tree_reflect(g, tree, g(m))


def semantic_budget(g: Callable[[int], int], n: int, tree: Tree) -> int:
    return semantic_oracle(g, tree, g(n))


def main() -> None:
    g = lambda n: n + 1
    trees = {
        "zero": ZERO,
        "one": Succ(ZERO),
        "two": Succ(Succ(ZERO)),
        "limit[zero,one,two]": Lim([ZERO, Succ(ZERO), Succ(Succ(ZERO))]),
    }
    n = 0
    print("calibrating family: g(n) = n + 1")
    print(f"explicit parameter N = {n}")
    print(f"g(g(g(N))) = {g(g(g(n)))}")
    print()

    for name, tree in trees.items():
        b = semantic_budget(g, n, tree)
        print(
            f"semantic_budget({name:22s}) = {b:>10d}  "
            f"[strictly above g^3(N): {b > g(g(g(n)))}]"
        )

    seed = trees["one"]
    first = semantic_budget(g, n, seed)
    first_closed_surrogate = ZERO
    second = semantic_budget(g, first, first_closed_surrogate)

    print()
    print(f"first reflected budget  = {first}")
    print(f"second reflected budget = {second}")
    print(f"second > first: {second > first}")

    resource_surrogate = ZERO
    final = hier(lambda x: x + 1, resource_surrogate, second)
    print(f"successor-base hierarchy at second budget = {final}")
    print(f"final > second: {final > second}")

    assert all(semantic_budget(g, n, t) > g(g(g(n))) for t in trees.values())
    assert second > first
    assert final > second


if __name__ == "__main__":
    main()
