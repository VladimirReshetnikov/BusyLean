# Theorem map for Contender 50

## Generic impredicative reflection spine

| Lean theorem | Mathematical content | Role |
|---|---|---|
| `doubleCalibration_lt_semanticOracle50` | `g(g(m)) < semanticOracle50 g t m` | `treeReflect g t (g m)` dominates the number-oracle value `g(g m)`. |
| `tripleCalibration_lt_semanticBudget50` | `g³(N) < semanticBudget50 g N t` | The resource selector applies the calibrator twice before invoking impredicative FT2 reflection. |
| `input_lt_semanticBudget50` | `N < semanticBudget50 g N t` for strictly inflationary `g` | Every feedback pass strictly increases its explicit finite resource parameter. |

## Specialized resource escalation

| Lean theorem | Mathematical content | Role |
|---|---|---|
| `input_lt_family49` | `n < family49(n)` | Inherited from strict inflation of `F49`. |
| `input_lt_budget50` | `N < budget50(N,t)` | First semantics-to-syntax/collapse transfer grows. |
| `budget50_lt_secondBudget50` | `budget50(N,t) < secondBudget50(N,t)` | Reflecting the first universe-collapsed output creates a strictly larger second reader/collapse universe. |
| `budget50_lt_reflectiveSecondBudget50` | every `reflectiveClose50 N J t` has a strictly larger second budget | Strict resource escalation survives when the closure is first-class inside the iteration-level hierarchy. |

## Numerical lower bounds

| Lean theorem | Statement |
|---|---|
| `family49_fourfold_lt_budget50` | `family49⁴(n) < budget50 (family49 n) t` |
| `family49_fourfold_lt_entry50` | `family49⁴(n) < entry50(n)` |
| `entry50_lt_F50` | `entry50(n) < F50(n)` |
| `family49_fourfold_lt_F50` | `family49⁴(n) < F50(n)` |
| `family49_fourfold_42_lt_contender_50` | `family49⁴(42) < contender_50` |
| `contender_49_lt_contender_50` | required comparison with the pinned champion |

Here `family49⁴(n)` abbreviates four nested applications. The lower bound is intentionally conservative: it uses the arithmetic strictness of `treeReflect`, two resource passes, and the final hierarchy step, but it does not claim a completed ordinal or simulation analysis of `reflectiveIterLevel50`.

## Architectural novelty

`semanticOracle50` uses bounded impredicative FT2 numerical reflection over the current tree to choose the next object-language resources. `reflectiveClose50` repeats this selection after universe collapse. `reflectiveThetaFrom50` uses the dynamic closure at every self-based successor, and `reflectiveIterLevel50` lifts it through Contender 48's full tree-indexed hierarchy of iteration levels. Thus semantic output controls the syntax and collapse universe available at the next higher-order stage.
