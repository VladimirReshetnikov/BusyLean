# Audited BusyLean snapshot

This proposal is pinned to the following repository state:

- Repository: `VladimirReshetnikov/BusyLean`
- Branch audited: `main`
- Commit: `961ee2bbd8039dcf9832edd9d28272db8ba181ac`
- Commit subject: `Docs: Contender 49, impredicative reflection over the tree`
- Lean toolchain declared by the repository: `leanprover/lean4:v4.34.0`
- Current accepted contender at the pin: Contender 49
- Current checker at the pin: predecessor target `BusyLean.Comparison48`, definition target `BusyLean.Contender49`, 15-second definition budget, 60-second proof budget, and permitted axioms `{propext, Quot.sound}`.

## Relevant inherited mechanisms

Contenders 40-41 introduced input-reading System FT2 and System FLT2 tree languages. Contenders 42-46 made relative collapse, tree-indexed levels, and universes of codes first-class and operator-relative. Contenders 45-47 iterated self-based operator construction. Contender 48 organized those iterations into a tree-indexed hierarchy of iteration levels (`iterLevel`). Contender 49 introduced `treeReflect g T m`: a strict maximum over the number oracle and the values of every bounded closed FT2 program of type `nat` reading the oracle tree `T`.

Contender 49 uses `treeReflect` as the numerical base for a final hierarchy, while the finite bound `m` supplied to that reflection and the finite parameters of the reader/collapse universe remain externally determined. Contender 50 turns the reflected number back into the finite resource bound of the next reader and collapsing universe. It then re-reflects the first universe-collapsed output, uses the strictly larger bound for reader re-entry, and lifts the dynamic closure through the full `iterLevel` architecture.

## Pinning policy

The integration patch targets the exact commit above. BusyLean changed repeatedly during this research pass. Apply the patch only at the pin, or rebase and renumber it against a later head before claiming current-champion status.
