import BusyLean.Contender50
import BusyLean.Comparison50

open BusyLean BusyLean.Ordinal

/-- Branch projection used only for definitional smoke tests. -/
def branch50 (i : Nat) : CTree → CTree
  | .lim f => f i
  | t => t

-- Keep the smoke test definitional: evaluating treeReflect at a nontrivial
-- reflected bound would deliberately enumerate FT2 programs.
example (g : Nat → Nat) (t : CTree) (m : Nat) :
    semanticOracle50 g t m = treeReflect g t (g m) := rfl
example (g : Nat → Nat) (t : CTree) (N : Nat) :
    semanticBudget50 g N t = treeReflect g t (g (g N)) := rfl

-- Retained branches reduce without evaluating enormous later branches.
example : branch50 0 (resourceBase50 0 .zero) = .zero := rfl
example : branch50 1 (resourceBase50 0 .zero) = firstFT50 0 .zero := rfl
example : branch50 2 (resourceBase50 0 .zero) = firstLadder50 0 .zero := rfl
example (N : Nat) : branch50 0 (resourceTree50 N) = levelIterTree N := rfl
example (N : Nat) (J : CTree → CTree) (t : CTree) :
    branch50 0 (reflectiveClose50 N J t) = closeU (budget50 N t) J t := rfl
example (N : Nat) (B : CTree → CTree) (t : CTree) :
    reflectiveThetaFrom50 N B .zero t = B t := rfl
example (N : Nat) (B : CTree → CTree) (a t : CTree) :
    reflectiveIterLevel50 N .zero B a t = reflectiveThetaFrom50 N B a t := rfl

#check @BusyLean.doubleCalibration_lt_semanticOracle50
#check @BusyLean.tripleCalibration_lt_semanticBudget50
#check @BusyLean.budget50_lt_secondBudget50
#check @BusyLean.budget50_lt_reflectiveSecondBudget50
#check @BusyLean.family49_fourfold_lt_F50
#print axioms BusyLean.resourceTree50
#print axioms BusyLean.contender_50
#print axioms BusyLean.contender_49_lt_contender_50
