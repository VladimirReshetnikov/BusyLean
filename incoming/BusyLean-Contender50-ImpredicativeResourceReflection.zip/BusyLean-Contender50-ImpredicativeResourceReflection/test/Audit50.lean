import BusyLean.Comparison50
import Lean

/-!
# Contender 50 audit

This supplements BusyLean's existing `test/Audit.lean`. It reports axiom
dependencies for the impredicative resource-reflection declarations and checks
that the final constant does not directly depend on any earlier closed
contender constant.
-/

open Lean Elab Command

/-- All constants reachable from `root` through declaration types and values. -/
def constClosure50 (env : Environment) (root : Name) : NameSet := Id.run do
  let mut seen : NameSet := {}
  let mut stack := #[root]
  while stack.size > 0 do
    let c := stack.back!
    stack := stack.pop
    if seen.contains c then continue
    seen := seen.insert c
    let some ci := env.find? c | continue
    let body : Array Name := match ci with
      | .defnInfo v => v.value.getUsedConstants
      | .thmInfo v => v.value.getUsedConstants
      | .opaqueInfo v => v.value.getUsedConstants
      | _ => #[]
    stack := stack ++ ci.type.getUsedConstants ++ body
  return seen

elab "#assert_not_in_closure50 " root:ident " : " bad:ident* : command => do
  let env ← getEnv
  let r ← liftCoreM <| realizeGlobalConstNoOverloadWithInfo root
  let cl := constClosure50 env r
  for b in bad do
    let n ← liftCoreM <| realizeGlobalConstNoOverloadWithInfo b
    if cl.contains n then throwError m!"{r} depends on forbidden constant {n}"
  logInfo m!"{r}: closure of {cl.size} constants avoids all {bad.size} forbidden names"

-- Inherited substrate.
#print axioms BusyLean.FT2.natValue
#print axioms BusyLean.treeReflect
#print axioms BusyLean.FT2.jumpF
#print axioms BusyLean.FLT2.jumpL
#print axioms BusyLean.closeU
#print axioms BusyLean.iterOf
#print axioms BusyLean.iterLevel
#print axioms BusyLean.Ordinal.metaBoostC
#print axioms BusyLean.Ordinal.hier

-- New construction.
#print axioms BusyLean.semanticOracle50
#print axioms BusyLean.semanticBudget50
#print axioms BusyLean.family49
#print axioms BusyLean.oracle50
#print axioms BusyLean.budget50
#print axioms BusyLean.levelOperator50
#print axioms BusyLean.firstFT50
#print axioms BusyLean.firstLadder50
#print axioms BusyLean.firstLevel50
#print axioms BusyLean.firstUniverse50
#print axioms BusyLean.secondBudget50
#print axioms BusyLean.reentryFT50
#print axioms BusyLean.reentryLadder50
#print axioms BusyLean.secondUniverse50
#print axioms BusyLean.reflectiveSecondBudget50
#print axioms BusyLean.reflectiveClose50
#print axioms BusyLean.resourceBase50
#print axioms BusyLean.reflectiveThetaFrom50
#print axioms BusyLean.reflectiveIterLevel50
#print axioms BusyLean.resourceTree50
#print axioms BusyLean.entry50
#print axioms BusyLean.tree50
#print axioms BusyLean.F50
#print axioms BusyLean.contender_50

-- Comparison spine.
#print axioms BusyLean.doubleCalibration_lt_semanticOracle50
#print axioms BusyLean.tripleCalibration_lt_semanticBudget50
#print axioms BusyLean.input_lt_semanticBudget50
#print axioms BusyLean.input_lt_family49
#print axioms BusyLean.input_lt_budget50
#print axioms BusyLean.budget50_lt_secondBudget50
#print axioms BusyLean.budget50_lt_reflectiveSecondBudget50
#print axioms BusyLean.family49_fourfold_lt_budget50
#print axioms BusyLean.family49_fourfold_lt_entry50
#print axioms BusyLean.entry50_lt_F50
#print axioms BusyLean.family49_fourfold_lt_F50
#print axioms BusyLean.family49_fourfold_42_lt_contender_50
#print axioms BusyLean.contender_49_lt_contender_50

#assert_not_in_closure50 BusyLean.contender_50 :
  BusyLean.contender_49 BusyLean.contender_48 BusyLean.contender_47
  BusyLean.contender_46 BusyLean.contender_45 BusyLean.contender_44
  BusyLean.contender_43 BusyLean.contender_42 BusyLean.contender_41
  BusyLean.contender_40 BusyLean.contender_39 BusyLean.contender_38
  BusyLean.contender_37 BusyLean.contender_36 BusyLean.contender_35
  BusyLean.contender_34 BusyLean.contender_33 BusyLean.contender_32
  BusyLean.contender_31 BusyLean.contender_30 BusyLean.contender_29
  BusyLean.contender_28 BusyLean.contender_27 BusyLean.contender_26
  BusyLean.contender_25 BusyLean.contender_24 BusyLean.contender_23
  BusyLean.contender_22 BusyLean.contender_21 BusyLean.contender_20
  BusyLean.contender_19 BusyLean.contender_18 BusyLean.contender_17
  BusyLean.contender_16 BusyLean.contender_15 BusyLean.contender_14
  BusyLean.contender_13 BusyLean.contender_12 BusyLean.contender_11
  BusyLean.contender_10 BusyLean.contender_9 BusyLean.contender_8
  BusyLean.contender_7 BusyLean.contender_6 BusyLean.contender_5

#check @BusyLean.doubleCalibration_lt_semanticOracle50
#check @BusyLean.tripleCalibration_lt_semanticBudget50
#check @BusyLean.budget50_lt_secondBudget50
#check @BusyLean.budget50_lt_reflectiveSecondBudget50
#check @BusyLean.family49_fourfold_lt_entry50
#check @BusyLean.family49_fourfold_lt_F50
#check @BusyLean.family49_fourfold_42_lt_contender_50
#check @BusyLean.contender_49_lt_contender_50
