# BusyLean Contender 50: Impredicative Semantic Resource Reflection

This package proposes a closed Lean natural number above the BusyLean snapshot pinned at:

`961ee2bbd8039dcf9832edd9d28272db8ba181ac`

At that commit, the accepted champion is **Contender 49**. The proposed entry is:

```lean
def contender_50 : Nat := F50 (F50 42)
```

## New idea

Contender 49 introduced `treeReflect g T m`, a strict maximum over the number oracle and the values of every bounded closed System FT2 program of type `nat` that reads the tree `T`. It uses that reflection as the numerical base of a final hierarchy.

Contender 50 changes the role of reflection. The reflected value becomes the finite resource bound of the **next** semantic stage: it selects FT2/FLT2 syntax depth, address prefix, relative-collapse depth, relative level rounds, universe-collapse parameters, and the parameter of the inherited hierarchy of iteration levels. The first universe-collapsed output is reflected again, yielding a provably larger second resource universe; both readers then re-enter at that larger bound. The two-pass selector is promoted to a first-class closure and lifted through Contender 48's full tree-indexed hierarchy of iteration levels.

The final numerical hierarchy uses only `Nat.succ`. The previous family calibrates finite resources and supplies certified inherited machinery; it is not the final hierarchy base.

## Main supplied claims

Pending Lean kernel replay, `BusyLean/Comparison50.lean` declares:

```lean
theorem family49_fourfold_lt_F50 (n : Nat) :
    family49 (family49 (family49 (family49 n))) < F50 n

theorem contender_49_lt_contender_50 :
    contender_49 < contender_50
```

The fourfold-family bound is conservative. It uses the accepted strictness theorem for `treeReflect`, a strict second reflection pass, and a final successor-base hierarchy step. It does not claim a completed ordinal analysis of the dynamic iteration-level tree.

## Package layout

- `BusyLean/Contender50.lean` — proposed definition.
- `BusyLean/Comparison50.lean` — generic reflection lemmas and comparison source.
- `test/ResourceReflectionSmoke.lean` — cheap definitional tests that avoid enormous normalization.
- `test/Audit50.lean` — axiom reports and closed-contender dependency audit.
- `scripts/check50.py` — standalone clean-build, timing, and axiom-audit driver.
- `scripts/static_check50.py` — non-kernel source-integrity checks.
- `integration/contender50.patch` — patch for the pinned BusyLean checkout.
- `notes/theorem_map.md` — theorem-to-mathematics map.
- `notes/repository_snapshot.md` — audited pin and inherited mechanisms.
- `notes/finite_model.py` — finite executable sanity model of the arithmetic spine.
- `notes/dependency_graph.{dot,svg,pdf}` — architecture diagram.
- `article/contender50.tex` and `article/contender50.pdf` — 21-page research article and compiled PDF.
- `VALIDATION.md` — completed and pending validation ledger.
- `REPRODUCE.md` — exact replay instructions.

## Validation boundary

Lean, Lake, and Elan are not installed in the authoring container. Therefore the proposed source has not been elaborated by Lean here, its axiom closure has not been kernel-reported here, and no build-time claim is made. Static source checks, exact-baseline patch replay, Python checks, finite-model assertions, LaTeX compilation, PDF preflight, and visual inspection were completed. See `VALIDATION.md`.

BusyLean changed repeatedly during this research pass. The exact pin is part of the claim. A later head requires rebasing, renumbering, and a fresh predecessor comparison before the proposal should be described as the current champion.
