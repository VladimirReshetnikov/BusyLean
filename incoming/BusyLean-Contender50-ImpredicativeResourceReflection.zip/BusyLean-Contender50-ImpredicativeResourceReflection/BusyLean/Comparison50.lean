import BusyLean.Contender50
import BusyLean.Comparison49

/-!
# Contender 50: comparison theorems

The arithmetic certificate uses Contender 49's proved strictness of
`treeReflect`. The first semantic budget exceeds three applications of its
calibrating family. At calibration `family49 n`, it therefore exceeds four
applications. Every first-class reflective closure obtains a strictly larger
second budget, and the final successor-base hierarchy adds another strict step.
-/

namespace BusyLean

/-- An impredicative semantic oracle exceeds two applications of its calibrating
family: the outer application selects the FT2 enumeration depth and the inner
one is dominated by `treeReflect`. -/
theorem doubleCalibration_lt_semanticOracle50
    (g : Nat → Nat) (t : Ordinal.CTree) (m : Nat) :
    g (g m) < semanticOracle50 g t m := by
  simpa [semanticOracle50] using oracle_lt_treeReflect g t (g m)

/-- A semantic budget exceeds three applications of its calibrating family. -/
theorem tripleCalibration_lt_semanticBudget50
    (g : Nat → Nat) (N : Nat) (t : Ordinal.CTree) :
    g (g (g N)) < semanticBudget50 g N t := by
  simpa [semanticBudget50] using
    doubleCalibration_lt_semanticOracle50 g t (g N)

/-- If the calibrating family is strictly inflationary, every semantic budget
strictly exceeds its explicit finite parameter. -/
theorem input_lt_semanticBudget50 (g : Nat → Nat)
    (hg : ∀ n, n < g n) (N : Nat) (t : Ordinal.CTree) :
    N < semanticBudget50 g N t :=
  Nat.lt_trans (hg N)
    (Nat.lt_trans (hg (g N))
      (Nat.lt_trans (hg (g (g N)))
        (tripleCalibration_lt_semanticBudget50 g N t)))

/-- `family49` is strictly inflationary. -/
theorem input_lt_family49 (n : Nat) : n < family49 n :=
  Nat.lt_trans (input_lt_F49 n) (input_lt_F49 (F49 n))

/-- The first reflected resource bound grows strictly. -/
theorem input_lt_budget50 (N : Nat) (t : Ordinal.CTree) : N < budget50 N t := by
  simpa [budget50] using
    (input_lt_semanticBudget50 family49 input_lt_family49 N t)

/-- Remeasuring the first universe-collapsed output yields a strictly larger
second resource universe. -/
theorem budget50_lt_secondBudget50 (N : Nat) (t : Ordinal.CTree) :
    budget50 N t < secondBudget50 N t := by
  simpa [secondBudget50] using
    (input_lt_semanticBudget50 family49 input_lt_family49
      (budget50 N t) (firstUniverse50 N t))

/-- The strict second pass also holds for every first-class operator supplied to
the dynamic closure. -/
theorem budget50_lt_reflectiveSecondBudget50 (N : Nat)
    (J : Ordinal.CTree → Ordinal.CTree) (t : Ordinal.CTree) :
    budget50 N t < reflectiveSecondBudget50 N J t := by
  simpa [reflectiveSecondBudget50] using
    (input_lt_semanticBudget50 family49 input_lt_family49
      (budget50 N t) (closeU (budget50 N t) J t))

/-- At calibration `family49 n`, the first tree-generated resource bound already
exceeds four nested applications of the previous family. -/
theorem family49_fourfold_lt_budget50 (n : Nat) (t : Ordinal.CTree) :
    family49 (family49 (family49 (family49 n))) <
      budget50 (family49 n) t := by
  simpa [budget50] using
    (tripleCalibration_lt_semanticBudget50 family49 (family49 n) t)

/-- The actual entry point is the larger second reflected budget. -/
theorem family49_fourfold_lt_entry50 (n : Nat) :
    family49 (family49 (family49 (family49 n))) < entry50 n := by
  have h₁ : family49 (family49 (family49 (family49 n))) <
      budget50 (calibration50 n) (seed50 n) := by
    simpa [calibration50] using family49_fourfold_lt_budget50 n (seed50 n)
  have h₂ : budget50 (calibration50 n) (seed50 n) < entry50 n := by
    simpa [entry50] using
      budget50_lt_secondBudget50 (calibration50 n) (seed50 n)
  exact Nat.lt_trans h₁ h₂

/-- The final successor-base hierarchy strictly exceeds its entry point. -/
theorem entry50_lt_F50 (n : Nat) : entry50 n < F50 n :=
  Nat.lt_of_lt_of_le (Nat.lt_succ_self (entry50 n))
    (Ordinal.le_hier (fun x => Nat.le_of_lt (Nat.lt_succ_self x))
      (tree50 n) (entry50 n)).1

/-- Strong pointwise numerical lower bound. -/
theorem family49_fourfold_lt_F50 (n : Nat) :
    family49 (family49 (family49 (family49 n))) < F50 n :=
  Nat.lt_trans (family49_fourfold_lt_entry50 n) (entry50_lt_F50 n)

private theorem family49_lt_family49_fourfold (n : Nat) :
    family49 n < family49 (family49 (family49 (family49 n))) :=
  Nat.lt_trans (input_lt_family49 (family49 n))
    (Nat.lt_trans (input_lt_family49 (family49 (family49 n)))
      (input_lt_family49 (family49 (family49 (family49 n)))))

/-- At every input, `F50` exceeds Contender 49's family. -/
theorem family49_lt_F50 (n : Nat) : family49 n < F50 n :=
  Nat.lt_trans (family49_lt_family49_fourfold n) (family49_fourfold_lt_F50 n)

/-- The new family is strictly inflationary. -/
theorem input_lt_F50 (n : Nat) : n < F50 n :=
  Nat.lt_trans (input_lt_family49 n) (family49_lt_F50 n)

/-- Direct strong bound at the contest input. -/
theorem family49_fourfold_42_lt_contender_50 :
    family49 (family49 (family49 (family49 42))) < contender_50 := by
  change family49 (family49 (family49 (family49 42))) < F50 (F50 42)
  exact Nat.lt_trans (family49_fourfold_lt_F50 42) (input_lt_F50 (F50 42))

/-- **Required comparison:** the pinned repository champion is smaller. -/
theorem contender_49_lt_contender_50 : contender_49 < contender_50 := by
  change family49 42 < F50 (F50 42)
  exact Nat.lt_trans (family49_lt_F50 42) (input_lt_F50 (F50 42))

/-- Hence Contender 48 is smaller as well. -/
theorem contender_48_lt_contender_50 : contender_48 < contender_50 :=
  Nat.lt_trans contender_48_lt_contender_49 contender_49_lt_contender_50

end BusyLean
