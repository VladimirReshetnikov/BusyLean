import BusyLean.Contender41

/-!
# A tree-indexed hyperhierarchy of tree hierarchies

Contender 38 introduced `hier g t : Nat → Nat`, a fast-growing numerical
hierarchy that consumes the tree `t` directly. Contender 41 supplies a much
stronger `readerTree`: its ladder programs receive the input tree and a tree
recursor, so the generated tree transformation genuinely depends on its
argument.

This module makes a separate higher-order move. For a fixed object tree `t`,
write

  `H_t(g) = hier g t`.

Then `hyperHier g a t` iterates the whole hierarchy-forming operator `H_t`
along a second, independent meta-tree `a`:

* at zero it is the base function `g`;
* at a successor it applies the complete object-tree hierarchy once more;
* at a limit it takes the maximum over the first `m+1` meta-branches.

Both tree dimensions are used by arithmetic recursion. The limit maximum is
robust to the zero padding used in BusyLean's generated program trees. All
recursion is structural on the meta-tree, and `hier` is itself structural on
the object tree.
-/

namespace BusyLean.Ordinal

/-- Iterate the operator `g ↦ hier g t` along the meta-tree `a`.

`hyperHier g a t m` has two independent tree dimensions:

* `a` controls how often the *whole hierarchy constructor* is promoted;
* `t` is traversed by every promoted hierarchy.
-/
def hyperHier (g : Nat → Nat) : CTree → CTree → Nat → Nat
  | .zero, _, m => g m
  | .succ a, t, m => hier (hyperHier g a t) t m
  | .lim f, t, m => maxUpTo (fun i => hyperHier g (f i) t m) m
  | .supL _, _, m => g m
  | .supH _, _, m => g m

@[simp] theorem hyperHier_zero (g : Nat → Nat) (t : CTree) (m : Nat) :
    hyperHier g .zero t m = g m := rfl

@[simp] theorem hyperHier_succ (g : Nat → Nat) (a t : CTree) (m : Nat) :
    hyperHier g (.succ a) t m = hier (hyperHier g a t) t m := rfl

@[simp] theorem hyperHier_lim (g : Nat → Nat) (f : Nat → CTree)
    (t : CTree) (m : Nat) :
    hyperHier g (.lim f) t m =
      maxUpTo (fun i => hyperHier g (f i) t m) m := rfl

end BusyLean.Ordinal
