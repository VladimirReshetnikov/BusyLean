import BusyLean.Ordinal.TreeHyperHierarchy

/-!
# Contender 42: a self-promoting reader-tree hyperhierarchy

```
family41 n := F41 (F41 n)
hyperTree42 n := readerTree (family41 n)
metaTree42 n := succ (hyperTree42 n)
F42 n := hyperHier family41 (metaTree42 n)
           (hyperTree42 n) (family41 n)
contender_42 := F42 (F42 42)
```

Contender 41 uses one direct fast-growing hierarchy along `readerTree`. Its
reader programs can inspect and recurse over their input tree. Contender 42
promotes the *entire hierarchy-forming operator* `g ↦ hier g T` and iterates
that operator along a second copy of the reader tree.

The previous family controls the base function, the reader-program depth, the
numeric input, the object-tree hierarchy, and the meta-tree iteration. Unlike
address-ladder size heuristics, both selected trees are consumed by arithmetic
recursion: finite program-depth erasure cannot remove either recursion.

**Do not evaluate `contender_42`.**
-/

namespace BusyLean

/-- Contender 41's construction as a function of its input:
`family41 42 = contender_41`. -/
def family41 (n : Nat) : Nat := F41 (F41 n)

/-- The previous family chooses the depth of Contender 41's reader tree. -/
def hyperTree42 (n : Nat) : Ordinal.CTree :=
  readerTree (family41 n)

/-- A successor guarantees one final complete object-tree hierarchy above the
transfinite meta-iteration. -/
def metaTree42 (n : Nat) : Ordinal.CTree :=
  .succ (hyperTree42 n)

/-- Two-dimensional reader-tree hyperhierarchy based on Contender 41's family. -/
def F42 (n : Nat) : Nat :=
  Ordinal.hyperHier family41 (metaTree42 n) (hyperTree42 n)
    (family41 n)

/-- **Contender 42.** Never evaluate it. -/
def contender_42 : Nat := F42 (F42 42)

end BusyLean
