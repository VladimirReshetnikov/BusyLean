import BusyLean.Contender42
import BusyLean.Comparison41

/-! # Contender 42: comparison theorems -/

namespace BusyLean.Ordinal

/-- The hyperhierarchy dominates its base and its numeric argument whenever
the base is inflationary. -/
theorem le_hyperHier {g : Nat → Nat} (hg : ∀ x, x ≤ g x) :
    ∀ (a t : CTree) (m : Nat),
      g m ≤ hyperHier g a t m ∧ m ≤ hyperHier g a t m := by
  intro a
  induction a with
  | zero =>
      intro t m
      exact ⟨Nat.le_refl _, hg m⟩
  | succ a ih =>
      intro t m
      show g m ≤ hier (hyperHier g a t) t m ∧
        m ≤ hier (hyperHier g a t) t m
      have hbase : ∀ x, x ≤ hyperHier g a t x :=
        fun x => (ih t x).2
      have hstep := le_hier hbase t m
      exact ⟨Nat.le_trans (ih t m).1 hstep.1, hstep.2⟩
  | lim f ih =>
      intro t m
      show g m ≤ maxUpTo (fun i => hyperHier g (f i) t m) m ∧
        m ≤ maxUpTo (fun i => hyperHier g (f i) t m) m
      have h0 := le_maxUpTo
        (fun i => hyperHier g (f i) t m) (Nat.zero_le m)
      exact ⟨Nat.le_trans (ih 0 t m).1 h0,
        Nat.le_trans (ih 0 t m).2 h0⟩
  | supL _ _ =>
      intro t m
      exact ⟨Nat.le_refl _, hg m⟩
  | supH _ _ =>
      intro t m
      exact ⟨Nat.le_refl _, hg m⟩

/-- One meta-successor is exactly one application of the complete object-tree
hierarchy constructor. -/
theorem hyperHier_one (g : Nat → Nat) (t : CTree) (m : Nat) :
    hyperHier g (.succ .zero) t m = hier g t m := rfl

end BusyLean.Ordinal

namespace BusyLean

/-- Inputs are below Contender 41's doubled family. -/
theorem input_lt_family41 (n : Nat) : n < family41 n :=
  Nat.lt_trans (input_lt_F41 n) (input_lt_F41 (F41 n))

/-- A fourfold self-composition of `F41` is a pointwise lower bound for `F42`. -/
theorem family41_iterate_le_F42 (n : Nat) :
    family41 (family41 n) ≤ F42 n :=
  (Ordinal.le_hyperHier
    (fun x => Nat.le_of_lt (input_lt_family41 x))
    (metaTree42 n) (hyperTree42 n) (family41 n)).1

/-- The preceding theorem, expanded into the incumbent function. -/
theorem F41_fourfold_le_F42 (n : Nat) :
    F41 (F41 (F41 (F41 n))) ≤ F42 n := by
  change family41 (family41 n) ≤ F42 n
  exact family41_iterate_le_F42 n

/-- At every input, `F42` strictly exceeds Contender 41's doubled family. -/
theorem family41_lt_F42 (n : Nat) : family41 n < F42 n :=
  Nat.lt_of_lt_of_le (input_lt_family41 (family41 n))
    (family41_iterate_le_F42 n)

/-- `F42` is strictly inflationary. -/
theorem input_lt_F42 (n : Nat) : n < F42 n :=
  Nat.lt_trans (input_lt_family41 n) (family41_lt_F42 n)

/-- Pointwise domination of the incumbent fast-growing function. -/
theorem F41_lt_F42 (n : Nat) : F41 n < F42 n :=
  Nat.lt_trans (input_lt_F41 (F41 n)) (family41_lt_F42 n)

/-- **Required comparison:** Contender 41 is strictly below Contender 42. -/
theorem contender_41_lt_contender_42 : contender_41 < contender_42 :=
  Nat.lt_trans (family41_lt_F42 42) (input_lt_F42 (F42 42))

/-- The previous two official contenders are also below the new contender. -/
theorem contender_40_lt_contender_42 : contender_40 < contender_42 :=
  Nat.lt_trans contender_40_lt_contender_41
    contender_41_lt_contender_42

end BusyLean
