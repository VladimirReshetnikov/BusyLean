import BusyLean.Comparison42

/-! Kernel dependency audit. Run with `lake env lean test/Audit42.lean`. -/

#print axioms BusyLean.Ordinal.hyperHier
#print axioms BusyLean.Ordinal.le_hyperHier
#print axioms BusyLean.hyperTree42
#print axioms BusyLean.F42
#print axioms BusyLean.contender_42
#print axioms BusyLean.F41_fourfold_le_F42
#print axioms BusyLean.F41_lt_F42
#print axioms BusyLean.contender_41_lt_contender_42
