import BusyLean.Comparison42

/-!
Small executable checks for the generic hierarchy only. They use finite
successor trees and tiny numerals; no BusyLean contender is evaluated.
-/

open BusyLean.Ordinal

namespace BusyLean.Test

private def fin42 : Nat → CTree
  | 0 => .zero
  | k + 1 => .succ (fin42 k)

private def omega42 : CTree := .lim fin42

#eval hyperHier Nat.succ .zero (fin42 1) 3
-- 4: meta-zero is the base function.

#eval hyperHier Nat.succ (fin42 1) (fin42 1) 3
-- 7: one meta-successor applies the object hierarchy once.

#eval hyperHier Nat.succ (fin42 2) (fin42 1) 3
-- 63: the complete first hierarchy becomes the base of the second.

#eval hyperHier Nat.succ omega42 (fin42 1) 2
-- 23: maximum over meta-stages 0, 1, and 2.

#eval hyperHier Nat.succ
  (.lim fun i => if i = 1 then fin42 2 else .zero) (fin42 1) 2
-- 23: zero padding does not lower a meta-limit.

example (g : Nat → Nat) (t : CTree) (m : Nat) :
    hyperHier g (.succ .zero) t m = hier g t m := by
  rfl

end BusyLean.Test
