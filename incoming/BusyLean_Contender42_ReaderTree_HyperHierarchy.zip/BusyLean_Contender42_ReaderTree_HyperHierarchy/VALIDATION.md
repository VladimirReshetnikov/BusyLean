# Validation status

## Baseline

- Repository: `VladimirReshetnikov/BusyLean`
- Pinned commit: `6afe0cdbd2005ea37500585d89f1dd8bab43b039`
- Official incumbent at that commit: Contender 41
- Declared toolchain: `leanprover/lean4:v4.34.0`

## Checks completed in the artifact runtime

1. A source audit over all supplied Lean files found no `sorry`, `admit`,
   `axiom`, `unsafe`, or `partial` declarations.
2. Required definitions and theorem names are present; delimiters are
   balanced.
3. The executable contender definition does not mention the closed constants
   `contender_41`, `contender_40`, or `contender_39`.
4. An independent Python model reproduced all five generic smoke values:
   `4, 7, 63, 23, 23`.
5. The LaTeX article compiled successfully with LuaLaTeX; text extraction,
   PDF preflight, Ghostscript parsing, and page-render inspection passed.
6. The integration patch and archive manifest were checked mechanically.

## Check not completed here

The runtime did not contain Lean, Lake, or Elan, and network access was not
available for installing Lean 4.34.0 or cloning a complete checkout. Therefore
no claim is made that the supplied Lean files were kernel-elaborated in this
environment.

Run the exact missing check with:

```bash
./BUILD.sh /path/to/BusyLean
```

or manually at the pinned commit:

```bash
lake build BusyLean.Comparison41
lake build BusyLean.Contender42
lake build BusyLean.Comparison42
lake env lean test/HyperHierarchySmoke.lean
lake env lean test/Audit42.lean
```

## Expected axiom envelope

`test/Audit42.lean` prints the axiom dependencies of the new definitions and
proofs. The repository's accepted audit permits only `propext` and
`Quot.sound` in the relevant dependency closure. The supplied source
introduces no new axiom declaration.
