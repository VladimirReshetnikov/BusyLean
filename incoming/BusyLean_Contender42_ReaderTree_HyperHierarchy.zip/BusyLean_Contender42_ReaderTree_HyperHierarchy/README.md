# BusyLean Contender 42: Self-Promoting Reader-Tree Hyperhierarchy

This package proposes a new closed Lean natural number for the BusyLean
repository. The research freeze is pinned to commit
`6afe0cdbd2005ea37500585d89f1dd8bab43b039` (13 October 2026), where the
official incumbent is Contender 41.

## Definition

Contender 41 constructs `readerTree N` from ladder programs that receive their
input tree and a tree recursor, then applies one direct numerical hierarchy
`hier` to that tree. Define the hierarchy-forming operator

```text
H_T(g) = hier g T.
```

Contender 42 iterates `H_T` along a second tree:

```lean
def hyperHier (g : Nat -> Nat) : CTree -> CTree -> Nat -> Nat
  | .zero,   _, m => g m
  | .succ a, t, m => hier (hyperHier g a t) t m
  | .lim f,  t, m => maxUpTo (fun i => hyperHier g (f i) t m) m
  | .supL _, _, m => g m
  | .supH _, _, m => g m
```

The closed contender is

```lean
def family41 (n : Nat) : Nat := F41 (F41 n)
def hyperTree42 (n : Nat) : CTree := readerTree (family41 n)
def metaTree42 (n : Nat) : CTree := .succ (hyperTree42 n)
def F42 (n : Nat) : Nat :=
  hyperHier family41 (metaTree42 n) (hyperTree42 n) (family41 n)
def contender_42 : Nat := F42 (F42 42)
```

Thus Contender 41's doubled family controls the base function, reader-program
depth, numerical seed, object-tree hierarchy, and meta-tree promotion of the
whole hierarchy constructor.

## Formal comparison target

`Comparison42.lean` contains proofs of:

- `F41 (F41 (F41 (F41 n))) <= F42 n` for every `n`;
- `F41 (F41 n) < F42 n` for every `n`;
- `F41 n < F42 n` for every `n`;
- `contender_41 < contender_42`;
- `contender_40 < contender_42`.

The first bound is a useful quantitative guardrail: even before using the
full structural interpretation, `F42 n` dominates a fourfold self-composition
of the incumbent function.

## Why this survives the finite-atom correction

The BusyLean Contender 38 report observes that bounded ladder programs see
only finite atom truncations. The proposed numerical step does not infer size
from an address order. `hyperHier` pattern-matches the meta-tree directly and
calls `hier`, which pattern-matches the object tree directly. Successors cause
value-dependent iteration; limits cause finite maxima. Both tree dimensions
therefore participate in arithmetic recursion.

## Contents

- `article.tex`, `article.pdf` - research article and compiled PDF.
- `Lean/BusyLean/Ordinal/TreeHyperHierarchy.lean` - generic two-tree hierarchy.
- `Lean/BusyLean/Contender42.lean` - closed definition.
- `Lean/BusyLean/Comparison42.lean` - comparison theorems.
- `Lean/test/HyperHierarchySmoke.lean` - small executable examples.
- `Lean/test/Audit42.lean` - `#print axioms` audit commands.
- `integration.patch` - suggested repository integration patch.
- `BUILD.sh` - isolated worktree build script for Lean 4.34.0.
- `scripts/static_audit.py` - source-level audit used in this environment.
- `scripts/reference_model.py` - independent tiny Python model.
- `VALIDATION.md` - exact validation status and limitations.
- `MANIFEST.sha256` - hashes for all package files except itself.

## Build against BusyLean

With a local checkout of BusyLean available:

```bash
./BUILD.sh /path/to/BusyLean
```

The script creates a detached temporary worktree at the pinned commit, copies
in the new modules, appends the three imports to `BusyLean.lean`, and runs the
baseline build, definition build, proof build, smoke test, and axiom audit
without modifying the caller's working tree.

Do not evaluate `contender_42` itself. Its Lean definition is executable in
principle, but evaluation is intentionally infeasible.
