# Design notes: Contender 42

## Pinned baseline

The proposal targets BusyLean commit
`6afe0cdbd2005ea37500585d89f1dd8bab43b039`. At that research freeze the
official incumbent is Contender 41:

```text
family40 n = F40(F40(n))
F41 n = hier family40 (readerTree (family40 n)) (family40 n)
contender_41 = F41(F41(42)).
```

`readerTree N` is generated from SystemFLT2 reader programs. Such programs
receive tree constructors, a tree recursor, and the input tree itself, so the
jump genuinely depends on its argument.

## New operator

For a fixed tree `T`, Contender 41 forms one function `H_T(g) = hier g T`.
Contender 42 iterates the complete operator `H_T` along a second tree:

```text
hyperHier(g, 0,     T, m) = g(m)
hyperHier(g, S(A), T, m) = hier(hyperHier(g,A,T), T, m)
hyperHier(g, lim f,T, m) = max_{i <= m} hyperHier(g,f(i),T,m).
```

The finite maximum makes the limit clause robust to padded zero branches in
program-generated trees. Recursion on the meta-tree is structural; every
successor invokes the already structural object-tree hierarchy.

## Closed diagonal

At input `n`, let

```text
s = family41 n = F41(F41(n))
T = readerTree s
A = succ T
F42(n) = hyperHier family41 A T s.
```

The previous family now controls five resources: base function, reader-tree
generation depth, numerical seed, object hierarchy, and meta-hierarchy.

## Formal lower bounds

The invariant `le_hyperHier` states that an inflationary base `g` and the
numeric argument are below `hyperHier g A T m`. Taking `g = family41` and
`m = family41 n` gives

```text
family41(family41(n)) <= F42(n),
```

which expands to

```text
F41(F41(F41(F41(n)))) <= F42(n).
```

Since `family41` is strictly inflationary, the package also proves
`family41 n < F42 n`, `F41 n < F42 n`, and finally
`contender_41 < contender_42`.

## Novelty and nonclaims

The novelty is not the easy comparison wrapper. It is a second structural
tree dimension that promotes an entire hierarchy constructor, analogous to a
conservative tree-indexed hyperation. No canonical ordinal calibration is
claimed. Establishing monotonicity under tree simulations and comparison with
standard hyperation/fast-growing hierarchies remains future work.
