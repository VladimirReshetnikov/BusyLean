#!/usr/bin/env bash
set -euo pipefail

BASE="6afe0cdbd2005ea37500585d89f1dd8bab43b039"
URL="https://github.com/VladimirReshetnikov/BusyLean.git"
PKG_DIR="$(cd "$(dirname "$0")" && pwd)"
TMP="$(mktemp -d)"
WORK="$TMP/BusyLean-contender42"
SOURCE_REPO="${1:-}"

cleanup() {
  if [[ -n "$SOURCE_REPO" && -d "$WORK" ]]; then
    git -C "$SOURCE_REPO" worktree remove --force "$WORK" >/dev/null 2>&1 || true
  fi
  rm -rf "$TMP"
}
trap cleanup EXIT

if [[ -n "$SOURCE_REPO" ]]; then
  SOURCE_REPO="$(cd "$SOURCE_REPO" && pwd)"
  git -C "$SOURCE_REPO" cat-file -e "$BASE^{commit}"
  git -C "$SOURCE_REPO" worktree add --detach "$WORK" "$BASE"
else
  git clone --no-checkout "$URL" "$WORK"
  git -C "$WORK" checkout --detach "$BASE"
fi

mkdir -p "$WORK/BusyLean/Ordinal" "$WORK/test"
cp "$PKG_DIR/Lean/BusyLean/Ordinal/TreeHyperHierarchy.lean" \
  "$WORK/BusyLean/Ordinal/TreeHyperHierarchy.lean"
cp "$PKG_DIR/Lean/BusyLean/Contender42.lean" \
  "$WORK/BusyLean/Contender42.lean"
cp "$PKG_DIR/Lean/BusyLean/Comparison42.lean" \
  "$WORK/BusyLean/Comparison42.lean"
cp "$PKG_DIR/Lean/test/HyperHierarchySmoke.lean" \
  "$WORK/test/HyperHierarchySmoke.lean"
cp "$PKG_DIR/Lean/test/Audit42.lean" "$WORK/test/Audit42.lean"

for imp in \
  'import BusyLean.Ordinal.TreeHyperHierarchy' \
  'import BusyLean.Contender42' \
  'import BusyLean.Comparison42'; do
  grep -qxF "$imp" "$WORK/BusyLean.lean" || echo "$imp" >> "$WORK/BusyLean.lean"
done

cd "$WORK"

echo "== Toolchain =="
cat lean-toolchain
command -v lake >/dev/null || {
  echo "ERROR: lake is not available; install Lean 4.34.0 via elan." >&2
  exit 2
}

echo "== Accepted baseline =="
lake build BusyLean.Comparison41

echo "== Contender 42 definitions =="
time lake build BusyLean.Contender42

echo "== Contender 42 proofs =="
time lake build BusyLean.Comparison42

echo "== Tiny executable checks =="
lake env lean test/HyperHierarchySmoke.lean

echo "== Axiom audit =="
lake env lean test/Audit42.lean

echo "PASS: Contender 42 package kernel-checked at $BASE"
