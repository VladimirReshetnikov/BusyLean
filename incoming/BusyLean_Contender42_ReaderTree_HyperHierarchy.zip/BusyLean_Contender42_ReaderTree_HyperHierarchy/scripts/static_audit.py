#!/usr/bin/env python3
"""Conservative source audit for the Contender 42 package.

This is a lexical/structural audit, not a substitute for Lean's elaborator and
kernel. It records exactly what was checked in the artifact environment.
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LEAN_ROOT = ROOT / "Lean"
FILES = sorted(LEAN_ROOT.rglob("*.lean"))
PROHIBITED = {
    "sorry": re.compile(r"\bsorry\b"),
    "admit": re.compile(r"\badmit\b"),
    "axiom": re.compile(r"\baxiom\b"),
    "unsafe": re.compile(r"\bunsafe\b"),
    "partial": re.compile(r"\bpartial\b"),
}
REQUIRED = {
    "BusyLean/Ordinal/TreeHyperHierarchy.lean": [
        "def hyperHier",
        "theorem hyperHier_zero",
    ],
    "BusyLean/Contender42.lean": [
        "def family41",
        "def hyperTree42",
        "def metaTree42",
        "def F42",
        "def contender_42",
    ],
    "BusyLean/Comparison42.lean": [
        "theorem le_hyperHier",
        "theorem F41_fourfold_le_F42",
        "theorem family41_lt_F42",
        "theorem F41_lt_F42",
        "theorem contender_41_lt_contender_42",
    ],
    "test/HyperHierarchySmoke.lean": [
        "import BusyLean.Comparison42",
    ],
    "test/Audit42.lean": [
        "#print axioms BusyLean.contender_42",
    ],
}


def strip_comments_and_strings(text: str) -> str:
    out: list[str] = []
    i = 0
    depth = 0
    in_string = False
    while i < len(text):
        if depth:
            if text.startswith("/-", i):
                depth += 1
                i += 2
            elif text.startswith("-/", i):
                depth -= 1
                i += 2
            else:
                i += 1
            continue
        if in_string:
            if text[i] == "\\":
                i += 2
            elif text[i] == '"':
                in_string = False
                i += 1
            else:
                i += 1
            continue
        if text.startswith("/-", i):
            depth = 1
            i += 2
        elif text.startswith("--", i):
            j = text.find("\n", i)
            i = len(text) if j < 0 else j
        elif text[i] == '"':
            in_string = True
            i += 1
        else:
            out.append(text[i])
            i += 1
    if depth or in_string:
        raise ValueError("unterminated block comment or string")
    return "".join(out)


def balanced(text: str) -> tuple[bool, str]:
    cleaned = strip_comments_and_strings(text)
    pairs = {')': '(', ']': '[', '}': '{'}
    stack: list[tuple[str, int]] = []
    for pos, ch in enumerate(cleaned):
        if ch in "([{":
            stack.append((ch, pos))
        elif ch in pairs:
            if not stack or stack[-1][0] != pairs[ch]:
                return False, f"unmatched {ch!r} near stripped offset {pos}"
            stack.pop()
    if stack:
        return False, f"unclosed {stack[-1][0]!r} near stripped offset {stack[-1][1]}"
    return True, "ok"


report: dict[str, object] = {
    "audit_kind": "static source audit; not Lean kernel validation",
    "baseline_commit": "6afe0cdbd2005ea37500585d89f1dd8bab43b039",
    "files": {},
}
failures: list[str] = []

for path in FILES:
    rel = path.relative_to(LEAN_ROOT).as_posix()
    text = path.read_text(encoding="utf-8")
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    bad = [name for name, pat in PROHIBITED.items() if pat.search(text)]
    ok_bal, bal_msg = balanced(text)
    report["files"][rel] = {
        "sha256": digest,
        "bytes": path.stat().st_size,
        "lines": len(text.splitlines()),
        "max_line_length": max((len(x) for x in text.splitlines()), default=0),
        "declaration_count": len(re.findall(
            r"(?m)^\s*(?:def|theorem|abbrev|inductive|structure|class|instance)\s+",
            text,
        )),
        "prohibited_tokens": bad,
        "delimiters": bal_msg,
    }
    if bad:
        failures.append(f"{rel}: prohibited tokens: {', '.join(bad)}")
    if not ok_bal:
        failures.append(f"{rel}: {bal_msg}")

for rel, needles in REQUIRED.items():
    path = LEAN_ROOT / rel
    if not path.exists():
        failures.append(f"missing required file: {rel}")
        continue
    text = path.read_text(encoding="utf-8")
    for needle in needles:
        if needle not in text:
            failures.append(f"{rel}: missing required marker {needle!r}")

# Definition hygiene: the executable definition uses F41/family41, never an
# earlier closed contender constant.
definition_code = strip_comments_and_strings(
    (LEAN_ROOT / "BusyLean/Contender42.lean").read_text(encoding="utf-8")
)
for forbidden in ("contender_41", "contender_40", "contender_39"):
    if re.search(rf"\b{re.escape(forbidden)}\b", definition_code):
        failures.append(
            f"BusyLean/Contender42.lean: executable code mentions {forbidden!r}"
        )

checks = {
    "lean_file_count": len(FILES),
    "required_markers_present": not any("missing required" in f for f in failures),
    "no_sorry_admit_axiom_unsafe_partial": not any(
        "prohibited tokens" in f for f in failures
    ),
    "balanced_delimiters": not any(
        "unmatched" in f or "unclosed" in f for f in failures
    ),
    "definition_avoids_previous_contender_constants": not any(
        "executable code mentions" in f for f in failures
    ),
    "kernel_compiled": False,
    "kernel_compile_note": (
        "Lean 4.34.0 and a complete checkout were unavailable in the artifact "
        "environment. Run BUILD.sh against the pinned checkout."
    ),
}
report["checks"] = checks
report["status"] = "PASS" if not failures else "FAIL"
report["failures"] = failures

(ROOT / "artifacts" / "static_audit.json").write_text(
    json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)
lines = [
    f"Static audit: {report['status']}",
    f"Baseline: {report['baseline_commit']}",
    f"Lean files: {len(FILES)}",
    "Kernel compilation: NOT RUN (see VALIDATION.md)",
    "",
]
for rel, data in report["files"].items():
    lines.append(
        f"{rel}: {data['lines']} lines, {data['declaration_count']} declarations, "
        f"max line {data['max_line_length']}, sha256 {data['sha256']}"
    )
if failures:
    lines += ["", "Failures:", *[f"- {f}" for f in failures]]
(ROOT / "artifacts" / "static_audit.txt").write_text(
    "\n".join(lines) + "\n", encoding="utf-8"
)
print("\n".join(lines))
raise SystemExit(0 if not failures else 1)
