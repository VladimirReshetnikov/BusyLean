#!/usr/bin/env python3
"""Tiny independent model for the finite smoke tests.

This does not attempt to evaluate any BusyLean contender.  It implements only
finite/queried fragments of the generic `hier` and `hyperHier` recursions.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Union


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Succ:
    pred: "Tree"


@dataclass(frozen=True)
class Lim:
    branch: Callable[[int], "Tree"]


Tree = Union[Zero, Succ, Lim]
ZERO = Zero()


def fin(n: int) -> Tree:
    if n < 0:
        raise ValueError("n must be nonnegative")
    t: Tree = ZERO
    for _ in range(n):
        t = Succ(t)
    return t


def iter_n(h: Callable[[int], int], k: int, x: int) -> int:
    for _ in range(k):
        x = h(x)
    return x


def max_up_to(h: Callable[[int], int], m: int) -> int:
    return max(h(i) for i in range(m + 1))


def hier(g: Callable[[int], int], t: Tree, m: int) -> int:
    if isinstance(t, Zero):
        return g(m)
    if isinstance(t, Succ):
        return iter_n(lambda x: hier(g, t.pred, x), m + 1, m)
    if isinstance(t, Lim):
        return max_up_to(lambda i: hier(g, t.branch(i), m), m)
    raise TypeError(t)


def hyper_hier(g: Callable[[int], int], a: Tree, t: Tree, m: int) -> int:
    if isinstance(a, Zero):
        return g(m)
    if isinstance(a, Succ):
        return hier(lambda x: hyper_hier(g, a.pred, t, x), t, m)
    if isinstance(a, Lim):
        return max_up_to(lambda i: hyper_hier(g, a.branch(i), t, m), m)
    raise TypeError(a)


def main() -> None:
    succ = lambda x: x + 1
    omega = Lim(fin)
    padded = Lim(lambda i: fin(2) if i == 1 else ZERO)
    values = [
        hyper_hier(succ, ZERO, fin(1), 3),
        hyper_hier(succ, fin(1), fin(1), 3),
        hyper_hier(succ, fin(2), fin(1), 3),
        hyper_hier(succ, omega, fin(1), 2),
        hyper_hier(succ, padded, fin(1), 2),
    ]
    expected = [4, 7, 63, 23, 23]
    if values != expected:
        raise SystemExit(f"FAIL: got {values}, expected {expected}")
    print("PASS:", *values)


if __name__ == "__main__":
    main()
