## Suggested README insertion

### Current contender: Contender 42

```lean
def family41 (n : Nat) : Nat := F41 (F41 n)
def hyperTree42 (n : Nat) : Ordinal.CTree := readerTree (family41 n)
def metaTree42 (n : Nat) : Ordinal.CTree := .succ (hyperTree42 n)
def F42 (n : Nat) : Nat :=
  Ordinal.hyperHier family41 (metaTree42 n) (hyperTree42 n) (family41 n)
def contender_42 : Nat := F42 (F42 42)

theorem contender_41_lt_contender_42 : contender_41 < contender_42
```

Contender 41 reads one `readerTree` with one direct fast-growing hierarchy.
Contender 42 iterates the whole hierarchy-forming operator
`g ↦ hier g T` along a second copy of the reader tree. Both tree dimensions
are consumed directly by arithmetic recursion.

| Theorem | Statement |
|---|---|
| `F41_fourfold_le_F42` | `F41^[4] n <= F42 n` at every input |
| `family41_lt_F42` | `F41 (F41 n) < F42 n` at every input |
| `F41_lt_F42` | `F41 n < F42 n` at every input |
| `contender_41_lt_contender_42` | Contender 41 < Contender 42 |
