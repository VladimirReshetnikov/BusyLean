# Validation record

## Repository audit

- Base commit: `c2f81dcb0f59d6cab513dc36fd9f1a1c17ff1516`.
- Current verified entry there: Contender 25.
- Pinned Lean version: `v4.34.0`.
- Reused formal interfaces:
  `FL.avalue`, `Ordinal.bigTree`, `Ordinal.Addr`, `Ordinal.addrUpTo`,
  `wDiagonalLift`, `wDiagonalLift_preservesProgressive`,
  `wDiagonalLift_strictlyInflationary`, and `input_lt_F25`.

## Checks performed locally

- Scanned the proposed Lean modules and audit file for `sorry`, `admit`,
  `axiom`, `noncomputable`, `partial`, `unsafe`, `opaque`, `implemented_by`,
  `extern`, `run_cmd`, `initialize`, and `#eval`.
- Confirmed that no definition in `Contender26.lean` mentions the constant
  `contender_25`; it uses the predecessor construction `F25`.
- Checked source inventory, delimiter balance, import names, theorem-name
  consistency, and the repository-relative patch mechanically.
- Compiled the LaTeX article, extracted its text, rendered every page, and
  visually inspected the rendered output.

## Kernel replay status

Lean 4.34.0 was not installed in the artifact-generation environment, and a
network toolchain installation was unavailable. Therefore no kernel-validation
claim is made. The reviewer should integrate the files into the base checkout
and run `scripts/check_submission.sh`, or execute the five `lake env lean`
commands in `README.md`.

## Expected axiom audit

`test/Contender26Audit.lean` prints the axiom closures of the load-bearing
results. The expected closure is inherited from the verified BusyLean
normalization and quotient infrastructure (normally `propext` and
`Quot.sound`). The actual Lean output is decisive.

## Claims deliberately not made

- No claim that `bigTree` is formally monotone in its natural parameter.
- No claim that the new address language formally contains Contender 25's
  language; proving a translated-language embedding is listed as future work.
- No numerical evaluation or decimal-size estimate.
- No literature-priority claim beyond novelty relative to the audited
  repository state.
