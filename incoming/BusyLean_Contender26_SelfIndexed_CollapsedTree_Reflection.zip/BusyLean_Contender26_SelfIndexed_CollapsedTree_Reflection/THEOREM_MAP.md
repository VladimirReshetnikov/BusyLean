# Theorem map

## Generic indexed-address reflection

| Declaration | Purpose |
|---|---|
| `FL.addrLadderAt` | Separates collapsed-tree parameter `L` from syntax budget `n`. |
| `reflectAddressFamilyAt` | Finite maximum over visible oracle values and accepted address-ladder programs. |
| `indexedAddressTransformer` | Packages the reflector as a `Transformer`. |
| `lt_reflectAddressFamilyAt` | Additive guard strictly exceeds the finite maximum. |
| `oracle_lt_reflectAddressFamilyAt` | Every visible oracle coordinate is dominated. |
| `addressValue_lt_reflectAddressFamilyAt` | Every enumerated accepted program is dominated. |
| `indexedAddressTransformer_progressive` | Supplies the amplifier's required `Progressive` hypothesis. |

## Predecessor-derived levels and orbit

| Declaration | Purpose |
|---|---|
| `family25` | Predecessor construction as a family; `family25 42 = contender_25`. |
| `iterateF25` | Structural finite iteration of `F25`. |
| `baseLevel26` | Two predecessor-family jumps. |
| `treeLevel26` | `baseLevel26 n + 1` further `F25` iterations; parameter of `bigTree`. |
| `seed26` | Visible `F25` orbit above `treeLevel26`. |
| `schedule26`, `rank26` | Self-fed W-tree schedule and rank. |
| `F26`, `contender_26` | Inner function and final closed natural. |

## Exact comparison chain

```text
contender_25
  < baseLevel26 42
  < treeLevel26 42
  < seed26 0 42
  < F26 42
  < contender_26
```

The corresponding Lean declarations are:

1. `contender_25_lt_baseLevel26_42`;
2. `baseLevel26_lt_treeLevel26`;
3. `treeLevel26_lt_seed26_zero`;
4. `seed26_lt_F26`;
5. `input_lt_F26` at the outer input;
6. `contender_25_lt_contender_26`.

## Language and orbit lower bounds

- `treeLevel26Value_lt_F26`: every enumerated accepted program over
  `Addr (bigTree (treeLevel26 n))` is below `F26 n`.
- `long_F25_orbit_lt_contender_26`: the final number exceeds an explicit
  `F25` orbit of length `F26 42 + 2` at the outer self-indexed tree level.
