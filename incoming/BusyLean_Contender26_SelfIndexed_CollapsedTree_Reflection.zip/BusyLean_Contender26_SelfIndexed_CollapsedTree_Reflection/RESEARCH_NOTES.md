# Research notes

## Design choice

The most consequential feature of the new verified Contender 25 is that the
universe ladder is indexed by addresses in a Lean-defined well-founded tree.
Well-foundedness is structural, so the tree parameter can be enlarged without
constructing a separate linear ordinal-notation system. The present proposal
pushes exactly that interface: it keeps the same trusted address semantics and
normalization theorem, but makes the tree parameter an enormous value produced
from the predecessor itself.

## Why two nested scales are used

`baseLevel26 n = family25 (family25 n)` gives an immediate, transparent
comparison with the previous closed contender. `treeLevel26 n` then iterates
`F25` a further `baseLevel26 n + 1` times. This second scale is not needed for a
bare successor theorem; it is included to make the language parameter itself a
substantial predecessor orbit rather than merely one more family application.

## Why the seed is separate from the language parameter

The object-language level and the oracle seed play different formal roles.
`treeLevel26` selects `bigTree`; `seed26` supplies a countable family to the
reflector and amplifier. Starting the seed above the language level yields a
clean structural chain while avoiding any unsupported monotonicity theorem for
reflection or for `bigTree`.

## Proof discipline

Reflection can branch on exact oracle values and is not monotone in its oracle.
Every strict inequality therefore follows one of four explicit witnesses:

1. a visible oracle coordinate in `prefixMax`;
2. a program value in `BigNumber.maximum`;
3. a visible seed coordinate in `Progressive`;
4. the base transformer occurrence in the strict-inflation theorem for
   `wDiagonalLift`.

## Main formalization risk

The package was not kernel-replayed locally. The highest-risk proof is the
small induction `input_lt_iterateF25_succ`; its statement and proof follow the
same orientation used by earlier reviewed orbit proposals. All remaining
proofs are direct instantiations of theorem shapes already present in
`Comparison25.lean` and `TreeHyperReflectionFacts.lean`.

## High-value follow-up

The strongest next theorem would be a translation/embedding from programs over
`Addr (bigTree a)` to programs over `Addr (bigTree b)` under a formally proved
relation between `a` and `b`. That would turn the present parameter jump into a
formal language-inclusion result, rather than relying on the intended ordinal
interpretation of `bigTree`.
