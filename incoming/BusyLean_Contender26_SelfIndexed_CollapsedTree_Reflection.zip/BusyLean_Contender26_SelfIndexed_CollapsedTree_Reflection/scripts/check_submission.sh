#!/usr/bin/env bash
set -euo pipefail

root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$root"

printf '%s\n' '== Static forbidden-token scan =='
if grep -RInE '^[[:space:]]*(#eval|run_cmd|initialize|unsafe|partial|noncomputable|opaque|extern|axiom|sorry\b|admit\b)' \
    BusyLean test; then
  echo 'Forbidden or review-required construct found.' >&2
  exit 1
fi

printf '%s\n' '== No direct use of the previous contender constant in definitions =='
if grep -nE '^[[:space:]]*def .*contender_25' BusyLean/Contender26.lean; then
  echo 'contender_25 must not occur in a definition.' >&2
  exit 1
fi

printf '%s\n' '== No evaluation commands =='
if grep -RInE '^[[:space:]]*#eval' BusyLean test; then
  echo '#eval is forbidden for this submission.' >&2
  exit 1
fi

printf '%s\n' '== Lean source inventory =='
find BusyLean test -type f -name '*.lean' -print | sort

if command -v lake >/dev/null 2>&1; then
  printf '%s\n' '== Kernel build with the surrounding BusyLean checkout =='
  lake env lean BusyLean/SelfIndexedAddressReflection.lean
  lake env lean BusyLean/SelfIndexedAddressReflectionFacts.lean
  lake env lean BusyLean/Contender26.lean
  lake env lean BusyLean/Comparison26.lean
  lake env lean test/Contender26Audit.lean
else
  printf '%s\n' 'lake not found; static checks completed, kernel build skipped.'
fi
