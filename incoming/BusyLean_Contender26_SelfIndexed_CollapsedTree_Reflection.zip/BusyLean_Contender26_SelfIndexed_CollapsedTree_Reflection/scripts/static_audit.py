#!/usr/bin/env python3
"""Conservative static checks for the Contender 26 proposal.

This is not a Lean parser and is not a substitute for kernel replay. It catches
common packaging mistakes before the files are integrated into BusyLean.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LEAN_FILES = sorted((ROOT / "BusyLean").glob("*.lean")) + sorted((ROOT / "test").glob("*.lean"))

FORBIDDEN = re.compile(
    r"^\s*(?:#eval|run_cmd|initialize|unsafe|partial|noncomputable|opaque|extern|axiom|sorry\b|admit\b)",
    re.MULTILINE,
)
REQUIRED_DECLS = {
    "SelfIndexedAddressReflection.lean": [
        "def addrLadderAt",
        "def reflectAddressFamilyAt",
        "def indexedAddressTransformer",
    ],
    "SelfIndexedAddressReflectionFacts.lean": [
        "theorem lt_reflectAddressFamilyAt",
        "theorem oracle_lt_reflectAddressFamilyAt",
        "theorem addressValue_lt_reflectAddressFamilyAt",
        "theorem indexedAddressTransformer_progressive",
    ],
    "Contender26.lean": [
        "def family25",
        "def iterateF25",
        "def baseLevel26",
        "def treeLevel26",
        "def seed26",
        "def schedule26",
        "def rank26",
        "def F26",
        "def contender_26",
    ],
    "Comparison26.lean": [
        "theorem contender_25_lt_treeLevel26_42",
        "theorem treeLevel26Value_lt_F26",
        "theorem long_F25_orbit_lt_contender_26",
        "theorem contender_25_lt_contender_26",
    ],
}


def strip_comments_and_strings(text: str) -> str:
    out: list[str] = []
    i = 0
    comment_depth = 0
    in_string = False
    while i < len(text):
        if comment_depth:
            if text.startswith("/-", i):
                comment_depth += 1
                out.extend("  ")
                i += 2
            elif text.startswith("-/", i):
                comment_depth -= 1
                out.extend("  ")
                i += 2
            else:
                out.append("\n" if text[i] == "\n" else " ")
                i += 1
            continue
        if in_string:
            if text[i] == "\\" and i + 1 < len(text):
                out.extend("  ")
                i += 2
            elif text[i] == '"':
                in_string = False
                out.append(" ")
                i += 1
            else:
                out.append("\n" if text[i] == "\n" else " ")
                i += 1
            continue
        if text.startswith("/-", i):
            comment_depth = 1
            out.extend("  ")
            i += 2
        elif text.startswith("--", i):
            end = text.find("\n", i)
            if end == -1:
                out.extend(" " * (len(text) - i))
                i = len(text)
            else:
                out.extend(" " * (end - i))
                out.append("\n")
                i = end + 1
        elif text[i] == '"':
            in_string = True
            out.append(" ")
            i += 1
        else:
            out.append(text[i])
            i += 1
    if comment_depth or in_string:
        raise ValueError("unterminated comment or string")
    return "".join(out)


def check_delimiters(path: Path, text: str) -> list[str]:
    clean = strip_comments_and_strings(text)
    pairs = {')': '(', ']': '[', '}': '{'}
    stack: list[tuple[str, int]] = []
    errors: list[str] = []
    for lineno, line in enumerate(clean.splitlines(), 1):
        for ch in line:
            if ch in "([{":
                stack.append((ch, lineno))
            elif ch in pairs:
                if not stack or stack[-1][0] != pairs[ch]:
                    errors.append(f"{path.name}:{lineno}: unmatched {ch}")
                else:
                    stack.pop()
    errors.extend(f"{path.name}:{line}: unclosed {ch}" for ch, line in stack)
    return errors


def main() -> int:
    errors: list[str] = []
    print(f"Auditing {len(LEAN_FILES)} Lean files under {ROOT}")
    for path in LEAN_FILES:
        text = path.read_text(encoding="utf-8")
        print(f"  {path.relative_to(ROOT)}: {len(text.splitlines())} lines")
        if FORBIDDEN.search(strip_comments_and_strings(text)):
            errors.append(f"{path}: forbidden executable token")
        errors.extend(check_delimiters(path, text))
        for needle in REQUIRED_DECLS.get(path.name, []):
            if needle not in text:
                errors.append(f"{path}: missing declaration marker {needle!r}")

    contender = (ROOT / "BusyLean" / "Contender26.lean").read_text(encoding="utf-8")
    executable = strip_comments_and_strings(contender)
    if re.search(r"^\s*def[^\n]*contender_25", executable, re.MULTILINE):
        errors.append("Contender26.lean: predecessor constant occurs in a definition")
    if "#eval" in executable:
        errors.append("Contender26.lean: evaluation command present")

    patch = ROOT / "patches" / "contender26.patch"
    if not patch.is_file() or "BusyLean/Comparison26.lean" not in patch.read_text(encoding="utf-8"):
        errors.append("integration patch missing or incomplete")

    if errors:
        print("\nFAILED")
        for error in errors:
            print(f"- {error}")
        return 1
    print("\nPASS: static consistency checks completed.")
    print("NOTE: this is not a Lean kernel check.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
