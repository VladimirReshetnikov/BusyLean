#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "usage: $0 /path/to/BusyLean-checkout" >&2
  exit 2
fi

src="$(cd "$(dirname "$0")/.." && pwd)"
dst="$(cd "$1" && pwd)"

for f in \
  BusyLean/SelfIndexedAddressReflection.lean \
  BusyLean/SelfIndexedAddressReflectionFacts.lean \
  BusyLean/Contender26.lean \
  BusyLean/Comparison26.lean; do
  install -D -m 0644 "$src/$f" "$dst/$f"
done
install -D -m 0644 "$src/test/Contender26Audit.lean" "$dst/test/Contender26Audit.lean"

if ! grep -q 'BusyLean.SelfIndexedAddressReflection' "$dst/BusyLean.lean"; then
  cat >> "$dst/BusyLean.lean" <<'IMPORTS'
import BusyLean.SelfIndexedAddressReflection
import BusyLean.SelfIndexedAddressReflectionFacts
import BusyLean.Contender26
import BusyLean.Comparison26
IMPORTS
fi

printf 'Integrated files into %s\n' "$dst"
printf '%s\n' 'Run:'
printf '  cd %q && lake env lean BusyLean/Comparison26.lean\n' "$dst"
printf '  cd %q && lake env lean test/Contender26Audit.lean\n' "$dst"
