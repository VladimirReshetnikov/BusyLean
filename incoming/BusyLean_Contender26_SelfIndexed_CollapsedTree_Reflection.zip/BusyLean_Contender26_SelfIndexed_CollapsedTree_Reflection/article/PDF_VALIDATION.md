# PDF validation

- Engine: pdfTeX via `latexmk -pdf`.
- Pages: 19, US Letter.
- Searchable text: verified with `pdftotext`.
- Replacement characters/NUL bytes in extracted text: 0/0.
- Box diagnostics: no overfull or underfull boxes in the final LaTeX log.
- Visual inspection: all 19 pages rendered at 160 dpi with the PDF skill
  renderer; title page, table of contents, equations, Lean listings, module
  table, appendices, and references were inspected for clipping and overlap.
