# BusyLean proposal: Contender 26 — self-indexed collapsed-tree reflection

**Target repository:** `VladimirReshetnikov/BusyLean`  
**Base commit:** `c2f81dcb0f59d6cab513dc36fd9f1a1c17ff1516`  
**Pinned toolchain:** `leanprover/lean4:v4.34.0`  
**Previous verified entry:** Contender 25

## Core definition

```lean
def family25 (n : Nat) : Nat := F25 (F25 n)
def baseLevel26 (n : Nat) : Nat := family25 (family25 n)
def treeLevel26 (n : Nat) : Nat :=
  iterateF25 (baseLevel26 n + 1) (baseLevel26 n)
def seed26 : Family :=
  fun i n => iterateF25 (i + 2) (treeLevel26 n)

def F26 (n : Nat) : Nat :=
  wDiagonalLift (schedule26 n) (rank26 n)
    (indexedAddressTransformer treeLevel26) seed26 n n

def contender_26 : Nat := F26 (F26 42)
```

The definition never mentions the constant `contender_25`. It reuses the
previous construction `F25`, which is permitted as a seed/oracle mechanism.

## Why it is a substantial jump

Contender 25 reflects programs over addresses in `Ordinal.bigTree n` at input
`n`. This proposal reflects programs over

```text
Ordinal.Addr (Ordinal.bigTree (treeLevel26 n)),
```

where `treeLevel26 n` is obtained only after two predecessor-family jumps and
then `baseLevel26 n + 1` further iterations of `F25`. The formal comparison
stack proves

```text
contender_25
  < baseLevel26 42
  < treeLevel26 42
  < seed26 0 42
  < F26 42
  < contender_26.
```

It also proves that every enumerated accepted depth-`n` program in the selected
self-indexed address language, run with the packed orbit seed, is below `F26 n`.
The final contender has the explicit lower bound

```text
iterateF25 (F26 42 + 2) (treeLevel26 (F26 42)) < contender_26.
```

No oracle-monotonicity assumption is used.

## Artifact map

- `BusyLean/SelfIndexedAddressReflection.lean`: decouples the collapsed-tree
  parameter from the syntax budget.
- `BusyLean/SelfIndexedAddressReflectionFacts.lean`: explicit maximum bounds
  and generic progressivity.
- `BusyLean/Contender26.lean`: the proposed construction.
- `BusyLean/Comparison26.lean`: strict comparison, program domination, and
  orbit lower bounds.
- `test/Contender26Audit.lean`: declaration and axiom inspection only.
- `article/self_indexed_collapsed_tree_reflection.tex` and `.pdf`: full paper.
- `patches/contender26.patch`: repository-relative integration patch.
- `scripts/integrate.sh`: deterministic copy/import helper.
- `scripts/check_submission.sh`: static screening and optional kernel replay.
- `THEOREM_MAP.md`, `RESEARCH_NOTES.md`, and `VALIDATION.md`: reviewer notes.

## Replay in a BusyLean checkout

```bash
unzip BusyLean_Contender26_SelfIndexed_CollapsedTree_Reflection.zip
cd BusyLean_Contender26_SelfIndexed_CollapsedTree_Reflection
./scripts/integrate.sh /path/to/BusyLean
cd /path/to/BusyLean
lake env lean BusyLean/SelfIndexedAddressReflection.lean
lake env lean BusyLean/SelfIndexedAddressReflectionFacts.lean
lake env lean BusyLean/Contender26.lean
lake env lean BusyLean/Comparison26.lean
lake env lean test/Contender26Audit.lean
```

Do not run `#eval` on `baseLevel26`, `treeLevel26`, `seedHeight26`, `F26`, or
`contender_26` at the contest input.

## Validation status

The Lean sources were statically screened and written against the declarations
at the exact base commit above. The artifact-generation environment did not
contain Lean 4.34.0, so this archive does **not** claim a local kernel replay.
The exact replay and audit commands are included. The LaTeX article was compiled
and its rendered pages were visually inspected.
