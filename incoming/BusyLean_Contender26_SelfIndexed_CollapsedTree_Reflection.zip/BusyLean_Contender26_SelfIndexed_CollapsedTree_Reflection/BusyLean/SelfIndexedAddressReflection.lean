import BusyLean.Contender25

/-!
# Reflection over collapsed-tree address ladders chosen by a level function

Contender 25 uses the universe ladder over the valid addresses of
`Ordinal.bigTree n` at numerical input `n`. This module separates the tree
parameter from the syntax budget. For an arbitrary computable
`level : Nat → Nat`, input `n` enumerates programs of syntax depth at most `n`
over the atoms `Ordinal.Addr (Ordinal.bigTree (level n))`.

The construction is total and executable in principle. It reuses Contender
25's normalization theorem `FL.sn_erase_addr`; no new normalization argument
or ordinal-notation well-foundedness proof is required.
-/

namespace BusyLean.FL

open Ordinal

/-- Programs of syntax depth at most `n` over addresses in `bigTree L`.

Unlike `addrLadderUpTo`, the collapsed-tree parameter and syntax budget are
independent.
-/
def addrLadderAt (L n : Nat) : List (CTm (Addr (bigTree L))) :=
  ctmsUpTo (addrUpTo (bigTree L) n) n

end BusyLean.FL

namespace BusyLean

open BusyLean.W

/-- Reflection over an address ladder selected by `level`.

The result explicitly exceeds every visible oracle coordinate at input `n`
and every accepted program in `FL.addrLadderAt (level n) n`, when that program
is run with the packed oracle family.
-/
def reflectAddressFamilyAt (level : Nat → Nat) (fs : Family) (n : Nat) : Nat :=
  n + 1 + BigNumber.maxN
    (prefixMax (fun i => fs i n) n)
    (BigNumber.maximum
      (FL.avalue (level n) (packFamily fs) n)
      (FL.addrLadderAt (level n) n))

/-- The indexed-address reflector packaged as a transformer.
The output coordinate is deliberately ignored. -/
def indexedAddressTransformer (level : Nat → Nat) : Transformer :=
  fun fs _ n => reflectAddressFamilyAt level fs n

end BusyLean
