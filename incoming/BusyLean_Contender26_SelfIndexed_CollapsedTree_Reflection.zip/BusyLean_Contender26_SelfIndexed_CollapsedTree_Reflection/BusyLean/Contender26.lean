import BusyLean.SelfIndexedAddressReflectionFacts
import BusyLean.Contender25

/-!
# Contender 26: self-indexed collapsed-tree address reflection

```
family25 n      := F25 (F25 n)
baseLevel26 n   := family25 (family25 n)
treeLevel26 n   := iterateF25 (baseLevel26 n + 1) (baseLevel26 n)
seed26 i n      := iterateF25 (i + 2) (treeLevel26 n)
F26 n           := wDiagonalLift (schedule26 n) (rank26 n)
                     (indexedAddressTransformer treeLevel26) seed26 n n
contender_26    := F26 (F26 42)
```

Contender 25 uses the address ladder over `Ordinal.bigTree n` at input `n`.
Contender 26 self-indexes that new language by a natural number already far
above Contender 25. First `baseLevel26 n` applies the predecessor family twice.
Then `treeLevel26 n` performs `baseLevel26 n + 1` further iterations of `F25`.
Programs at input `n` therefore live over

`Ordinal.Addr (Ordinal.bigTree (treeLevel26 n))`.

The seed is a visible `F25` orbit beginning above that tree parameter. Its
zero coordinate is `family25 (treeLevel26 n)`. The W-ranked amplifier is also
resized from a far-out visible seed coordinate and is built above Contender
25's rank at the self-indexed tree level.

All recursion is structural and computable in principle. **Never evaluate
`contender_26`, `F26 42`, `treeLevel26 42`, or their constituents.**
-/

namespace BusyLean

open BigNumber (WTree)
open BusyLean.W

/-- Contender 25's construction as a function of its input.
Definitionally, `family25 42 = contender_25`. -/
def family25 (n : Nat) : Nat := F25 (F25 n)

/-- Finite iteration of `F25`, oriented so that a successor count exposes one
outer application of `F25`. -/
def iterateF25 : Nat → Nat → Nat
  | 0, n => n
  | k + 1, n => F25 (iterateF25 k n)

/-- A first self-indexed level, already strictly above the predecessor family. -/
def baseLevel26 (n : Nat) : Nat := family25 (family25 n)

/-- The parameter of the collapsed tree reflected at input `n`.

It is obtained by iterating `F25` `baseLevel26 n + 1` times from
`baseLevel26 n`.
-/
def treeLevel26 (n : Nat) : Nat :=
  iterateF25 (baseLevel26 n + 1) (baseLevel26 n)

/-- A countable visible orbit above the new tree parameter. Coordinate zero is
`family25 (treeLevel26 n)`. -/
def seed26 : Family := fun i n => iterateF25 (i + 2) (treeLevel26 n)

/-- A far-out visible orbit value used to size the schedule and rank. -/
def seedHeight26 (n : Nat) : Nat := seed26 (treeLevel26 n) n

/-- A schedule above Contender 25's rank at the self-indexed tree level. -/
def schedule26 (n : Nat) : WTree Nat :=
  Autonomous.realize
    (Autonomous.hyper (seedHeight26 n + 42)
      (Autonomous.encode (rank25 (treeLevel26 n))))

/-- A second autonomous notation above the whole schedule. -/
def rank26 (n : Nat) : WTree Nat :=
  Autonomous.realize
    (Autonomous.hyper (seedHeight26 n + 42)
      (Autonomous.encode (schedule26 n)))

/-- W-ranked hyperreflection over the self-indexed collapsed-tree language. -/
def F26 (n : Nat) : Nat :=
  wDiagonalLift (schedule26 n) (rank26 n)
    (indexedAddressTransformer treeLevel26) seed26 n n

/-- **Contender 26.** Never evaluate it. -/
def contender_26 : Nat := F26 (F26 42)

end BusyLean
