import BusyLean.SelfIndexedAddressReflection
import BusyLean.TreeHyperReflectionFacts

/-!
# Growth facts for indexed collapsed-tree address reflection

All inequalities use explicit occurrences in finite maxima. They never assume
monotonicity in the oracle family; such monotonicity is false because reflected
programs may inspect and branch on oracle values.
-/

namespace BusyLean

open BusyLean.W

/-- Anything below the finite maximum is strictly below the reflected value. -/
theorem lt_reflectAddressFamilyAt {level : Nat → Nat} {fs : Family} {n m : Nat}
    (h : m ≤ BigNumber.maxN (prefixMax (fun i => fs i n) n)
      (BigNumber.maximum
        (FL.avalue (level n) (packFamily fs) n)
        (FL.addrLadderAt (level n) n))) :
    m < reflectAddressFamilyAt level fs n := by
  show m < n + 1 + _
  have hM : ∀ M : Nat, M + 1 ≤ n + 1 + M := fun M => by
    rw [Nat.add_comm M 1]
    exact Nat.add_le_add_right (Nat.le_add_left 1 n) M
  exact Nat.lt_of_le_of_lt h
    (Nat.lt_of_lt_of_le (Nat.lt_succ_self _) (hM _))

/-- Every visible oracle value is below indexed-address reflection. -/
theorem oracle_lt_reflectAddressFamilyAt (level : Nat → Nat) (fs : Family)
    {i n : Nat} (hi : i ≤ n) :
    fs i n < reflectAddressFamilyAt level fs n :=
  lt_reflectAddressFamilyAt
    (Nat.le_trans (le_prefixMax (fun j => fs j n) hi)
      (BigNumber.le_maxN_left _ _))

/-- Every enumerated, accepted indexed-address program is below reflection. -/
theorem addressValue_lt_reflectAddressFamilyAt (level : Nat → Nat) (fs : Family)
    {n : Nat} {t : FL.CTm (Ordinal.Addr (Ordinal.bigTree (level n)))}
    (ht : t ∈ FL.addrLadderAt (level n) n) :
    FL.avalue (level n) (packFamily fs) n t <
      reflectAddressFamilyAt level fs n :=
  lt_reflectAddressFamilyAt
    (Nat.le_trans
      (le_maximum (FL.avalue (level n) (packFamily fs) n) ht)
      (BigNumber.le_maxN_right _ _))

/-- Indexed-address reflection is progressive for every level function. -/
theorem indexedAddressTransformer_progressive (level : Nat → Nat) :
    Progressive (indexedAddressTransformer level) := by
  intro seed i o n hi
  exact oracle_lt_reflectAddressFamilyAt level seed hi

end BusyLean
