import BusyLean.Contender26
import BusyLean.Comparison25

/-!
# Contender 26: comparison theorems

The principal result is `contender_25_lt_contender_26`. Stronger structural
facts show that at input `42` the collapsed-tree parameter itself exceeds
Contender 25, a visible seed coordinate exceeds that parameter, and the full
inner function exceeds both. Every accepted program over the self-indexed
address ladder is also below the inner function.
-/

namespace BusyLean

open BusyLean.W

/-- The predecessor family is pointwise progressive in its numerical input. -/
theorem input_lt_family25 (n : Nat) : n < family25 n :=
  Nat.lt_trans (input_lt_F25 n) (input_lt_F25 (F25 n))

/-- One further finite `F25` iterate is strictly larger. This uses only
`input_lt_F25`, never oracle monotonicity. -/
theorem iterateF25_lt_succ (k n : Nat) :
    iterateF25 k n < iterateF25 (k + 1) n := by
  simpa only [iterateF25] using input_lt_F25 (iterateF25 k n)

/-- Any positive finite `F25` orbit from `n` strictly exceeds `n`. -/
theorem input_lt_iterateF25_succ (k n : Nat) :
    n < iterateF25 (k + 1) n := by
  induction k with
  | zero =>
      simpa only [iterateF25] using input_lt_F25 n
  | succ k ih =>
      exact Nat.lt_trans ih (iterateF25_lt_succ (k + 1) n)

/-- The first new level strictly exceeds the previous family value. -/
theorem family25_lt_baseLevel26 (n : Nat) : family25 n < baseLevel26 n :=
  input_lt_family25 (family25 n)

/-- At input `42`, even the first new level exceeds Contender 25. -/
theorem contender_25_lt_baseLevel26_42 : contender_25 < baseLevel26 42 := by
  change family25 42 < family25 (family25 42)
  exact input_lt_family25 (family25 42)

/-- The collapsed-tree parameter is above an orbit whose length is itself the
first new level. -/
theorem baseLevel26_lt_treeLevel26 (n : Nat) :
    baseLevel26 n < treeLevel26 n := by
  simpa only [treeLevel26] using
    input_lt_iterateF25_succ (baseLevel26 n) (baseLevel26 n)

/-- The actual tree parameter at input `42` already exceeds Contender 25. -/
theorem contender_25_lt_treeLevel26_42 : contender_25 < treeLevel26 42 :=
  Nat.lt_trans contender_25_lt_baseLevel26_42
    (baseLevel26_lt_treeLevel26 42)

/-- Coordinate zero is exactly two more `F25` iterations above the tree
parameter. -/
theorem seed26_zero (n : Nat) : seed26 0 n = family25 (treeLevel26 n) := rfl

/-- The visible seed already strictly exceeds the self-indexed tree parameter. -/
theorem treeLevel26_lt_seed26_zero (n : Nat) :
    treeLevel26 n < seed26 0 n := by
  rw [seed26_zero]
  exact input_lt_family25 (treeLevel26 n)

/-- Every visible seed-orbit coordinate lies below `F26 n`. -/
theorem seed26_lt_F26 {i n : Nat} (hi : i ≤ n) : seed26 i n < F26 n :=
  ((wDiagonalLift_preservesProgressive (schedule26 n) (rank26 n))
    (indexedAddressTransformer treeLevel26)
    (indexedAddressTransformer_progressive treeLevel26))
    seed26 i n n hi

/-- The new inner function exceeds its own collapsed-tree parameter. -/
theorem treeLevel26_lt_F26 (n : Nat) : treeLevel26 n < F26 n :=
  Nat.lt_trans (treeLevel26_lt_seed26_zero n)
    (seed26_lt_F26 (i := 0) (n := n) (Nat.zero_le n))

/-- At every input, `F26` exceeds Contender 25's family. -/
theorem family25_lt_F26 (n : Nat) : family25 n < F26 n :=
  Nat.lt_trans (family25_lt_baseLevel26 n)
    (Nat.lt_trans (baseLevel26_lt_treeLevel26 n) (treeLevel26_lt_F26 n))

/-- The inner stage at the contest input already exceeds Contender 25. -/
theorem contender_25_lt_F26_42 : contender_25 < F26 42 :=
  Nat.lt_trans contender_25_lt_treeLevel26_42 (treeLevel26_lt_F26 42)

/-- The unamplified self-indexed reflection is strictly below `F26`. -/
theorem raw26_lt_F26 (n : Nat) :
    reflectAddressFamilyAt treeLevel26 seed26 n < F26 n :=
  (wDiagonalLift_strictlyInflationary (schedule26 n) (rank26 n))
    (indexedAddressTransformer treeLevel26)
    (indexedAddressTransformer_progressive treeLevel26)
    seed26 n n n (Nat.le_refl n)

/-- Every accepted program of depth at most `n` over the addresses of
`bigTree (treeLevel26 n)`, run with the packed seed orbit, is below `F26 n`. -/
theorem treeLevel26Value_lt_F26 {n : Nat}
    {t : FL.CTm (Ordinal.Addr (Ordinal.bigTree (treeLevel26 n)))}
    (ht : t ∈ FL.addrLadderAt (treeLevel26 n) n) :
    FL.avalue (treeLevel26 n) (packFamily seed26) n t < F26 n :=
  Nat.lt_trans
    (addressValue_lt_reflectAddressFamilyAt treeLevel26 seed26 ht)
    (raw26_lt_F26 n)

/-- `F26` itself is pointwise progressive in its numerical input. -/
theorem input_lt_F26 (n : Nat) : n < F26 n :=
  Nat.lt_trans (input_lt_family25 n) (family25_lt_F26 n)

/-- A strong closed lower bound: the final contender exceeds an `F25` orbit
whose length is itself `F26 42 + 2`, starting at the self-indexed tree level
selected at the outer input. -/
theorem long_F25_orbit_lt_contender_26 :
    iterateF25 (F26 42 + 2) (treeLevel26 (F26 42)) < contender_26 := by
  simpa only [seed26, contender_26] using
    (seed26_lt_F26 (i := F26 42) (n := F26 42) (Nat.le_refl _))

/-- **The required comparison:** Contender 25 is strictly below Contender 26. -/
theorem contender_25_lt_contender_26 : contender_25 < contender_26 :=
  Nat.lt_trans (family25_lt_F26 42) (input_lt_F26 (F26 42))

/-- Consequently every earlier verified contender is also below Contender 26. -/
theorem contender_24_lt_contender_26 : contender_24 < contender_26 :=
  Nat.lt_trans contender_24_lt_contender_25 contender_25_lt_contender_26

end BusyLean
