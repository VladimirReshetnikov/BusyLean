import BusyLean.Comparison26

-- These commands inspect declarations only; they do not evaluate a large
-- number. The reviewer should confirm that the output contains only axioms
-- already accepted by BusyLean (normally `propext` and `Quot.sound`).

#print axioms BusyLean.indexedAddressTransformer_progressive
#print axioms BusyLean.treeLevel26Value_lt_F26
#print axioms BusyLean.long_F25_orbit_lt_contender_26
#print axioms BusyLean.contender_25_lt_contender_26

#check @BusyLean.FL.addrLadderAt
#check @BusyLean.reflectAddressFamilyAt
#check @BusyLean.indexedAddressTransformer
#check @BusyLean.family25
#check @BusyLean.iterateF25
#check @BusyLean.baseLevel26
#check @BusyLean.treeLevel26
#check @BusyLean.seed26
#check @BusyLean.F26
#check @BusyLean.contender_26
#check @BusyLean.contender_25_lt_baseLevel26_42
#check @BusyLean.baseLevel26_lt_treeLevel26
#check @BusyLean.contender_25_lt_treeLevel26_42
#check @BusyLean.treeLevel26_lt_F26
#check @BusyLean.treeLevel26Value_lt_F26
#check @BusyLean.long_F25_orbit_lt_contender_26
#check @BusyLean.contender_25_lt_contender_26
