#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 1 ]; then
  echo "usage: $0 /path/to/BusyLean" >&2
  exit 2
fi

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TARGET="$(cd "$1" && pwd)"

for f in BusyLean/Contender41.lean BusyLean/Comparison41.lean BusyLean.lean README.md test/Audit.lean; do
  if [ ! -f "$TARGET/$f" ]; then
    echo "missing expected BusyLean file: $TARGET/$f" >&2
    exit 1
  fi
done

install -m 0644 "$ROOT/BusyLean/SemanticDiagonal.lean" "$TARGET/BusyLean/SemanticDiagonal.lean"
install -m 0644 "$ROOT/BusyLean/Contender42.lean" "$TARGET/BusyLean/Contender42.lean"
install -m 0644 "$ROOT/BusyLean/Comparison42.lean" "$TARGET/BusyLean/Comparison42.lean"
install -m 0644 "$ROOT/test/SemanticDiagonalSmoke.lean" "$TARGET/test/SemanticDiagonalSmoke.lean"
install -m 0644 "$ROOT/test/Contender42Audit.lean" "$TARGET/test/Contender42Audit.lean"

python - "$ROOT" "$TARGET" <<'PY'
from pathlib import Path
import sys

root = Path(sys.argv[1])
target = Path(sys.argv[2])

imports = (root / "integration/BusyLean.lean.append").read_text()
umbrella = target / "BusyLean.lean"
text = umbrella.read_text()
if "import BusyLean.SemanticDiagonal" not in text:
    if text and not text.endswith("\n"):
        text += "\n"
    umbrella.write_text(text + imports)

audit_snippet = (root / "integration/Audit.lean.append").read_text()
audit = target / "test/Audit.lean"
text = audit.read_text()
if "#print axioms BusyLean.SD.rankEval" not in text:
    if text and not text.endswith("\n"):
        text += "\n"
    audit.write_text(text + "\n" + audit_snippet)

section = (root / "integration/README-section.md").read_text().rstrip()
baseline41 = (root / "integration/README-contender41-baseline.md").read_text().rstrip()
readme = target / "README.md"
text = readme.read_text()
if "## Current contender: Contender 42" not in text:
    heading41 = "## Current contender: Contender 41"
    heading40 = "## Current contender: Contender 40"
    if heading41 in text:
        text = text.replace(heading41, section + "\n\n## Contender 41", 1)
    elif heading40 in text:
        # Preceding commit e7831b integrates Contender 41 in source but its README
        # still starts at Contender 40. Insert the missing baseline section too.
        replacement = section + "\n\n" + baseline41 + "\n\n## Contender 40"
        text = text.replace(heading40, replacement, 1)
    else:
        raise SystemExit("README baseline heading not found (expected Contender 40 or 41)")
    readme.write_text(text)
PY

mkdir -p "$TARGET/.github/workflows"
install -m 0644 "$ROOT/integration/ci-contender42.yml" \
  "$TARGET/.github/workflows/contender42.yml"

echo "Contender 42 files installed into $TARGET"
echo "Run: cd '$TARGET' && lake build && lake env lean test/Contender42Audit.lean"
