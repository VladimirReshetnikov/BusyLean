## Contender 41

```lean
def family40 (n : Nat) : Nat := F40 (F40 n)                 -- Contender 40 = family40 42
def F41 (n : Nat) : Nat :=                                   -- BusyLean/Contender41.lean
  Ordinal.hier family40 (readerTree (family40 n)) (family40 n)
def contender_41 : Nat := F41 (F41 42)

theorem contender_40_lt_contender_41 : contender_40 < contender_41
```

`FLT2.jumpL` lets a typed impredicative ladder reader inspect its input tree.
Contender 41 joins that reader jump with Contender 40's transformer, closes the
result under first-class tree metalanguages, and reads the resulting tree with
`Ordinal.hier`. This compatibility section repairs the documentation lag at the preceding commit
`e7831bef2a7981889dbff42c3474eabaea0e3d62`, whose source and umbrella module
already integrate Contender 41 while the top README heading still names
Contender 40.
