## Current contender: Contender 42

```lean
def family41 (n : Nat) : Nat := F41 (F41 n)                 -- Contender 41 = family41 42
def F42 (n : Nat) : Nat := SD.rayo family41 n               -- BusyLean/Contender42.lean
def contender_42 : Nat := F42 (F42 42)

theorem contender_41_lt_contender_42 : contender_41 < contender_42
```

Contender 42 changes the growth mechanism.  `SD.Prog` is a finite,
intrinsically total unary language with composition, arithmetic, finite
iteration, an oracle, and a **rank-lowering semantic reflection** instruction.
At rank `k+1`, reflection enumerates a finite depth class and evaluates it only
at rank `k`.  Thus totality follows by structural recursion on the rank and
program; no ordinal notation or normalization axiom is used.

At input `n`, `SD.rayo family41 n` takes one plus the maximum of every rank-`n`
program of depth at most `n`, evaluated at `n`.  Consequently:

| Theorem | Statement |
|---|---|
| `SD.program_lt_rayo` | every rank-`n`, depth-`n` program is below the diagonal |
| `family41_lt_F42` | Contender 41's whole family is beaten pointwise |
| `contender41FoldIter_lt_F42_42` | the inner call beats `contender_41` family iterations |
| `contender41HorizonDiagonal_lt_F42_42` | it beats a rank-41 diagonal of depth `contender_41` |
| `contender_41_lt_F42_42` | Contender 41 is already below the inner call |
| `contender_41_lt_contender_42` | Contender 41 < Contender 42 |

The generic diagonalizer lives in `BusyLean/SemanticDiagonal.lean`, imports
only `Init`, and is independent of the earlier `wDiagonalLift`/tree-ordinal
lineage.  The previous family appears solely as the interpretation of the
language's oracle instruction.
