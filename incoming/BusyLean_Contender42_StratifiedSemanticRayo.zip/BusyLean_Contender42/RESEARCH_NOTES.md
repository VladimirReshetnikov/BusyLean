# Research notes and design alternatives

## Design objective

The repository already contains a long line of increasingly sophisticated
ordinal-tree, language-stacking, impredicative-jump, and hierarchy
constructions. A valid successor had to do more than choose a taller tree or
apply `wDiagonalLift` at one further meta-level. It also had to remain a closed,
constructive `Nat`, admit a short direct comparison, and be realistically
formalizable in Lean without hidden termination assumptions.

## Selected idea: ramified semantic closure

The selected construction treats finite program semantics themselves as a
first-class growth operator. A `reflect` instruction asks for one plus the
maximum value of a finite program class, but only at the preceding semantic
rank. The rank discipline is analogous to ramified truth predicates: a level
may talk about all lower levels but not about itself. This produces a universal
finite semantic diagonal while keeping evaluation total by ordinary recursion.

Three aspects are essential:

1. **Semantic rather than syntactic stacking.** Reflection ranges over values
   of all programs in a finite class, not merely over a fixed ordinal operator.
2. **Dynamic budgets.** The depth of an inner reflected class is itself a
   program value. The compact witness `.reflect .oracle .input` therefore turns
   the preceding contender into a syntax horizon.
3. **Intrinsic termination.** No normalization theorem, ordinal
   well-foundedness theorem, halting test, or classical choice is needed.

## Alternatives rejected

### Another tree-ordinal lift

A natural continuation would stack the Contender-41 reader jump under another
closure operator or hierarchy. This would likely prove a strict comparison,
but it would remain in the existing lineage and fail the request for a novel
mechanism.

### A simple predecessor iteration

Defining `F42 n` as many iterations of `family41` certainly gives a large
number and an easy proof, but it is almost pure piggybacking. The final
construction contains such an iteration only as one automatically dominated
program among millions of semantic programs.

### “Maximum of the previous contenders plus one”

This is formally sufficient but mathematically uninteresting, tightly coupled
to a fixed repository snapshot, and not a new source of growth.

### Unrestricted self-interpreter or Busy Beaver

Maximizing over arbitrary terminating Lean programs would require deciding
termination or importing a proof-carrying totality discipline. Maximizing over
arbitrary machines would be noncomputable. The rank-lowering language avoids
both problems: every enumerated syntax is total by construction.

### Full quotation of Lean terms

A kernel-level quotation and evaluator would be ambitious but would greatly
increase trusted implementation complexity and make the comparison depend on
subtle elaborator/kernel encodings. The purpose-built language isolates the
new mathematical idea and keeps the trusted core small.

## Why the predecessor oracle is legitimate

A sequential BusyLean contender must compare with the incumbent. Supplying
`family41` as the meaning of one generic oracle instruction is a controlled
interface, not the growth mechanism itself. The same `SD.rayo` works for every
oracle and is developed in a module importing only `Init`. The oracle is one
member of the finite language, while the diagonal simultaneously dominates
all combinations of arithmetic, composition, iteration, and lower-rank
reflection. Formal dependency-audit snippets make this separation testable.

## Strength and calibration

The archive proves exact natural-number inequalities, including the
predecessor-sized iteration and horizon bounds. It deliberately does not claim
a proof-theoretic ordinal calibration for the new hierarchy. A plausible next
research program is to classify fixed-rank fragments, study closure under
oracle substitution, and compare the resulting functions with ramified truth
and reflection progressions.

## Validation boundary

The mathematical and source-level audit is complete, the TeX/PDF pipeline and
integration artifacts are tested, and an independent Python model checks tiny
instances and enumerator cardinalities. The execution environment did not
provide Lean/Lake and did not permit fetching the approximately 580 MB pinned
binary toolchain, so this archive does not mislabel the Lean code as
kernel-replayed. A pinned GitHub Actions workflow and exact local commands are
included for that final validation step.
