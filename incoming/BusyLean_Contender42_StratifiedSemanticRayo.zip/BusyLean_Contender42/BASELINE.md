# Audited repository baseline

## Commit and toolchain

- Repository: `VladimirReshetnikov/BusyLean`
- Audited Git commit: `6afe0cdbd2005ea37500585d89f1dd8bab43b039`
- Default branch at the final audit: `main`
- Pinned toolchain: `leanprover/lean4:v4.34.0`

## Source-level incumbent

The incumbent at the audited commit is **Contender 41**. The top of
`README.md`, the umbrella module, and the comparison source agree. The decisive
source facts are:

```lean
-- BusyLean.lean
import BusyLean.SystemFLT2.Trees
import BusyLean.Contender41
import BusyLean.Comparison41
```

```lean
-- BusyLean/Contender41.lean
def family40 (n : Nat) : Nat := F40 (F40 n)
def F41 (n : Nat) : Nat :=
  Ordinal.hier family40 (readerTree (family40 n)) (family40 n)
def contender_41 : Nat := F41 (F41 42)
```

```lean
-- BusyLean/Comparison41.lean
theorem contender_40_lt_contender_41 : contender_40 < contender_41 := ...
```

The repository audit file also contains closure and axiom checks through
`contender_41`. Consequently, this proposal is numbered **Contender 42** and
proves `contender_41 < contender_42`.

## Documentation history and compatibility

While this package was being assembled, `main` moved from
`e7831bef2a7981889dbff42c3474eabaea0e3d62` to the audited commit above. The
single intervening commit changed only `README.md` and the repository article;
it corrected the top heading from Contender 40 to Contender 41. The contender
sources and umbrella imports did not change.

`integration/apply_to_checkout.sh` therefore recognizes both shapes:

1. the current README whose current heading is Contender 41; or
2. the immediately preceding lagging README whose current heading is
   Contender 40.

In the second case it inserts a compact Contender-41 baseline section before
adding the Contender-42 section. The installer was tested twice on that legacy
shape and was idempotent.

## Scope of the audit

The baseline audit was used to determine numbering, import names, the standard
two-call contender pattern, the predecessor comparison theorem, the no-direct-
predecessor-value convention, and the pinned Lean version. The new semantic
diagonal core itself imports only `Init` and does not reuse the incumbent’s
ordinal, tree-language, hierarchy, or reflection definitions.
