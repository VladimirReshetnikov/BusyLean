# Formal proof map

This file maps the mathematical argument to Lean declarations.

## 1. Finite total language

| Mathematical object or fact | Lean declaration |
|---|---|
| Unary program syntax | `BusyLean.SD.Prog` |
| Finite iteration | `BusyLean.SD.iterateNat` |
| Structural evaluator with supplied reflection | `BusyLean.SD.eval` |
| Programs of constructor depth at most `d` | `BusyLean.SD.programs` |
| Finite maximum | `BusyLean.SD.maximum` |

`eval` recurses only on strict subprograms. `programs d` is a concrete finite
list for every natural `d`; duplicates affect cost, not correctness.

## 2. Rank-lowering semantic reflection

| Mathematical object or fact | Lean declaration |
|---|---|
| One plus the finite semantic maximum | `BusyLean.SD.reflectMax` |
| Rank-indexed interpreter | `BusyLean.SD.rankEval` |
| Every visible program is below a reflection | `BusyLean.SD.program_lt_reflectMax` |

At rank `0`, reflection returns the value of its argument. At rank `k+1`, each
reflection evaluates enumerated programs only at rank `k`. This strict rank
drop is the totality certificate and blocks same-rank semantic self-reference.

## 3. Universal diagonal

```lean
def universal : Prog := .reflect .input .input

def rayo (oracle : Nat → Nat) (n : Nat) : Nat :=
  rankEval oracle (n + 1) universal n
```

The definitional equation is `SD.rayo_eq`. Membership in the finite maximum
gives the generic theorem:

```lean
theorem SD.program_lt_rayo (oracle : Nat → Nat)
    {n : Nat} {p : Prog} (hp : p ∈ SD.programs n) :
    SD.rankEval oracle n p n < SD.rayo oracle n
```

The oracle and input instructions are members at every depth, yielding
`SD.oracle_lt_rayo` and `SD.input_lt_rayo`.

## 4. BusyLean instantiation

```lean
def family41 (n : Nat) : Nat := F41 (F41 n)
def F42 (n : Nat) : Nat := SD.rayo family41 n
def contender_42 : Nat := F42 (F42 42)
```

`family41 42` is definitionally `contender_41`. Therefore:

1. `family41_lt_F42 42` proves `contender_41 < F42 42`.
2. `input_lt_F42 (F42 42)` proves `F42 42 < F42 (F42 42)`.
3. Transitivity gives `contender_41_lt_contender_42`.

The explicit conjunction `contender_41_lt_inner42_lt_contender_42` records the
strict intermediate gap.

## 5. Strong gap witnesses

### Predecessor-sized iteration

`SD.oracleIter` is the program

```lean
.iterate .oracle .oracle .input
```

and evaluates to `iterateNat oracle (oracle n) n` at every semantic rank.
Its membership produces `SD.oracleIter_lt_rayo`. At input 42:

```lean
theorem contender41FoldIter_lt_F42_42 :
  SD.iterateNat family41 contender_41 42 < F42 42
```

Thus the inner call already exceeds `contender_41` iterations of the entire
predecessor family.

### Predecessor-sized semantic horizon

`SD.oracleBudgetReflect` is `.reflect .oracle .input`. At outer rank 42 and
input 42, it launches an inner rank-41 diagonal with syntax budget
`family41 42 = contender_41`. Its membership produces:

```lean
theorem contender41HorizonDiagonal_lt_F42_42 :
  SD.reflectMax (SD.rankEval family41 41) contender_41 42 < F42 42
```

This theorem is the cleanest formal certificate that the construction is not
merely “apply one old fast function once more.”

## 6. Dependency audit

`integration/Audit.lean.append` asks the repository’s existing
`#assert_not_in_closure` command to confirm that `SD.rayo` does not depend on
`F41`, `Ordinal.hier`, `FLT2.jumpL`, `FT2.jumpF`, `Ordinal.metaBoostT`, or
`wDiagonalLift`. It separately checks that `contender_42` depends on the
predecessor *family* but not on any predecessor contender constant.
