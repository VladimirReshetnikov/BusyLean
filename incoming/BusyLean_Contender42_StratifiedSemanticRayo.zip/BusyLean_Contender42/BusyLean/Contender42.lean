import BusyLean.SemanticDiagonal
import BusyLean.Contender41

/-!
# Contender 42: stratified semantic Rayo reflection

```
family41 n   := F41 (F41 n)
F42 n        := SD.rayo family41 n
contender_42 := F42 (F42 42)
```

The new growth mechanism is not another `wDiagonalLift`, ordinal notation, or
language stack.  `SD.rayo` is an independent rank-stratified universal
interpreter.  At input `n`, it evaluates a finite language at rank `n+1`; its
reflection instruction enumerates every rank-`n` program of depth at most `n`,
takes their maximum at input `n`, and adds one.  Strict rank descent certifies
totality.

Contender 41's family is supplied only as the generic oracle instruction.  The
formal comparison uses the fact that this instruction occurs in the enumerated
language; the semantic diagonal then simultaneously exceeds all the much more
complicated programs in the same finite class.

**Do not evaluate `contender_42`.**
-/

namespace BusyLean

/-- Contender 41 as a unary family; `family41 42 = contender_41`. -/
def family41 (n : Nat) : Nat := F41 (F41 n)

/-- Rank-stratified semantic diagonal over the preceding family. -/
def F42 (n : Nat) : Nat := SD.rayo family41 n

/-- **Contender 42.** Never evaluate it. -/
def contender_42 : Nat := F42 (F42 42)

end BusyLean
