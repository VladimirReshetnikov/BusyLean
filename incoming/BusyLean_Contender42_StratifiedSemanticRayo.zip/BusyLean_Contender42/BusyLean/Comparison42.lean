import BusyLean.Contender42
import BusyLean.Comparison41

/-! # Contender 42: comparison theorems -/

namespace BusyLean

/-- At every input, the stratified semantic diagonal exceeds Contender 41's
entire twofold family. -/
theorem family41_lt_F42 (n : Nat) : family41 n < F42 n :=
  SD.oracle_lt_rayo family41 n

/-- The stronger universal statement: every rank-`n`, depth-`n` semantic
program at the diagonal input is below `F42 n`. -/
theorem sdProgram_lt_F42 {n : Nat} {p : SD.Prog} (hp : p ∈ SD.programs n) :
    SD.rankEval family41 n p n < F42 n :=
  SD.program_lt_rayo family41 hp

/-- A concrete huge lower bound: at every positive input, `F42` exceeds as many
iterations of the entire Contender-41 family as the family itself specifies. -/
theorem family41Iter_lt_F42 (d : Nat) :
    SD.iterateNat family41 (family41 (d + 1)) (d + 1) < F42 (d + 1) :=
  SD.oracleIter_lt_rayo family41 d

/-- The dynamic horizon lower bound: a single rank-lowering instruction inside
`F42` diagonalizes over a class whose syntax depth is the previous contender's
value. -/
theorem family41HorizonDiagonal_lt_F42 (d : Nat) :
    SD.reflectMax (SD.rankEval family41 d) (family41 (d + 1)) (d + 1) <
      F42 (d + 1) :=
  SD.oracleBudgetDiagonal_lt_rayo family41 d

/-- At input 42 this is `contender_41` iterations of `family41`. -/
theorem contender41FoldIter_lt_F42_42 :
    SD.iterateNat family41 contender_41 42 < F42 42 := by
  simpa [family41, contender_41] using family41Iter_lt_F42 41

/-- At input 42, `F42 42` exceeds an inner rank-41 semantic diagonal over all
programs of depth at most `contender_41`. -/
theorem contender41HorizonDiagonal_lt_F42_42 :
    SD.reflectMax (SD.rankEval family41 41) contender_41 42 < F42 42 := by
  simpa [family41, contender_41] using family41HorizonDiagonal_lt_F42 41

/-- The old family is itself strictly inflationary. -/
theorem input_lt_family41 (n : Nat) : n < family41 n :=
  Nat.lt_trans (input_lt_F41 n) (input_lt_F41 (F41 n))

/-- `F42` is strictly inflationary independently of the oracle comparison. -/
theorem input_lt_F42 (n : Nat) : n < F42 n :=
  SD.input_lt_rayo family41 n

/-- A useful two-step gap: Contender 41 is already below the *inner* call used
in Contender 42. -/
theorem contender_41_lt_F42_42 : contender_41 < F42 42 := by
  change family41 42 < F42 42
  exact family41_lt_F42 42

/-- **The required comparison**: Contender 41 is strictly smaller than
Contender 42. -/
theorem contender_41_lt_contender_42 : contender_41 < contender_42 := by
  change family41 42 < F42 (F42 42)
  exact Nat.lt_trans (family41_lt_F42 42) (input_lt_F42 (F42 42))

/-- A visible strict chain exhibiting the nontrivial gap. -/
theorem contender_41_lt_inner42_lt_contender_42 :
    contender_41 < F42 42 ∧ F42 42 < contender_42 :=
  ⟨contender_41_lt_F42_42, input_lt_F42 (F42 42)⟩

theorem contender_40_lt_contender_42 : contender_40 < contender_42 :=
  Nat.lt_trans contender_40_lt_contender_41 contender_41_lt_contender_42

end BusyLean
