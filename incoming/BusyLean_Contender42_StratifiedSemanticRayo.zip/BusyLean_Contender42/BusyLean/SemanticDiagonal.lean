import Init

/-!
# Stratified semantic diagonalization

This file is deliberately independent of the earlier BusyLean ordinal and
reflection machinery.  It defines:

* a small, intrinsically total language of unary natural-number programs;
* a finite depth-bounded enumerator for that language;
* a rank-indexed interpreter in which semantic reflection may inspect only the
  preceding rank; and
* a Rayo-style diagonal that exceeds every program in the preceding finite
  class.

The strict rank drop is the termination certificate.  No normalization theorem,
well-founded ordinal notation, classical choice, or axiom is required.
-/

namespace BusyLean.SD

/-- Programs are unary.  `oracle` is supplied externally.  The `reflect`
constructor is ramified: at semantic rank `k+1` it enumerates and evaluates
programs only at rank `k`. -/
inductive Prog where
  | zero : Prog
  | one : Prog
  | input : Prog
  | oracle : Prog
  | succ : Prog → Prog
  | add : Prog → Prog → Prog
  | mul : Prog → Prog → Prog
  | compose : Prog → Prog → Prog
  | iterate : Prog → Prog → Prog → Prog
  | reflect : Prog → Prog → Prog
  deriving DecidableEq, Repr

/-- Ordinary finite iteration. -/
def iterateNat (f : Nat → Nat) : Nat → Nat → Nat
  | 0, x => x
  | k + 1, x => iterateNat f k (f x)

/-- Evaluate a program relative to an oracle and a supplied reflection
operation.  Recursive calls are only on strict subprograms. -/
def eval (oracle : Nat → Nat) (reflection : Nat → Nat → Nat) : Prog → Nat → Nat
  | .zero, _ => 0
  | .one, _ => 1
  | .input, n => n
  | .oracle, n => oracle n
  | .succ p, n => Nat.succ (eval oracle reflection p n)
  | .add p q, n => eval oracle reflection p n + eval oracle reflection q n
  | .mul p q, n => eval oracle reflection p n * eval oracle reflection q n
  | .compose p q, n => eval oracle reflection p (eval oracle reflection q n)
  | .iterate count step start, n =>
      iterateNat (eval oracle reflection step)
        (eval oracle reflection count n) (eval oracle reflection start n)
  | .reflect budget arg, n =>
      reflection (eval oracle reflection budget n) (eval oracle reflection arg n)
termination_by structural p => p

/-- Cartesian product, kept local so the program enumerator has no hidden
coding assumptions. -/
def cross {A B : Type} (xs : List A) (ys : List B) : List (A × B) :=
  xs.flatMap (fun x => ys.map (fun y => (x, y)))

/-- All programs of constructor depth at most `d` (with harmless duplicates).
The recursive layer contains the preceding layer verbatim, making membership
monotone in the depth budget. -/
def programs : Nat → List Prog
  | 0 => [.zero, .one, .input, .oracle]
  | d + 1 =>
      let ps := programs d
      ps ++
      ps.map Prog.succ ++
      (cross ps ps).map (fun p => .add p.1 p.2) ++
      (cross ps ps).map (fun p => .mul p.1 p.2) ++
      (cross ps ps).map (fun p => .compose p.1 p.2) ++
      (cross (cross ps ps) ps).map
        (fun p => .iterate p.1.1 p.1.2 p.2) ++
      (cross ps ps).map (fun p => .reflect p.1 p.2)

/-- A primitive maximum, duplicated here rather than importing any earlier
BusyLean reflection framework. -/
def maxN : Nat → Nat → Nat
  | 0, b => b
  | a + 1, 0 => a + 1
  | a + 1, b + 1 => Nat.succ (maxN a b)

/-- Maximum score on a finite list. -/
def maximum {A : Type} (score : A → Nat) : List A → Nat
  | [] => 0
  | a :: xs => maxN (score a) (maximum score xs)

/-- The semantic diagonal over all programs in the given finite depth class. -/
def reflectMax (lower : Prog → Nat → Nat) (depth input : Nat) : Nat :=
  Nat.succ (maximum (fun p => lower p input) (programs depth))

/-- Rank `0` treats `reflect` as the identity on its argument.  Rank `k+1`
interprets it as the finite semantic diagonal over rank `k`. -/
def rankEval (oracle : Nat → Nat) : Nat → Prog → Nat → Nat
  | 0 => eval oracle (fun _ x => x)
  | k + 1 => eval oracle (reflectMax (rankEval oracle k))

/-- A compact program that iterates the oracle `oracle n` times from `n`. -/
def oracleIter : Prog := .iterate .oracle .oracle .input

/-- A compact program whose reflection budget is the oracle value itself. -/
def oracleBudgetReflect : Prog := .reflect .oracle .input

/-- The canonical diagonal program: use the current input as both syntax budget
and evaluation argument. -/
def universal : Prog := .reflect .input .input

/-- The stratified Rayo-style diagonal.  Input `n` is evaluated at rank `n+1`,
so its single reflection step enumerates rank-`n` programs of depth at most
`n`, all at argument `n`. -/
def rayo (oracle : Nat → Nat) (n : Nat) : Nat :=
  rankEval oracle (n + 1) universal n

/-! ## Elementary comparison lemmas -/

theorem le_maxN_left : ∀ a b : Nat, a ≤ maxN a b
  | 0, b => Nat.zero_le b
  | a + 1, 0 => Nat.le_refl (a + 1)
  | a + 1, b + 1 => Nat.succ_le_succ (le_maxN_left a b)

theorem le_maxN_right : ∀ a b : Nat, b ≤ maxN a b
  | 0, b => Nat.le_refl b
  | a + 1, 0 => Nat.zero_le (a + 1)
  | a + 1, b + 1 => Nat.succ_le_succ (le_maxN_right a b)

theorem le_maximum {A : Type} (score : A → Nat) {x : A} :
    ∀ {xs : List A}, x ∈ xs → score x ≤ maximum score xs
  | _ :: _, .head _ => le_maxN_left _ _
  | y :: _, .tail _ h => Nat.le_trans (le_maximum score h) (le_maxN_right (score y) _)

theorem zero_mem_programs (d : Nat) : Prog.zero ∈ programs d := by
  induction d with
  | zero => simp [programs]
  | succ d ih => simp [programs, ih]

theorem one_mem_programs (d : Nat) : Prog.one ∈ programs d := by
  induction d with
  | zero => simp [programs]
  | succ d ih => simp [programs, ih]

theorem input_mem_programs (d : Nat) : Prog.input ∈ programs d := by
  induction d with
  | zero => simp [programs]
  | succ d ih => simp [programs, ih]

/-- The comparison oracle is a genuine member of every finite program class. -/
theorem oracle_mem_programs (d : Nat) : Prog.oracle ∈ programs d := by
  induction d with
  | zero => simp [programs]
  | succ d ih => simp [programs, ih]

/-- Constructor closure for the finite enumerator. -/
theorem iterate_mem_programs_succ {d : Nat} {count step start : Prog}
    (hc : count ∈ programs d) (hs : step ∈ programs d)
    (hz : start ∈ programs d) :
    Prog.iterate count step start ∈ programs (d + 1) := by
  simp [programs, cross, hc, hs, hz]

/-- Constructor closure for semantic reflection. -/
theorem reflect_mem_programs_succ {d : Nat} {budget arg : Prog}
    (hb : budget ∈ programs d) (ha : arg ∈ programs d) :
    Prog.reflect budget arg ∈ programs (d + 1) := by
  simp [programs, cross, hb, ha]

/-- The oracle-iteration witness is already visible at every positive depth. -/
theorem oracleIter_mem_programs_succ (d : Nat) :
    oracleIter ∈ programs (d + 1) := by
  unfold oracleIter
  exact iterate_mem_programs_succ
    (oracle_mem_programs d) (oracle_mem_programs d) (input_mem_programs d)

/-- The oracle-budget reflection witness is visible at every positive depth. -/
theorem oracleBudgetReflect_mem_programs_succ (d : Nat) :
    oracleBudgetReflect ∈ programs (d + 1) := by
  unfold oracleBudgetReflect
  exact reflect_mem_programs_succ (oracle_mem_programs d) (input_mem_programs d)

@[simp] theorem eval_oracle (oracle : Nat → Nat) (reflection : Nat → Nat → Nat)
    (n : Nat) : eval oracle reflection .oracle n = oracle n := rfl

@[simp] theorem rankEval_oracle (oracle : Nat → Nat) (k n : Nat) :
    rankEval oracle k .oracle n = oracle n := by
  cases k <;> rfl

@[simp] theorem rankEval_oracleIter (oracle : Nat → Nat) (k n : Nat) :
    rankEval oracle k oracleIter n = iterateNat oracle (oracle n) n := by
  cases k <;> rfl

@[simp] theorem rankEval_oracleBudgetReflect_succ
    (oracle : Nat → Nat) (k n : Nat) :
    rankEval oracle (k + 1) oracleBudgetReflect n =
      reflectMax (rankEval oracle k) (oracle n) n := by
  rfl

/-- Every program visible to a semantic diagonal is strictly beaten. -/
theorem program_lt_reflectMax (lower : Prog → Nat → Nat) {depth input : Nat}
    {p : Prog} (hp : p ∈ programs depth) :
    lower p input < reflectMax lower depth input :=
  Nat.lt_succ_of_le (le_maximum (fun q => lower q input) hp)

/-- Definitional equation exposing the finite maximum computed by `rayo`. -/
theorem rayo_eq (oracle : Nat → Nat) (n : Nat) :
    rayo oracle n = reflectMax (rankEval oracle n) n n := rfl

/-- The main generic diagonal theorem: every rank-`n`, depth-`n` program is
strictly below `rayo oracle n` at the diagonal input. -/
theorem program_lt_rayo (oracle : Nat → Nat) {n : Nat} {p : Prog}
    (hp : p ∈ programs n) :
    rankEval oracle n p n < rayo oracle n := by
  rw [rayo_eq]
  exact program_lt_reflectMax (rankEval oracle n) hp

/-- A concrete amplification witness: at every positive input the diagonal beats
`oracle n` iterations of the whole oracle, starting from `n`. -/
theorem oracleIter_lt_rayo (oracle : Nat → Nat) (d : Nat) :
    iterateNat oracle (oracle (d + 1)) (d + 1) < rayo oracle (d + 1) := by
  have h := program_lt_rayo oracle
    (p := oracleIter) (oracleIter_mem_programs_succ d)
  simpa using h

/-- A stronger horizon witness.  The outer diagonal contains a one-node
program that launches an inner diagonal whose syntax budget is `oracle n`. -/
theorem oracleBudgetDiagonal_lt_rayo (oracle : Nat → Nat) (d : Nat) :
    reflectMax (rankEval oracle d) (oracle (d + 1)) (d + 1) <
      rayo oracle (d + 1) := by
  have h := program_lt_rayo oracle
    (p := oracleBudgetReflect) (oracleBudgetReflect_mem_programs_succ d)
  simpa using h

/-- In particular the new diagonal beats its oracle pointwise. -/
theorem oracle_lt_rayo (oracle : Nat → Nat) (n : Nat) :
    oracle n < rayo oracle n := by
  have h := program_lt_rayo oracle (p := Prog.oracle) (oracle_mem_programs n)
  simpa using h

/-- The input program is also visible, so `rayo` is strictly inflationary even
when the oracle itself is small. -/
theorem input_lt_rayo (oracle : Nat → Nat) (n : Nat) :
    n < rayo oracle n := by
  have h := program_lt_rayo oracle (p := Prog.input) (input_mem_programs n)
  simpa using h

end BusyLean.SD
