import BusyLean.Comparison42

open BusyLean

#check SD.program_lt_rayo
#check SD.oracle_lt_rayo
#check family41_lt_F42
#check sdProgram_lt_F42
#check contender_41_lt_contender_42

-- Only tiny instances are intended for evaluation.
def tinyOracle (n : Nat) : Nat := n + 2

#eval SD.rayo tinyOracle 0
#eval SD.rankEval tinyOracle 2 SD.oracleIter 1

-- Even `SD.rayo tinyOracle 1` is deliberately omitted: dynamic reflection
-- budgets make nontrivial instances explode quickly.

-- Never evaluate F42 42 or contender_42.
