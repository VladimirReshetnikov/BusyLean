import BusyLean.Comparison42
import Lean

/-!
Standalone additions for the repository's audit suite.
-/

#print axioms BusyLean.SD.rankEval
#print axioms BusyLean.SD.program_lt_rayo
#print axioms BusyLean.contender_42
#print axioms BusyLean.sdProgram_lt_F42
#print axioms BusyLean.contender41FoldIter_lt_F42_42
#print axioms BusyLean.contender41HorizonDiagonal_lt_F42_42
#print axioms BusyLean.contender_41_lt_contender_42

-- Expected output for every line above: no axioms.
