#!/usr/bin/env python3
"""Executable reference model for the tiny fragments of Contender 42.

This is not a replacement for Lean.  It independently mirrors the core
semantics, checks the first enumerator cardinalities, and evaluates only the
instances that are intentionally small.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import json
from pathlib import Path
from typing import Callable, Iterable, Tuple


@dataclass(frozen=True)
class Prog:
    tag: str
    args: Tuple["Prog", ...] = ()


def atom(tag: str) -> Prog:
    return Prog(tag)


ZERO = atom("zero")
ONE = atom("one")
INPUT = atom("input")
ORACLE = atom("oracle")


def succ(p: Prog) -> Prog:
    return Prog("succ", (p,))


def binary(tag: str, p: Prog, q: Prog) -> Prog:
    return Prog(tag, (p, q))


def iterate(count: Prog, step: Prog, start: Prog) -> Prog:
    return Prog("iterate", (count, step, start))


def reflect(budget: Prog, arg: Prog) -> Prog:
    return Prog("reflect", (budget, arg))


ORACLE_ITER = iterate(ORACLE, ORACLE, INPUT)
ORACLE_BUDGET_REFLECT = reflect(ORACLE, INPUT)
UNIVERSAL = reflect(INPUT, INPUT)


def iterate_nat(f: Callable[[int], int], count: int, x: int) -> int:
    for _ in range(count):
        x = f(x)
    return x


def eval_prog(
    oracle: Callable[[int], int],
    reflection: Callable[[int, int], int],
    p: Prog,
    n: int,
) -> int:
    if p.tag == "zero":
        return 0
    if p.tag == "one":
        return 1
    if p.tag == "input":
        return n
    if p.tag == "oracle":
        return oracle(n)
    if p.tag == "succ":
        return eval_prog(oracle, reflection, p.args[0], n) + 1
    if p.tag in {"add", "mul"}:
        a = eval_prog(oracle, reflection, p.args[0], n)
        b = eval_prog(oracle, reflection, p.args[1], n)
        return a + b if p.tag == "add" else a * b
    if p.tag == "compose":
        inner = eval_prog(oracle, reflection, p.args[1], n)
        return eval_prog(oracle, reflection, p.args[0], inner)
    if p.tag == "iterate":
        count = eval_prog(oracle, reflection, p.args[0], n)
        start = eval_prog(oracle, reflection, p.args[2], n)
        step = lambda x: eval_prog(oracle, reflection, p.args[1], x)
        return iterate_nat(step, count, start)
    if p.tag == "reflect":
        depth = eval_prog(oracle, reflection, p.args[0], n)
        arg = eval_prog(oracle, reflection, p.args[1], n)
        return reflection(depth, arg)
    raise ValueError(f"unknown program tag: {p.tag}")


@lru_cache(maxsize=None)
def programs(depth: int) -> Tuple[Prog, ...]:
    if depth == 0:
        return (ZERO, ONE, INPUT, ORACLE)
    ps = programs(depth - 1)
    out = list(ps)
    out.extend(succ(p) for p in ps)
    for tag in ("add", "mul", "compose"):
        out.extend(binary(tag, p, q) for p in ps for q in ps)
    out.extend(iterate(c, s, z) for c in ps for s in ps for z in ps)
    out.extend(reflect(p, q) for p in ps for q in ps)
    return tuple(out)


def program_count_recurrence(depth: int) -> int:
    n = 4
    for _ in range(depth):
        n = n**3 + 4 * n**2 + 2 * n
    return n


def rank_eval(oracle: Callable[[int], int], rank: int, p: Prog, n: int) -> int:
    if rank == 0:
        return eval_prog(oracle, lambda _depth, x: x, p, n)

    def reflection(depth: int, x: int) -> int:
        return 1 + max(rank_eval(oracle, rank - 1, q, x) for q in programs(depth))

    return eval_prog(oracle, reflection, p, n)


def rayo(oracle: Callable[[int], int], n: int) -> int:
    return rank_eval(oracle, n + 1, UNIVERSAL, n)


def main() -> None:
    counts = [program_count_recurrence(d) for d in range(5)]
    assert counts[0] == len(programs(0))
    assert counts[1] == len(programs(1))
    assert counts[:4] == [4, 136, 2_589_712, 17_368_210_672_489_143_328]

    tiny_oracle = lambda n: n + 2
    results = {
        "program_counts_depth_0_through_4": [str(x) for x in counts],
        "tiny_oracle_definition": "f(n)=n+2",
        "rayo_tiny_oracle_0": rayo(tiny_oracle, 0),
        "oracle_iter_rank_0_input_1": rank_eval(tiny_oracle, 0, ORACLE_ITER, 1),
        "oracle_iter_rank_2_input_1": rank_eval(tiny_oracle, 2, ORACLE_ITER, 1),
        "expected_oracle_iter_input_1": iterate_nat(tiny_oracle, tiny_oracle(1), 1),
    }
    assert results["rayo_tiny_oracle_0"] == 3
    assert results["oracle_iter_rank_0_input_1"] == 7
    assert results["oracle_iter_rank_2_input_1"] == 7

    out = Path(__file__).resolve().parents[1] / "reference" / "reference-results.json"
    out.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
