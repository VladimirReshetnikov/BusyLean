#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python /home/oai/skills/pdfs/scripts/latex_to_pdf.py \
  "$ROOT/article/contender42.tex" -o "$ROOT/article/contender42.pdf"
python /home/oai/skills/pdfs/scripts/pdf_inspect.py \
  "$ROOT/article/contender42.pdf" > "$ROOT/article/pdf-inspect.txt"
rm -rf "$ROOT/article/render"
python /home/oai/skills/pdfs/scripts/render_pdf.py \
  "$ROOT/article/contender42.pdf" --out_dir "$ROOT/article/render" --dpi 160
