#!/usr/bin/env bash
set -euo pipefail

# Run from an integrated BusyLean checkout.
lake build
lake env lean BusyLean/SemanticDiagonal.lean
lake env lean BusyLean/Contender42.lean
lake env lean BusyLean/Comparison42.lean
lake env lean test/SemanticDiagonalSmoke.lean
lake env lean test/Contender42Audit.lean
