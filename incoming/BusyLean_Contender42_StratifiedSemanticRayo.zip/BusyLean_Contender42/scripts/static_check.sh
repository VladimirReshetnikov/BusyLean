#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

printf '%s\n' "BusyLean Contender 42 static and executable checks"
printf 'UTC: %s\n\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"

printf '%s\n' '[1] Python reference model'
python3 "$ROOT/scripts/reference_model.py" | tee "$ROOT/reference/reference-run.log"
printf '%s\n\n' 'PASS: reference model'

printf '%s\n' '[2] Python syntax'
python3 -m py_compile "$ROOT/scripts/reference_model.py"
printf '%s\n\n' 'PASS: py_compile'

printf '%s\n' '[3] Shell syntax'
for f in "$ROOT"/scripts/*.sh "$ROOT"/integration/apply_to_checkout.sh; do
  bash -n "$f"
  printf 'PASS: %s\n' "${f#$ROOT/}"
done
printf '\n'

printf '%s\n' '[4] Forbidden Lean placeholders/declarations'
pattern='^[[:space:]]*(sorry|admit|axiom([[:space:]]|$)|unsafe[[:space:]]+(def|theorem)|partial[[:space:]]+def|noncomputable([[:space:]]|$)|classical[[:space:]]*$)'
if rg -n "$pattern" \
    "$ROOT/BusyLean/SemanticDiagonal.lean" \
    "$ROOT/BusyLean/Contender42.lean" \
    "$ROOT/BusyLean/Comparison42.lean"; then
  printf '%s\n' 'FAIL: forbidden placeholder or declaration found'
  exit 1
else
  printf '%s\n\n' 'PASS: no forbidden placeholder or declaration in the three new modules'
fi

printf '%s\n' '[5] Core import boundary'
test "$(grep -c '^import ' "$ROOT/BusyLean/SemanticDiagonal.lean")" -eq 1
grep -qx 'import Init' "$ROOT/BusyLean/SemanticDiagonal.lean"
printf '%s\n\n' 'PASS: SemanticDiagonal.lean imports only Init'

printf '%s\n' '[6] Line length'
awk 'length($0)>100 {print FILENAME ":" FNR ":" length($0); bad=1} END {exit bad}' \
  "$ROOT"/BusyLean/*.lean "$ROOT"/test/*.lean
printf '%s\n\n' 'PASS: all new Lean/test lines are at most 100 characters'

printf '%s\n' '[7] Trailing whitespace'
if rg -n '[[:blank:]]+$' "$ROOT"/BusyLean/*.lean "$ROOT"/test/*.lean; then
  printf '%s\n' 'FAIL: trailing whitespace'
  exit 1
else
  printf '%s\n\n' 'PASS: no trailing whitespace in Lean/test files'
fi

printf '%s\n' '[8] Expected declarations'
for name in \
  'def rankEval' 'def rayo' 'theorem program_lt_rayo' \
  'def contender_42' 'theorem contender_41_lt_contender_42' \
  'theorem contender41FoldIter_lt_F42_42' \
  'theorem contender41HorizonDiagonal_lt_F42_42'; do
  rg -q --fixed-strings "$name" "$ROOT/BusyLean"
  printf 'PASS: %s\n' "$name"
done
printf '\n'

printf '%s\n' '[9] PDF text/structure smoke'
pdfinfo "$ROOT/article/contender42.pdf" | grep -E '^(Pages|Page size|File size):'
test "$(pdfinfo "$ROOT/article/contender42.pdf" | awk '/^Pages:/ {print $2}')" -eq 17
pdftext="$(mktemp)"
trap 'rm -f "$pdftext"' EXIT
pdftotext "$ROOT/article/contender42.pdf" "$pdftext"
grep -q 'Stratified Semantic Rayo Reflection' "$pdftext"
rm -f "$pdftext"
trap - EXIT
printf '%s\n\n' 'PASS: PDF is readable and title text is present'

printf '%s\n' '[10] Final LaTeX pass diagnostics'
python3 - "$ROOT/article/build.log" <<'PY'
from pathlib import Path
import re
import sys

text = Path(sys.argv[1]).read_text(errors="replace")
marks = list(re.finditer(r"Run number \d+ of rule 'pdflatex'", text))
if not marks:
    raise SystemExit("FAIL: no pdflatex run markers")
last = text[marks[-1].start():]
for bad in ("undefined references", "undefined citations", "Fatal error", "!  ==>"):
    if bad.lower() in last.lower():
        raise SystemExit(f"FAIL: final pass contains {bad!r}")
print("PASS: final pdflatex pass has no unresolved references or fatal errors")
print("INFO: final pass underfull boxes:", last.count(r"Underfull \hbox"))
print("INFO: final pass overfull boxes:", last.count(r"Overfull \hbox"))
PY
printf '\n%s\n' 'ALL_STATIC_CHECKS_PASSED'
