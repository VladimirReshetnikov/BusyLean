# BusyLean Contender 42 research package

This package proposes **Contender 42: Stratified Semantic Rayo Reflection** for
`VladimirReshetnikov/BusyLean`, audited against repository commit
`6afe0cdbd2005ea37500585d89f1dd8bab43b039`.

The incumbent at that commit is Contender 41 in both source and README:
`BusyLean.lean` imports `Contender41` and `Comparison41`, and the top README
section documents Contender 41. The immediately preceding commit had a
source/README mismatch, so the integration script deliberately supports both
shapes. See `BASELINE.md` for the exact audit.

## Core definition

```lean
def family41 (n : Nat) : Nat := F41 (F41 n)
def F42 (n : Nat) : Nat := SD.rayo family41 n
def contender_42 : Nat := F42 (F42 42)
```

`SD.rayo oracle n` is one plus the maximum value of every rank-`n` program of
syntax depth at most `n`, evaluated at input `n`. Its finite language supports
arithmetic, composition, finite iteration, an oracle, and rank-lowering
semantic reflection. Every reflective call at rank `k+1` evaluates programs
only at rank `k`, so the interpreter is computable by structural recursion and
contains no halting oracle or same-rank semantic self-reference.

The mechanism is independent of the existing tree-ordinal lineage:
`BusyLean/SemanticDiagonal.lean` imports only `Init`. Contender 41 enters only
as the interpretation of one generic oracle instruction.

## Main formal claims

- `SD.program_lt_rayo`: every visible rank-`n`, depth-`n` program is below the
  diagonal.
- `family41_lt_F42`: the full Contender-41 family is beaten pointwise.
- `contender_41_lt_contender_42`: the required strict comparison.
- `contender41FoldIter_lt_F42_42`: already `F42 42` exceeds
  `contender_41` iterations of `family41` starting at 42.
- `contender41HorizonDiagonal_lt_F42_42`: already `F42 42` exceeds a rank-41
  semantic diagonal whose syntax budget is `contender_41`.

`PROOF_MAP.md` traces every step to its Lean declaration.

## Package map

- `BusyLean/`: core, contender, and comparison modules.
- `test/`: smoke checks and axiom audit.
- `article/`: TeX article, compiled PDF, build transcript, and render report.
- `integration/`: unified patch, idempotent installer, README/audit snippets,
  and pinned CI workflow.
- `scripts/` and `reference/`: independent tiny executable model and results.
- `BASELINE.md`, `PROOF_MAP.md`, `RESEARCH_NOTES.md`: audit, formal map, and
  design record.
- `VALIDATION.md`, `MANIFEST.md`, `SHA256SUMS`: validation and integrity.

## Validation status

The article was compiled, all 17 PDF pages were rendered and visually
inspected, the Python reference model was executed, the unified patch was
applied to a mock checkout, and the installer was tested twice for
idempotence. The environment did not contain Lean/Lake, so no completed kernel
replay is claimed. Exact Lean 4.34.0 commands and a pinned GitHub Actions
workflow are included. See `VALIDATION.md` for the full ledger.
