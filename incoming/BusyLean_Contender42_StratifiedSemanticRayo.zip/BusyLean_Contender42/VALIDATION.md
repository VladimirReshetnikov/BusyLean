# Validation ledger

## Repository baseline

- Repository: `VladimirReshetnikov/BusyLean`
- Audited commit: `6afe0cdbd2005ea37500585d89f1dd8bab43b039`
- Source-level incumbent: Contender 41
- Documentation state: README and source both identify Contender 41
- Pinned toolchain: `leanprover/lean4:v4.34.0`

The repository advanced by one documentation-only commit during packaging;
`BASELINE.md` records both the final audit and compatibility handling.

## Mathematical/source checks

- The program class is finite at every syntax depth by primitive recursion.
- `eval` is structurally recursive on programs.
- `rankEval` is structurally recursive on the semantic rank.
- Every `reflect` call at rank `k+1` evaluates enumerated programs only at
  rank `k`; there is no same-rank semantic self-reference.
- `program_lt_rayo` is the finite-maximum membership theorem.
- `family41_lt_F42` is its oracle-member instance.
- `contender_41_lt_contender_42` uses the standard two-call BusyLean pattern
  plus strict inflationarity of `SD.rayo`.
- Static scan found no `sorry`, `admit`, `axiom`, `unsafe`, `partial`, or
  `classical` declaration in the three new Lean modules.
- The core module’s sole import is `Init`.

The detailed declaration map is in `PROOF_MAP.md`.

## Independent executable reference model

`scripts/reference_model.py` independently mirrors the tiny semantics and was
executed successfully. It verifies the program-count recurrence

```text
N(0) = 4
N(d+1) = N(d)^3 + 4*N(d)^2 + 2*N(d)
```

through depth 4, checks `rayo (fun n => n + 2) 0 = 3`, and checks that the
oracle-iteration program is rank-independent on a small input. Recorded output:
`reference/reference-results.json` and `reference/reference-run.log`.

This model is corroborative; it is not a substitute for Lean.

## Integration tests

- Unified patch dry-run: passed.
- Unified patch application: passed; generated files were byte-compared with
  the package sources.
- Checkout installer on the audited Contender-41 README shape: passed and
  idempotent.
- Checkout installer on the immediately preceding Contender-40-heading legacy
  shape: passed and idempotent; it inserted the missing Contender-41 section.
- In both tests, a second run produced identical hashes for `BusyLean.lean`,
  `README.md`, and `test/Audit.lean`.
- Shell syntax checks: passed for all packaged shell scripts.

Logs are under `validation/`.

## Article/PDF checks

- LaTeX compilation: successful; see `article/build.log`.
- PDF structural inspection: 17 US-Letter pages, embedded fonts, unencrypted,
  with outline; see `article/pdf-inspect.txt`.
- Render inspection: every page rendered at 160 dpi; global contact-sheet
  inspection plus detailed checks of pages 3, 10, 12, and 16 found no clipping,
  overlap, broken glyphs, or overflowing tables. Temporary renders were removed
  after inspection; see `article/render-check.md`.

## Lean kernel status

The execution container had neither `lean` nor `lake`; direct network access
from the container was disabled, and the available download route could not
retrieve the approximately 580 MB Lean 4.34.0 binary release. Therefore **this
archive does not claim a completed Lean kernel replay**.

The package supplies exact replay commands:

```bash
lake build
lake env lean BusyLean/SemanticDiagonal.lean
lake env lean BusyLean/Contender42.lean
lake env lean BusyLean/Comparison42.lean
lake env lean test/SemanticDiagonalSmoke.lean
lake env lean test/Contender42Audit.lean
```

It also supplies `integration/ci-contender42.yml`, pinned to the repository’s
`lean-toolchain`, for automated replay. A successful downstream run should
archive the log as `lean-check.log`; none is included here.

## Integrity

`MANIFEST.md` lists the deliverables. `SHA256SUMS` records hashes of every
packaged file other than the checksum file itself. The final ZIP was tested
with `unzip -t`, extracted into a clean directory, and checked against those
hashes.
