# Package manifest

Package: **BusyLean Contender 42 — Stratified Semantic Rayo Reflection**  
Audited repository commit: `6afe0cdbd2005ea37500585d89f1dd8bab43b039`

## Research and audit documents

| Path | Purpose |
|---|---|
| `README.md` | package overview, definition, main claims, and validation status |
| `BASELINE.md` | fixed-commit repository audit and documentation-history record |
| `PROOF_MAP.md` | declaration-by-declaration map of the formal argument |
| `RESEARCH_NOTES.md` | novelty analysis, rejected alternatives, and research limits |
| `VALIDATION.md` | complete validation ledger and kernel-replay boundary |

## Lean source

| Path | Purpose |
|---|---|
| `BusyLean/SemanticDiagonal.lean` | independent finite language, rank interpreter, and generic diagonal theorems |
| `BusyLean/Contender42.lean` | `family41`, `F42`, and `contender_42` definitions |
| `BusyLean/Comparison42.lean` | pointwise comparison, strong gap witnesses, and final strict theorem |
| `test/SemanticDiagonalSmoke.lean` | deliberately tiny executable smoke checks |
| `test/Contender42Audit.lean` | `#print axioms` audit commands |

## Article

| Path | Purpose |
|---|---|
| `article/contender42.tex` | full 17-page research article source |
| `article/contender42.pdf` | compiled research article |
| `article/build.log` | complete LaTeX compilation transcript |
| `article/pdf-inspect.txt` | page, metadata, outline, annotation, and font inspection |
| `article/render-check.md` | record of the all-page visual render inspection |

## Integration artifacts

| Path | Purpose |
|---|---|
| `integration/contender42-additions.patch` | unified patch adding imports, modules, and tests |
| `integration/apply_to_checkout.sh` | idempotent installer for current and immediately preceding README shapes |
| `integration/BusyLean.lean.append` | umbrella import snippet |
| `integration/Audit.lean.append` | axiom and dependency-closure audit snippet |
| `integration/README-section.md` | Contender-42 README section |
| `integration/README-contender41-baseline.md` | compatibility section for the preceding README lag |
| `integration/ci-contender42.yml` | pinned GitHub Actions build, smoke, audit, and leanchecker workflow |

## Executable reference artifacts

| Path | Purpose |
|---|---|
| `scripts/reference_model.py` | independent tiny Python model of the syntax and semantics |
| `scripts/static_check.sh` | reproducible non-kernel static and artifact checks |
| `scripts/check.sh` | exact downstream Lean/Lake replay commands |
| `scripts/build_article.sh` | article compile, inspect, and render pipeline |
| `reference/reference-results.json` | machine-readable reference outputs |
| `reference/reference-run.log` | recorded reference-model output |
| `examples/semantic_diagonal_pseudocode.txt` | compact language-agnostic pseudocode |

## Validation evidence

| Path | Purpose |
|---|---|
| `validation/static-checks.log` | successful Python, shell, source, and PDF checks |
| `validation/patch-dry-run.log` | successful unified-patch dry run |
| `validation/patch-apply.log` | successful patch application |
| `validation/installer-current-readme.log` | current Contender-41 README installer and idempotence test |
| `validation/installer-first-run.log` | first legacy README installer run |
| `validation/installer-second-run.log` | second legacy README installer run, demonstrating idempotence |

## Integrity

`SHA256SUMS` contains SHA-256 hashes for every packaged file except
`SHA256SUMS` itself. The ZIP archive is distributed outside this directory and
is separately identified in the final delivery message.
