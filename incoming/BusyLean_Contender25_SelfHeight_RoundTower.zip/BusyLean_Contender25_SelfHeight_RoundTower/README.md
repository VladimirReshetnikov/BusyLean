# BusyLean Contender 25: Self-Height Round-Tower Hyperreflection

This archive proposes a new closed, computable-in-principle natural number for
BusyLean, prepared against repository commit
`4fe4f5ed921a8e861d33008a368c6e6ff5b40446` and the pinned toolchain
`leanprover/lean4:v4.34.0`.

The incumbent at that snapshot is Contender 24:

```lean
def contender_24 : Nat := F24 (F24 42)
```

The proposal defines

```lean
def contender_25 : Nat := F25 (F25 42)
```

where `F25 n` reflects over programs whose universe atoms come from

```lean
roundTower (roundHeight25 n)
```

rather than `roundTower n`.  The height is a self-fed finite orbit of the old
growth function:

```lean
def family24 (n : Nat) : Nat := F24 (F24 n)
def orbit24 : Family := fun i n => iterateF24 (i + 2) n
def roundHeight25 (n : Nat) : Nat := orbit24 (family24 n) n
```

Consequently,

```lean
roundHeight25 42 = iterateF24 (contender_24 + 2) 42.
```

A fresh autonomous schedule and a fresh W-tree rank, both controlled by that
height, amplify the self-height reflector.  Coordinate zero of `orbit24` is
exactly `family24`, which gives a direct formal comparison without assuming
oracle monotonicity:

```lean
theorem contender_24_lt_contender_25 :
  contender_24 < contender_25
```

## Contents

- `article/contender25_self_height_round_tower.tex` - full research article.
- `article/contender25_self_height_round_tower.pdf` - compiled article.
- `overlay/BusyLean/Contender25.lean` - executable definitions.
- `overlay/BusyLean/Comparison25.lean` - comparison and retained lower bounds.
- `overlay/test/Contender25Audit.lean` - focused axiom/dependency audit.
- `overlay/test/Contender25Smoke.lean` - non-evaluating elaboration smoke test.
- `integration/busylean-contender25.patch` - unified patch against the recorded
  baseline.
- `scripts/install_overlay.sh` - guarded installer into a BusyLean checkout.
- `scripts/check25.py` - clean build, timing, smoke, and axiom audit harness.
- `scripts/static_audit.py` - source-only audit used in this artifact runtime.
- `research/` - proof outline, ordinal analysis, provenance, and risk register.
- `verification/` - validation receipts and limitations.
- `MANIFEST.sha256` - checksums for every packaged file except itself.

## Installation and kernel replay

From the extracted package:

```bash
./scripts/install_overlay.sh /path/to/BusyLean
cd /path/to/BusyLean
python3 scripts/check25.py
```

The checker performs these phases from a clean build directory:

1. prebuild accepted `BusyLean.Comparison24` (not budgeted);
2. build `BusyLean.Contender25` under the 15-second definition budget;
3. build `BusyLean.Comparison25` under the 60-second proof budget;
4. run the smoke test;
5. run the focused axiom and closure audit.

## Validation boundary

The source-level static audit, article compilation, PDF rendering, and package
integrity checks were completed in the artifact environment.  That environment
had no Lean or Lake executable, so kernel acceptance and timing are not
claimed.  The package deliberately distinguishes a complete proposed proof
source from a successful Lean replay; see `verification/BUILD_STATUS.md` and
`research/RISK_REGISTER.md`.

## Research assessment

The formal inequality is robust: it uses only the old family at a visible seed
coordinate and accepted generic progressivity theorems.  The principal growth
innovation is independent of that minimal comparison path.  It raises the
height of the *object-language round tower* from the numerical input to a
self-length `F24` orbit, then feeds the same height into both W-tree amplifier
parameters.  The article explains why this is materially stronger than merely
choosing a larger fixed schedule or wrapping the incumbent in arithmetic.
