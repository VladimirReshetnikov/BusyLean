# Validation status

## Completed in the artifact runtime

- Inspected BusyLean `main` at commit
  `4fe4f5ed921a8e861d33008a368c6e6ff5b40446`.
- Matched the current accepted baseline, Contender 24.
- Wrote the complete proposed Lean definition and comparison modules.
- Ran `scripts/static_audit.py` successfully.
- Checked line lengths, forbidden source tokens, and the no-direct-use rule.
- Compiled the LaTeX article and visually inspected rendered pages (recorded
  separately after final rendering).
- Generated an integration patch and SHA-256 manifest.

## Not completed in the artifact runtime

Lean and Lake were not installed, and external installation was unavailable.
Accordingly, the following are **not claimed**:

- Lean kernel acceptance;
- exact `#print axioms` output;
- declaration-closure size;
- the 15-second definition budget;
- the 60-second proof budget.

Run `scripts/install_overlay.sh` followed by `python3 scripts/check25.py` in a
checkout with the pinned Lean 4.34.0 toolchain to establish those facts.
