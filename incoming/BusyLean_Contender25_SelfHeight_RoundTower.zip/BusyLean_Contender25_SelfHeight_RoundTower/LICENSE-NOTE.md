# License note

The overlay is a research proposal intended for integration into the BusyLean
repository.  It imports and builds on BusyLean interfaces but does not bundle
the repository itself.  On acceptance, the new Lean and documentation files
should be placed under the same license and contribution terms as BusyLean.
The third-party works cited in the article remain under their respective
licenses and copyrights.
