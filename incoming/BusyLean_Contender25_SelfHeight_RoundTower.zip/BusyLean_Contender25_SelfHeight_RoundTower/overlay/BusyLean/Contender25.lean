import BusyLean.Contender24

/-!
# Contender 25: self-height round-tower hyperreflection

```
contender_25 := F25 (F25 42)
F25 n        := wDiagonalLift (schedule25 n) (rank25 n)
                  srTransformer orbit24 n n
```

Contender 24 uses the universe ladder over `roundTower n` at input `n`.
This construction makes the round itself a large, self-fed value.  Coordinate
`i` of `orbit24` is the `(i+2)`-fold iterate of `F24`, so coordinate zero is
exactly Contender 24's family `family24 n = F24 (F24 n)`.  The language used at
input `n` is the ladder over

```
roundTower (roundHeight25 n)
roundHeight25 n = orbit24 (family24 n) n.
```

Thus, at the contest seed `42`, the number of rounds is the
`(contender_24 + 2)`-fold iterate of `F24` from `42`.  The same height controls
an autonomous schedule above `rank24 n` and a further W-tree rank above that
schedule.

Every definition is structural or is assembled from previously proved total
functions.  The resulting natural number is computable in principle, but it
must never be evaluated at the contest input.
-/

namespace BusyLean

open BigNumber (WTree)
open BusyLean.W

/-- Contender 24's construction as a function of its input:
`family24 42 = contender_24`. -/
def family24 (n : Nat) : Nat := F24 (F24 n)

/-- Finite iteration of `F24`, oriented so that one successor step exposes an
outer call to `F24`. -/
def iterateF24 : Nat → Nat → Nat
  | 0, n => n
  | k + 1, n => F24 (iterateF24 k n)

/-- Coordinate `i` is the `(i+2)`-fold `F24` iterate from `n`.
Coordinate zero is definitionally `family24 n`. -/
def orbit24 : Family := fun i n => iterateF24 (i + 2) n

/-- The self-fed round index.  Its iteration count is itself Contender 24's
complete family value at the current input. -/
def roundHeight25 (n : Nat) : Nat := orbit24 (family24 n) n

namespace FL

open Ordinal

/-- Programs of syntax depth at most `n` over the self-height round tower.
Only the syntax/fuel budget remains `n`; the universe index is
`roundHeight25 n`. -/
def selfRoundLadderUpTo (n : Nat) :
    List (CTm (roundTower (roundHeight25 n)).T) :=
  ctmsUpTo ((roundTower (roundHeight25 n)).enum n) n

end FL

/-- Reflection over the self-height round-tower language, with a countable
oracle family. -/
def reflectSRFamily (fs : Family) (n : Nat) : Nat :=
  n + 1 + BigNumber.maxN (prefixMax (fun i => fs i n) n)
    (BigNumber.maximum
      (FL.rvalue (roundHeight25 n) (packFamily fs) n)
      (FL.selfRoundLadderUpTo n))

/-- The family-aware self-height round-tower reflection transformer. -/
def srTransformer : Transformer := fun fs _ n => reflectSRFamily fs n

/-- An autonomous schedule above Contender 24's rank, at the self-fed height. -/
def schedule25 (n : Nat) : WTree Nat :=
  Autonomous.realize
    (Autonomous.hyper (roundHeight25 n + 42)
      (Autonomous.encode (rank24 n)))

/-- A second autonomous closure, now serving as the W-tree rank of the lift
hierarchy. -/
def rank25 (n : Nat) : WTree Nat :=
  Autonomous.realize
    (Autonomous.hyper (roundHeight25 n + 42)
      (Autonomous.encode (schedule25 n)))

/-- W-ranked hyperreflection of self-height round-tower programs, seeded with
the exposed `F24` orbit. -/
def F25 (n : Nat) : Nat :=
  wDiagonalLift (schedule25 n) (rank25 n)
    srTransformer orbit24 n n

/-- **Contender 25.** Never evaluate it. -/
def contender_25 : Nat := F25 (F25 42)

end BusyLean
