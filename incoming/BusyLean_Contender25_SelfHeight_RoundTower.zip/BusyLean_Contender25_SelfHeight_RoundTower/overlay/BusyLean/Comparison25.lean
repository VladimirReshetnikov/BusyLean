import BusyLean.Contender25
import BusyLean.Comparison24

/-! # Contender 25: comparison theorems -/

namespace BusyLean

open BusyLean.W

/-- The additive guard in `reflectSRFamily` strictly exceeds the finite maximum
that it reflects. -/
theorem lt_reflectSRFamily {fs : Family} {n m : Nat}
    (h : m ≤ BigNumber.maxN (prefixMax (fun i => fs i n) n)
      (BigNumber.maximum
        (FL.rvalue (roundHeight25 n) (packFamily fs) n)
        (FL.selfRoundLadderUpTo n))) :
    m < reflectSRFamily fs n := by
  show m < n + 1 + _
  have hM : ∀ M : Nat, M + 1 ≤ n + 1 + M := fun M => by
    rw [Nat.add_comm M 1]
    exact Nat.add_le_add_right (Nat.le_add_left 1 n) M
  exact Nat.lt_of_le_of_lt h
    (Nat.lt_of_lt_of_le (Nat.lt_succ_self _) (hM _))

/-- Every visible oracle coordinate lies below one self-height reflection
step. -/
theorem oracle_lt_reflectSRFamily (fs : Family) {i n : Nat}
    (hi : i ≤ n) : fs i n < reflectSRFamily fs n :=
  lt_reflectSRFamily
    (Nat.le_trans (le_prefixMax (fun j => fs j n) hi)
      (BigNumber.le_maxN_left _ _))

/-- Every enumerated program over the self-height round tower lies below one
reflection step. -/
theorem srvalue_lt_reflectSRFamily (fs : Family) {n : Nat}
    {t : FL.CTm ((Ordinal.roundTower (roundHeight25 n)).T)}
    (ht : t ∈ FL.selfRoundLadderUpTo n) :
    FL.rvalue (roundHeight25 n) (packFamily fs) n t <
      reflectSRFamily fs n :=
  lt_reflectSRFamily
    (Nat.le_trans
      (le_maximum
        (FL.rvalue (roundHeight25 n) (packFamily fs) n) ht)
      (BigNumber.le_maxN_right _ _))

/-- Self-height round-tower reflection is progressive. -/
theorem srTransformer_progressive : Progressive srTransformer :=
  fun seed _ _ _ hi => oracle_lt_reflectSRFamily seed hi

/-- One more finite `F24` iterate is strictly larger.  No monotonicity of
`F24` is used. -/
theorem iterateF24_lt_succ (k n : Nat) :
    iterateF24 k n < iterateF24 (k + 1) n := by
  simpa only [iterateF24] using input_lt_F24 (iterateF24 k n)

/-- Coordinate zero of the seed orbit is exactly Contender 24's family. -/
theorem orbit24_zero (n : Nat) : orbit24 0 n = family24 n := rfl

/-- The exposed `F24` orbit is strictly increasing coordinate by coordinate. -/
theorem orbit24_lt_next (i n : Nat) :
    orbit24 i n < orbit24 (i + 1) n := by
  simpa only [orbit24, Nat.add_assoc, Nat.add_comm, Nat.add_left_comm]
    using iterateF24_lt_succ (i + 2) n

/-- Every seed-orbit coordinate visible at input `n` lies below `F25 n`. -/
theorem orbit24_lt_F25 {i n : Nat} (hi : i ≤ n) :
    orbit24 i n < F25 n := by
  have h :=
    ((wDiagonalLift_preservesProgressive (schedule25 n) (rank25 n))
      srTransformer srTransformer_progressive)
      orbit24 i n n hi
  simpa only [F25] using h

/-- At every input, `F25` strictly exceeds Contender 24's complete family. -/
theorem family24_lt_F25 (n : Nat) : family24 n < F25 n := by
  have h := orbit24_lt_F25 (i := 0) (n := n) (Nat.zero_le n)
  simpa only [orbit24_zero] using h

/-- The raw self-height reflection step is strictly below the full W-ranked
hyperreflection. -/
theorem raw_reflection_lt_F25 (n : Nat) :
    reflectSRFamily orbit24 n < F25 n :=
  (wDiagonalLift_strictlyInflationary (schedule25 n) (rank25 n))
    srTransformer srTransformer_progressive orbit24 n n n (Nat.le_refl n)

/-- Every self-height round-tower program of depth at most `n`, run with the
packed seed orbit, is below `F25 n`. -/
theorem srvalue_lt_F25 {n : Nat}
    {t : FL.CTm ((Ordinal.roundTower (roundHeight25 n)).T)}
    (ht : t ∈ FL.selfRoundLadderUpTo n) :
    FL.rvalue (roundHeight25 n) (packFamily orbit24) n t < F25 n :=
  Nat.lt_trans (srvalue_lt_reflectSRFamily orbit24 ht)
    (raw_reflection_lt_F25 n)

/-- The input lies below Contender 24's family. -/
theorem input_lt_family24 (n : Nat) : n < family24 n :=
  Nat.lt_trans (input_lt_F24 n) (input_lt_F24 (F24 n))

/-- `F25` is strictly inflationary on numerical inputs. -/
theorem input_lt_F25 (n : Nat) : n < F25 n :=
  Nat.lt_trans (input_lt_family24 n) (family24_lt_F25 n)

/-- Pointwise, the old growth function is already below the new one. -/
theorem F24_lt_F25 (n : Nat) : F24 n < F25 n :=
  Nat.lt_trans (input_lt_F24 (F24 n)) (family24_lt_F25 n)

/-- Exact identity for the object-language round at the contest seed. -/
theorem roundHeight25_at_42 :
    roundHeight25 42 = iterateF24 (contender_24 + 2) 42 := rfl

/-- A strong closed lower bound: the final contender exceeds an `F24` orbit
whose length is itself `F25 42 + 2`. -/
theorem long_F24_orbit_lt_contender_25 :
    iterateF24 (F25 42 + 2) (F25 42) < contender_25 := by
  simpa only [orbit24, contender_25] using
    (orbit24_lt_F25 (i := F25 42) (n := F25 42) (Nat.le_refl _))

/-- **The required exact comparison:** Contender 24 is strictly smaller than
Contender 25. -/
theorem contender_24_lt_contender_25 : contender_24 < contender_25 := by
  have hinner : contender_24 < F25 42 := by
    simpa only [family24, contender_24] using family24_lt_F25 42
  exact Nat.lt_trans hinner (input_lt_F25 (F25 42))

/-- The new contender also exceeds Contender 23 by transitivity. -/
theorem contender_23_lt_contender_25 : contender_23 < contender_25 :=
  Nat.lt_trans contender_23_lt_contender_24 contender_24_lt_contender_25

end BusyLean
