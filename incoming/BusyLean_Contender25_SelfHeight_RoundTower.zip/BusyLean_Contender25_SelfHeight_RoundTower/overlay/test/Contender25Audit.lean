import BusyLean.Comparison25
import Lean

/-!
# Focused Contender 25 audit

Run with:

```
lake env lean test/Contender25Audit.lean
```

The file prints axiom dependencies and rejects any dependency of the new closed
number on an earlier closed contender constant.  It mirrors the repository's
main `test/Audit.lean` closure check without modifying that file.
-/

open Lean Elab Command

/-- All constants reachable from `root` through declaration types and values. -/
def constClosure25 (env : Environment) (root : Name) : NameSet := Id.run do
  let mut seen : NameSet := {}
  let mut stack := #[root]
  while stack.size > 0 do
    let c := stack.back!
    stack := stack.pop
    if seen.contains c then continue
    seen := seen.insert c
    let some ci := env.find? c | continue
    let body : Array Name := match ci with
      | .defnInfo v => v.value.getUsedConstants
      | .thmInfo v => v.value.getUsedConstants
      | .opaqueInfo v => v.value.getUsedConstants
      | _ => #[]
    stack := stack ++ ci.type.getUsedConstants ++ body
  return seen

/-- Fail if any listed constant lies in the transitive declaration closure. -/
elab "#assert_not_in_closure25 " root:ident " : " bad:ident* : command => do
  let env ← getEnv
  let r ← liftCoreM <| realizeGlobalConstNoOverloadWithInfo root
  let cl := constClosure25 env r
  for b in bad do
    let n ← liftCoreM <| realizeGlobalConstNoOverloadWithInfo b
    if cl.contains n then
      throwError m!"{r} depends on forbidden constant {n}"
  logInfo m!"{r}: closure of {cl.size} constants avoids all {bad.size} forbidden names"

#print axioms BusyLean.contender_25
#print axioms BusyLean.contender_24_lt_contender_25
#print axioms BusyLean.family24_lt_F25
#print axioms BusyLean.srvalue_lt_F25
#print axioms BusyLean.roundHeight25_at_42
#print axioms BusyLean.long_F24_orbit_lt_contender_25

#assert_not_in_closure25 BusyLean.contender_25 :
  BusyLean.contender_24 BusyLean.contender_23 BusyLean.contender_22
  BusyLean.contender_21 BusyLean.contender_20 BusyLean.contender_19
  BusyLean.contender_18 BusyLean.contender_17 BusyLean.contender_16
  BusyLean.contender_15 BusyLean.contender_14 BusyLean.contender_13
  BusyLean.contender_12 BusyLean.contender_11 BusyLean.contender_10
  BusyLean.contender_9 BusyLean.contender_8 BusyLean.contender_7
  BusyLean.contender_6 BusyLean.contender_5

#check @BusyLean.contender_24_lt_contender_25
#check @BusyLean.family24_lt_F25
#check @BusyLean.srvalue_lt_F25
#check @BusyLean.roundHeight25_at_42
#check @BusyLean.long_F24_orbit_lt_contender_25
