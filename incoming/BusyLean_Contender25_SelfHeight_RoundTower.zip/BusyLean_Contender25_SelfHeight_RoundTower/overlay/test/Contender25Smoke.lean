import BusyLean.Comparison25

/-! # Non-evaluating smoke checks for Contender 25 -/

open BusyLean

example (n : Nat) : iterateF24 0 n = n := rfl
example (n : Nat) : orbit24 0 n = family24 n := rfl
example : roundHeight25 42 = iterateF24 (contender_24 + 2) 42 := rfl

#check FL.selfRoundLadderUpTo
#check reflectSRFamily
#check F25
#check contender_25
#check contender_24_lt_contender_25

-- Deliberately no evaluation of `F25`, `roundHeight25 42`, or the contender.
