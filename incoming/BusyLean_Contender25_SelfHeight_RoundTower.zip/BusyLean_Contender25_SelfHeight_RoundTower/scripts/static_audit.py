#!/usr/bin/env python3
"""Conservative source audit for the Contender 25 overlay."""
from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
LEAN_FILES = sorted((ROOT / "overlay").rglob("*.lean"))
LIB_FILES = [p for p in LEAN_FILES if "/BusyLean/" in p.as_posix()]
FORBIDDEN = {
    "sorry", "admit", "axiom", "unsafe", "partial", "noncomputable",
    "opaque", "implemented_by", "extern", "native_decide",
}


def strip_comments_and_strings(text: str) -> str:
    # Sufficiently conservative for an audit: remove nested block comments,
    # line comments, and strings before checking tokens.
    out: list[str] = []
    i = 0
    depth = 0
    in_string = False
    while i < len(text):
        if depth:
            if text.startswith("/-", i):
                depth += 1
                i += 2
            elif text.startswith("-/", i):
                depth -= 1
                i += 2
            else:
                i += 1
            continue
        if in_string:
            if text[i] == "\\":
                i += 2
            elif text[i] == '"':
                in_string = False
                i += 1
            else:
                i += 1
            continue
        if text.startswith("/-", i):
            depth = 1
            i += 2
        elif text.startswith("--", i):
            j = text.find("\n", i)
            i = len(text) if j < 0 else j
        elif text[i] == '"':
            in_string = True
            i += 1
        else:
            out.append(text[i])
            i += 1
    return "".join(out)


def main() -> int:
    errors: list[str] = []
    report: dict[str, object] = {"files": [], "forbidden_tokens": []}
    for path in LEAN_FILES:
        text = path.read_text(encoding="utf-8")
        code = strip_comments_and_strings(text)
        rel = path.relative_to(ROOT).as_posix()
        max_line = max((len(line) for line in text.splitlines()), default=0)
        sha = hashlib.sha256(path.read_bytes()).hexdigest()
        report["files"].append(
            {"path": rel, "lines": len(text.splitlines()),
             "max_line_length": max_line, "sha256": sha}
        )
        if max_line > 100:
            errors.append(f"{rel}: line longer than 100 columns ({max_line})")
        for token in sorted(FORBIDDEN):
            if re.search(rf"\b{re.escape(token)}\b", code):
                report["forbidden_tokens"].append({"path": rel, "token": token})
                errors.append(f"{rel}: forbidden token in code: {token}")

    # Closed numeral must use F24's construction, not the old closed constant.
    contender = (ROOT / "overlay/BusyLean/Contender25.lean").read_text(encoding="utf-8")
    code = strip_comments_and_strings(contender)
    if re.search(r"\bcontender_24\b", code):
        errors.append("Contender25.lean mentions the closed constant contender_24")
    if "def contender_25 : Nat := F25 (F25 42)" not in contender:
        errors.append("expected closed contender definition not found")

    out = ROOT / "verification/static_audit.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if errors:
        print("STATIC AUDIT: FAIL")
        for error in errors:
            print(f"- {error}")
        return 1
    print(f"STATIC AUDIT: PASS ({len(LEAN_FILES)} Lean files; {len(LIB_FILES)} library files)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
