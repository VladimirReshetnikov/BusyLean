#!/usr/bin/env python3
"""Kernel build, time-budget check, and focused axiom audit.

Run from an integrated BusyLean checkout after copying the overlay files:

    python3 scripts/check25.py

This script is supplied for reproducibility.  It was not executed in the
artifact environment because Lean/Lake 4.34.0 was unavailable there.
"""
from __future__ import annotations

import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BUILD_DIRS = [ROOT / ".lake" / "build"]
PERMITTED = {"propext", "Quot.sound"}
PREVIOUS = "BusyLean.Comparison24"
CURRENT_DEF = "BusyLean.Contender25"
CURRENT_PROOF = "BusyLean.Comparison25"
DEFINITION_BUDGET = 15.0
PROOF_BUDGET = 60.0
LAKE = shutil.which("lake") or "lake"


def run(args: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [LAKE, *args], cwd=ROOT, capture_output=True, text=True
    )


def timed_build(label: str, targets: list[str], budget: float | None) -> float:
    start = time.monotonic()
    build = run(["build", *targets])
    elapsed = time.monotonic() - start
    if build.returncode != 0:
        print(build.stdout)
        print(build.stderr, file=sys.stderr)
        raise SystemExit(f"FAIL: {label} build failed")
    note = f"budget {budget:.0f} s" if budget else "accepted earlier"
    print(f"{label}: {elapsed:.2f} s ({note})")
    if budget is not None and elapsed > budget:
        raise SystemExit(f"FAIL: {label} exceeded budget")
    return elapsed


def main() -> None:
    for directory in BUILD_DIRS:
        shutil.rmtree(directory, ignore_errors=True)

    total = timed_build("previous contender", [PREVIOUS], None)
    total += timed_build("definitions", [CURRENT_DEF], DEFINITION_BUDGET)
    total += timed_build("proofs", [CURRENT_PROOF], PROOF_BUDGET)
    print(f"total clean build: {total:.2f} s")

    smoke = run(["env", "lean", "test/Contender25Smoke.lean"])
    if smoke.returncode != 0:
        print(smoke.stdout)
        print(smoke.stderr, file=sys.stderr)
        raise SystemExit("FAIL: smoke test")

    audit = run(["env", "lean", "test/Contender25Audit.lean"])
    out = audit.stdout + audit.stderr
    print(out)
    if audit.returncode != 0:
        raise SystemExit("FAIL: focused audit did not run cleanly")
    reports = re.findall(
        r"'([^']+)' (?:depends on axioms: \[([^\]]*)\]|does not depend)", out
    )
    bad = [
        (name, axioms)
        for name, axioms in reports
        if axioms
        and set(a.strip() for a in axioms.split(",")) - PERMITTED
    ]
    if not reports:
        raise SystemExit("FAIL: no axiom reports found")
    if bad:
        raise SystemExit(f"FAIL: forbidden axioms: {bad}")
    print(
        f"PASS: {len(reports)} declarations audited; "
        f"axioms within {sorted(PERMITTED)}"
    )


if __name__ == "__main__":
    main()
