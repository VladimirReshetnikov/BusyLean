#!/usr/bin/env bash
set -euo pipefail

# Usage: ./scripts/install_overlay.sh /path/to/BusyLean
# The script copies new files only and appends two imports if absent.

if [[ $# -ne 1 ]]; then
  echo "usage: $0 /path/to/BusyLean" >&2
  exit 2
fi

PKG="$(cd "$(dirname "$0")/.." && pwd)"
DST="$(cd "$1" && pwd)"

[[ -f "$DST/lakefile.toml" && -f "$DST/BusyLean.lean" ]] || {
  echo "not a BusyLean checkout: $DST" >&2
  exit 1
}

grep -qx 'leanprover/lean4:v4.34.0' "$DST/lean-toolchain" || {
  echo "unexpected Lean toolchain" >&2
  exit 1
}

for rel in \
  BusyLean/Contender25.lean \
  BusyLean/Comparison25.lean \
  test/Contender25Audit.lean \
  test/Contender25Smoke.lean; do
  src="$PKG/overlay/$rel"
  dst="$DST/$rel"
  if [[ -e "$dst" ]]; then
    echo "refusing to overwrite $dst" >&2
    exit 1
  fi
  install -D -m 0644 "$src" "$dst"
done

for imp in \
  'import BusyLean.Contender25' \
  'import BusyLean.Comparison25'; do
  grep -qxF "$imp" "$DST/BusyLean.lean" || printf '%s\n' "$imp" >> "$DST/BusyLean.lean"
done

install -m 0755 "$PKG/scripts/check25.py" "$DST/scripts/check25.py"
echo "Overlay installed. Run: python3 scripts/check25.py"
