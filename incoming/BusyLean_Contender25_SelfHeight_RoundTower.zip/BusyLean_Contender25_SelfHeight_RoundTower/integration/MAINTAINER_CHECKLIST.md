# Maintainer integration checklist

1. Confirm the target checkout still contains the Contender 24 API recorded in
   `research/source_manifest.json`.
2. Apply `integration/busylean-contender25.patch`, or use
   `scripts/install_overlay.sh`.
3. Run `python3 scripts/check25.py` in the checkout.
4. Record definition and proof times.
5. Confirm focused axiom and closure audits pass.
6. Add the new declarations to the repository-wide `test/Audit.lean`.
7. Promote the C25 targets into the repository-wide `scripts/check.py` only
   after acceptance.
8. Update README history, current-contender statement, dependency diagram, and
   any generated article maintained by the repository.
9. Recompute repository-wide hashes and CI receipts.
10. Keep the article's distinction between heuristic ordinal interpretation and
    exact formal WFO facts.
