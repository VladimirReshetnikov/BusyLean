# Risk register

| Risk | Consequence | Mitigation in the package | Acceptance criterion |
|---|---|---|---|
| Lean 4.34.0 was unavailable in the artifact runtime | Source may need a small elaboration repair | Definitions and proofs closely mirror accepted Contenders 23-24; focused smoke and audit files are supplied | `lake build BusyLean.Contender25 BusyLean.Comparison25` succeeds |
| Dependent type `roundTower (roundHeight25 n).T` may stress elaboration | Definition-phase budget could be exceeded | The height remains stuck on variable `n`; no closed evaluation is requested | Definition phase <= 15 seconds after C24 is prebuilt |
| A `simpa` or `rfl` may expose a definitional-equality mismatch | Proof module fails despite correct mathematics | Each vulnerable equality is isolated (`orbit24_zero`, `roundHeight25_at_42`) and has an obvious explicit rewrite fallback | Proof phase <= 60 seconds |
| Hidden forbidden axiom enters through proof automation | Contest audit fails | No new automation beyond accepted arithmetic/order lemmas; focused `#print axioms` audit included | Every report is a subset of `{propext, Quot.sound}` |
| New numeral accidentally mentions an older closed contender | Violates no-laziness/dependency rule | Static audit rejects `contender_24` in executable C25 code; Lean closure audit rejects all C5-C24 constants | Focused closure check passes |
| Heuristic ordinal language is overstated | Mathematical interpretation becomes misleading | Article separates exact WFO definitions from heuristic order-type language | Review accepts all heuristic statements as explicitly labeled |
| Repository head changes before integration | Patch may no longer apply cleanly | Exact baseline commit and source blob hashes are recorded; overlay files are standalone | Rebase/review against new head and rerun full checks |
| Self-height construction is judged too parameter-driven | Proposal may be formally valid but architecturally uninteresting | Height changes the object-language universe index and both W-tree amplifier parameters; program-value and orbit bounds are retained | Maintainer review confirms qualitative novelty |
