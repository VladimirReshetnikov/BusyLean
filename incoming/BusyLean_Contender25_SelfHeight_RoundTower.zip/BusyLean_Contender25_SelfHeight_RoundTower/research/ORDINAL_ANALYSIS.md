# Ordinal and growth analysis

## Exact formal content

The proposal does **not** identify Lean's tree orders with quotient ordinals.
The exact formal objects are:

1. `roundTower k`, a computable well-founded order produced by iterating
   `limitAlong` from the repository's relativized Buchholz tower;
2. `roundHeight25 n`, a concrete natural number computed by finite recursion;
3. `schedule25 n` and `rank25 n`, concrete well-founded `WTree Nat` values;
4. a finite enumeration of syntax at depth `n` over the atom order
   `roundTower (roundHeight25 n)`;
5. a closed natural number obtained by normalization, finite maxima, and
   structural recursion over well-founded trees.

The formal domination theorem is independent of any heuristic assignment of
order types.  It follows from the visible seed coordinate and generic
progressivity/strict-inflation theorems.

## Heuristic reading

The repository describes one tower stage over an index element `j` as behaving
like a relativized Buchholz collapse of approximate type

    psi_0(Omega_omega * (j + 1)),

and one complete `limitAlong` round as moving to a new fixed-point scale for
`x |-> psi_0(Omega_omega * x)`.  Contender 24 selects round `n` at input `n`.
The proposed contender selects instead

    iterateF24 (family24 n + 2) n.

At `n = 42`, the iteration count is exactly `contender_24 + 2`.  Thus the
proposal does not merely add another fixed autonomous tree above the old
language: it feeds the old complete family into the *height of the round-tower
language itself*, and then applies a fresh W-ranked amplifier at that height.

This should be read as a structural growth diagnosis, not as a theorem that
`roundTower k` has a particular canonical ordinal type.  Proving a precise
ordinal semantics for `towerAlong`, including embeddings between rounds and a
continuity theorem for `limitAlong`, is an important separate project.

## Why this is more than “old contender plus one”

The closed constant `contender_24` never occurs in the definition of
`contender_25`.  The prior **construction** `F24` is used in three nontrivial
ways:

- its double iterate supplies seed coordinate zero, enabling an exact formal
  comparison;
- a self-length finite orbit determines the language's round index;
- the same self-height controls two autonomous W-tree closures used as the
  schedule and the lift rank.

The numerical guard `n + 1 + ...` is not the source of the proposed magnitude;
it only supplies the local strictness needed by the proof.  The magnitude comes
from normalization over a much higher universe ladder and from W-ranked
hyperreflection over that progressive transformer.

## Conservative claims

The package claims only what its source supports:

- computability in principle;
- a complete proposed Lean proof term for strict domination;
- architectural lower bounds recorded in `Comparison25.lean`.

It does not claim a decimal expansion, feasible evaluation, a calibrated
fast-growing-hierarchy index, or kernel acceptance before Lean 4.34.0 replay.
