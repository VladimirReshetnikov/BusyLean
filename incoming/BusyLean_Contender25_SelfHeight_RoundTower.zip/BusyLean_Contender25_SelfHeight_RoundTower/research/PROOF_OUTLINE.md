# Proof outline: Contender 24 < Contender 25

## 1. Definitions

Let

- `family24 n = F24 (F24 n)`;
- `iterateF24 k n` be the `k`-fold iterate of `F24` from `n`;
- `orbit24 i n = iterateF24 (i + 2) n`;
- `roundHeight25 n = orbit24 (family24 n) n`.

The first coordinate is definitionally the old family:

```lean
orbit24 0 n = F24 (F24 n) = family24 n.
```

At the contest seed,

```lean
roundHeight25 42 = iterateF24 (contender_24 + 2) 42.
```

The new reflector enumerates well-typed programs of depth/fuel at most `n`
over the atom order `roundTower (roundHeight25 n)` and takes a guarded finite
maximum over their values and the visible prefix of its oracle family.

The new growth function is

```lean
F25 n =
  wDiagonalLift (schedule25 n) (rank25 n)
    srTransformer orbit24 n n
```

and the closed number is `contender_25 = F25 (F25 42)`.

## 2. Progressivity of one reflection step

The finite maximum inside `reflectSRFamily fs n` contains every visible oracle
value `fs i n` for `i <= n`.  The leading `n + 1 +` guard makes the reflector
strictly larger than that maximum.  Hence

```lean
oracle_lt_reflectSRFamily :
  i <= n -> fs i n < reflectSRFamily fs n
```

and therefore `srTransformer` is progressive.

The same guard gives a program-value bound for every term in
`FL.selfRoundLadderUpTo n`.

## 3. Preservation through W-ranked hyperreflection

The accepted generic theorem

```lean
wDiagonalLift_preservesProgressive
```

states that every W-tree rank preserves progressivity of a transformer.  Apply
it to `srTransformer`, seed family `orbit24`, input `n`, visible seed coordinate
`i`, and output coordinate `n`.  This yields

```lean
orbit24 i n < F25 n       whenever i <= n.
```

Taking `i = 0` and rewriting `orbit24 0 n` gives

```lean
family24 n < F25 n.
```

No monotonicity in oracle families is assumed; such monotonicity is generally
false because reflected programs may branch on oracle values.

## 4. Input growth

The accepted theorem `input_lt_F24` gives

```lean
n < F24 n < F24 (F24 n) = family24 n.
```

Combining this with `family24 n < F25 n` proves `n < F25 n`.

## 5. Closed comparison

At `n = 42`, `family24 42` is definitionally `contender_24`, so

```lean
contender_24 < F25 42.
```

Input growth applied to `F25 42` gives

```lean
F25 42 < F25 (F25 42) = contender_25.
```

Transitivity proves the required theorem:

```lean
contender_24_lt_contender_25 : contender_24 < contender_25.
```

## 6. Stronger retained bounds

The package also proposes proofs that:

- every visible `F24`-orbit coordinate lies below `F25 n`;
- every enumerated self-height round-tower program lies below `F25 n`;
- `F24 n < F25 n` pointwise;
- the final contender exceeds the `F24` orbit of length `F25 42 + 2` starting
  at `F25 42`.

These statements make the comparison architecture substantially more explicit
than the single closed inequality required by the contest.
