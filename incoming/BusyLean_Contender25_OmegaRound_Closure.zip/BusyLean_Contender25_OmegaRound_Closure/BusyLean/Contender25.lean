import BusyLean.Ordinal.OmegaRound
import BusyLean.Contender24

/-!
# Contender 25: omega-round closure with self-fed continuation

```
contender_25 := F25 (F25 42)
F25 n        := wDiagonalLift (schedule25 n) (rank25 n)
                  oTransformer orbit24 n n
```

Contender 24 uses the ladder over the finite round `roundTower n`.  Here the
object language starts with `omegaRound`, the ordered sum of *all* finite
rounds, and then applies `limitAlong` a self-fed number of times.  Thus the
language itself crosses the first explicit limit of the existing round
hierarchy before the W-ranked reflection amplifier is applied.

The seed exposes a finite orbit of `F24`; coordinate zero is Contender 24's
family, while later visible coordinates are longer iterates.  The same orbit
provides the post-omega height.  The source never uses the closed constant
`contender_24`.  All definitions are constructive and computable in principle.
Never evaluate the final number.
-/

namespace BusyLean

/-- Contender 24's construction as a function of its input:
`family24 42 = contender_24` by definitional equality. -/
def family24 (n : Nat) : Nat := F24 (F24 n)

/-- Finite iteration of `F24`, with the newest iterate outermost.  This
orientation makes strict growth use only `input_lt_F24`, not monotonicity. -/
def iterateF24 : Nat → Nat → Nat
  | 0, n => n
  | k + 1, n => F24 (iterateF24 k n)

/-- Coordinate `i` is the `(i+2)`-fold `F24` iterate from `n`.  Coordinate zero
is definitionally `family24 n`. -/
def orbit24 : Family := fun i n => iterateF24 (i + 2) n

/-- A long, self-fed orbit value controlling the language and amplifier. -/
def seedHeight25 (n : Nat) : Nat := orbit24 (family24 n) n

/-- A self-fed number of rounds strictly above the omega-limit. -/
def metaHeight25 (n : Nat) : Nat := seedHeight25 n + 1

end BusyLean

namespace BusyLean.FL

open Ordinal

/-- Strong normalization for a ladder over a post-omega round. -/
theorem sn_erase_omegaRound {f : Nat → Nat} (K : Nat)
    {fuel : Nat} {t : CTm (omegaRoundTower K).T}
    (h : infer fuel [] [] t = some Ty.nat) : F.SN f (erase t) :=
  sn_of_typed (wfUniv f (omegaRoundTower_wf K))
    (infer_sound fuel t (goodCtx_nil []) h).1

/-- The value of a program over the atoms of `omegaRoundTower K`, checked with
`fuel`, relative to oracle `f`. -/
def ovalue (K : Nat) (f : Nat → Nat) (fuel : Nat)
    (t : CTm (omegaRoundTower K).T) : Nat :=
  match h : infer fuel [] [] t with
  | some A =>
      if hA : A = Ty.nat then
        F.decode
          (F.nf f
            ⟨erase t,
              sn_erase_omegaRound K
                (h.trans (congrArg some hA))⟩)
      else 0
  | none => 0

/-- Programs of depth at most `n` over the post-omega atom order at height
`K`. -/
def omegaRoundLadderUpTo (K n : Nat) :
    List (CTm (omegaRoundTower K).T) :=
  ctmsUpTo ((omegaRoundTower K).enum n) n

end BusyLean.FL

namespace BusyLean

open BigNumber (WTree)
open BusyLean.W

/-- The maximum output of the bounded post-omega ladder language. -/
def omegaProgramMaximum (fs : Family) (n : Nat) : Nat :=
  BigNumber.maximum
    (FL.ovalue (metaHeight25 n) (packFamily fs) n)
    (FL.omegaRoundLadderUpTo (metaHeight25 n) n)

/-- The finite bound reflected by one post-omega reflection step. -/
def omegaReflectionBound (fs : Family) (n : Nat) : Nat :=
  BigNumber.maxN (prefixMax (fun i => fs i n) n)
    (omegaProgramMaximum fs n)

/-- Reflection over the post-omega ladder, with a countable oracle family. -/
def reflectOFamily (fs : Family) (n : Nat) : Nat :=
  n + 1 + omegaReflectionBound fs n

/-- The family-aware post-omega reflection transformer. -/
def oTransformer : Transformer := fun fs _ n => reflectOFamily fs n

/-- An autonomous schedule placed above Contender 24's rank tree. -/
def schedule25 (n : Nat) : WTree Nat :=
  Autonomous.realize
    (Autonomous.hyper (seedHeight25 n + 42)
      (Autonomous.encode (rank24 n)))

/-- A second autonomous closure, used as the transfinite lift rank. -/
def rank25 (n : Nat) : WTree Nat :=
  Autonomous.realize
    (Autonomous.hyper (seedHeight25 n + 42)
      (Autonomous.encode (schedule25 n)))

/-- W-ranked hyperreflection of the self-fed post-omega ladder language. -/
def F25 (n : Nat) : Nat :=
  wDiagonalLift (schedule25 n) (rank25 n)
    oTransformer orbit24 n n

/-- **Contender 25.**  This is a closed, constructive natural number.  Never
evaluate it. -/
def contender_25 : Nat := F25 (F25 42)

end BusyLean
