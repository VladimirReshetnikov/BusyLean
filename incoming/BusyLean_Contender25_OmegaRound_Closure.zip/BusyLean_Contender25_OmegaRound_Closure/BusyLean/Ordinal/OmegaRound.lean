import BusyLean.Ordinal.TowerAlong

/-!
# The omega-limit of the finite round hierarchy

`roundTower k` is the finite round hierarchy used by Contender 24.  This module
forms one well-founded order containing every finite round as a summand, then
continues the same `limitAlong` operation above that omega-limit.

Everything is executable.  The only recursion is structural recursion on
natural numbers or the already certified well-founded recursion in
`WFO.towerAlong`.
-/

namespace BusyLean.Ordinal

open BuchB

namespace BuchB.WFO

/-- Accessibility of a natural number for the Boolean presentation of `<`. -/
theorem omegaIndex_acc (n : Nat) :
    Acc (fun a b : Nat => decide (a < b) = true) n := by
  have h := Nat.lt_wfRel.wf.apply n
  induction h with
  | intro n _ ih =>
      exact Acc.intro n fun m hm =>
        ih m (by simpa only [decide_eq_true_eq] using hm)

/-- The standard well-order of the natural numbers, packaged as a `WFO`. -/
def omegaIndex : WFO where
  T := Nat
  dec := inferInstance
  lt := fun a b => decide (a < b)
  trans := by
    intro a b c hab hbc
    simp only [decide_eq_true_eq] at hab hbc ⊢
    exact Nat.lt_trans hab hbc
  wf := omegaIndex_acc
  enum := fun n => List.range (n + 1)

end BuchB.WFO

/-- The ordered sum of all finite rounds used by Contender 24.

Its elements are pairs `⟨k, x⟩` with `x : (roundTower k).T`.  The outer
natural-number coordinate is compared first, so every finite round occurs as a
whole block below every later block.
-/
def omegaRound : BuchB.WFO :=
  BuchB.WFO.sigma BuchB.WFO.omegaIndex roundTower

/-- The canonical inclusion of the `k`-th finite round into `omegaRound`. -/
def intoOmegaRound (k : Nat) (x : (roundTower k).T) : omegaRound.T :=
  ⟨k, x⟩

/-- Rounds continued above the omega-limit of all finite rounds. -/
def omegaRoundTower : Nat → BuchB.WFO
  | 0 => omegaRound
  | k + 1 => (omegaRoundTower k).limitAlong

/-- Every post-omega round is a well-founded atom order for the ladder
language. -/
theorem omegaRoundTower_wf (k : Nat) :
    WellFounded (FL.ALt (α := (omegaRoundTower k).T)) :=
  ⟨(omegaRoundTower k).wf⟩

end BusyLean.Ordinal
