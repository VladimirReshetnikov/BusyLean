import BusyLean.Contender25
import BusyLean.Comparison24

/-! # Contender 25: exact comparison theorems -/

namespace BusyLean

open BusyLean.W

/-- The additive guard strictly exceeds the finite bound being reflected. -/
theorem lt_reflectOFamily {fs : Family} {n m : Nat}
    (h : m ≤ omegaReflectionBound fs n) :
    m < reflectOFamily fs n := by
  show m < n + 1 + omegaReflectionBound fs n
  have hM : ∀ M : Nat, M + 1 ≤ n + 1 + M := fun M => by
    rw [Nat.add_comm M 1]
    exact Nat.add_le_add_right (Nat.le_add_left 1 n) M
  exact Nat.lt_of_le_of_lt h
    (Nat.lt_of_lt_of_le (Nat.lt_succ_self _) (hM _))

/-- Every visible oracle coordinate lies below one post-omega reflection step. -/
theorem oracle_lt_reflectOFamily (fs : Family) {i n : Nat} (hi : i ≤ n) :
    fs i n < reflectOFamily fs n :=
  lt_reflectOFamily
    (Nat.le_trans (le_prefixMax (fun j => fs j n) hi)
      (BigNumber.le_maxN_left _ _))

/-- Every enumerated post-omega ladder program lies below one reflection
step. -/
theorem ovalue_lt_reflectOFamily (fs : Family) {n : Nat}
    {t : FL.CTm ((Ordinal.omegaRoundTower (metaHeight25 n)).T)}
    (ht : t ∈ FL.omegaRoundLadderUpTo (metaHeight25 n) n) :
    FL.ovalue (metaHeight25 n) (packFamily fs) n t <
      reflectOFamily fs n :=
  lt_reflectOFamily
    (Nat.le_trans
      (le_maximum
        (FL.ovalue (metaHeight25 n) (packFamily fs) n) ht)
      (BigNumber.le_maxN_right _ _))

/-- Post-omega reflection is progressive. -/
theorem oTransformer_progressive : Progressive oTransformer :=
  fun seed _ _ _ hi => oracle_lt_reflectOFamily seed hi

/-- One more finite `F24` iterate is strictly larger.  No monotonicity of `F24`
is used. -/
theorem iterateF24_lt_succ (k n : Nat) :
    iterateF24 k n < iterateF24 (k + 1) n := by
  simpa only [iterateF24] using input_lt_F24 (iterateF24 k n)

/-- Coordinate zero of the exposed orbit is Contender 24's family. -/
theorem orbit24_zero (n : Nat) : orbit24 0 n = family24 n := rfl

/-- Every visible `F24`-orbit coordinate lies below `F25 n`. -/
theorem orbit24_lt_F25 {i n : Nat} (hi : i ≤ n) : orbit24 i n < F25 n := by
  have h :=
    ((wDiagonalLift_preservesProgressive (schedule25 n) (rank25 n))
      oTransformer oTransformer_progressive)
      orbit24 i n n hi
  simpa only [F25] using h

/-- At every input, `F25` exceeds Contender 24's whole family. -/
theorem family24_lt_F25 (n : Nat) : family24 n < F25 n := by
  simpa only [orbit24_zero] using
    (orbit24_lt_F25 (i := 0) (n := n) (Nat.zero_le n))

/-- The raw post-omega reflection is strictly below the full W-ranked
amplifier. -/
theorem raw_reflection_lt_F25 (n : Nat) :
    reflectOFamily orbit24 n < F25 n :=
  (wDiagonalLift_strictlyInflationary (schedule25 n) (rank25 n))
    oTransformer oTransformer_progressive
    orbit24 n n n (Nat.le_refl n)

/-- Every bounded program in the post-omega ladder, run with the packed seed,
is below `F25 n`. -/
theorem ovalue_lt_F25 {n : Nat}
    {t : FL.CTm ((Ordinal.omegaRoundTower (metaHeight25 n)).T)}
    (ht : t ∈ FL.omegaRoundLadderUpTo (metaHeight25 n) n) :
    FL.ovalue (metaHeight25 n) (packFamily orbit24) n t < F25 n :=
  Nat.lt_trans
    (ovalue_lt_reflectOFamily orbit24 ht)
    (raw_reflection_lt_F25 n)

/-- The numerical input lies below Contender 24's family. -/
theorem input_lt_family24 (n : Nat) : n < family24 n :=
  Nat.lt_trans (input_lt_F24 n) (input_lt_F24 (F24 n))

/-- `F25` is strictly inflationary on numerical inputs. -/
theorem input_lt_F25 (n : Nat) : n < F25 n :=
  Nat.lt_trans (input_lt_family24 n) (family24_lt_F25 n)

/-- **The required exact comparison:** Contender 24 is strictly smaller than
Contender 25. -/
theorem contender_24_lt_contender_25 : contender_24 < contender_25 :=
  Nat.lt_trans (family24_lt_F25 42) (input_lt_F25 (F25 42))

/-- A strong closed lower bound: the final contender exceeds an `F24` orbit
whose length is itself `F25 42 + 2`. -/
theorem long_F24_orbit_lt_contender_25 :
    iterateF24 (F25 42 + 2) (F25 42) < contender_25 := by
  simpa only [orbit24, contender_25] using
    (orbit24_lt_F25 (i := F25 42) (n := F25 42) (Nat.le_refl _))

/-- Contender 25 also exceeds Contender 23, by transitivity. -/
theorem contender_23_lt_contender_25 : contender_23 < contender_25 :=
  Nat.lt_trans contender_23_lt_contender_24 contender_24_lt_contender_25

end BusyLean
