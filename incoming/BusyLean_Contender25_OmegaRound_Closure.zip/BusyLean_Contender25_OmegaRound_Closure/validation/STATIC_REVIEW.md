# Static review and validation record

Date: 2026-10-13

## Scope

This record covers the proposal files in this archive.  It is not a substitute
for Lean kernel replay.

## Repository baseline

- Repository: `VladimirReshetnikov/BusyLean`
- Inspected commit: `4fe4f5ed921a8e861d33008a368c6e6ff5b40446`
- Current checked-in champion at that commit: Contender 24
- Expected toolchain: Lean 4.34.0

The proposal was written against the exact signatures and proof patterns in:

- `BusyLean/Ordinal/TowerAlong.lean`
- `BusyLean/Contender24.lean`
- `BusyLean/Comparison24.lean`
- `BusyLean/TreeHyperReflection.lean`
- `BusyLean/TreeHyperReflectionFacts.lean`
- `BusyLean/SystemFL/Transfinite.lean`

## Completed checks

1. All new Lean sources were scanned after removal of nested comments and
   strings.
2. No forbidden construct was found: `noncomputable`, `partial`, `unsafe`,
   `opaque`, `axiom`, `sorry`, `admit`, `implemented_by`, `extern`,
   `native_decide`, or `Classical.choice`.
3. Delimiters were balanced in each Lean source.
4. The definition source for Contender 25 does not textually mention the closed
   constant `contender_24` outside comments.
5. The expected definition and theorem inventory is present.
6. The Python clean-build harness parses and byte-compiles.
7. The unified overlay patch applies cleanly to an exact local reconstruction
   of the inspected `BusyLean.lean` import file.
8. The LaTeX article compiles without errors, overfull boxes, or unresolved
   references.
9. The 22-page PDF passes structural preflight, has embedded fonts, and was
   rendered at 200 dpi.
10. Contact sheets and representative full-resolution pages were visually
    inspected; no clipping, overlap, black boxes, or broken glyphs were found.

The machine-readable output of the source scan is in
`static-validation.txt`.  PDF metadata is in `pdf-inspect.txt` and
`pdf-preflight.txt`.

## Kernel status

The generation container had no `lean`, `lake`, or `elan` executable, and
outbound DNS was unavailable.  Consequently:

- the new modules were **not** compiled by Lean in this environment;
- the 15-second definition budget and 60-second proof budget were **not**
  measured here;
- the expected axiom set was **not** kernel-reported here; and
- the transitive dependency closure was **not** computed by Lean here.

The archive therefore includes `scripts/check_contender25.py` and a CI workflow
that make these checks mandatory on integration.

## Main elaboration risks to watch during replay

1. The accessibility proof for `omegaIndex` converts
   `decide (m < n) = true` to `m < n` with a narrowly scoped `simpa only`.
2. The carrier of `omegaRound` is exposed definitionally through the projection
   `omegaRound.T` in `intoOmegaRound`.
3. `omegaReflectionBound` is a named wrapper around a dependent maximum; the
   comparison proofs rely on delta-reduction of this small wrapper.
4. Final endpoint matching uses definitional equality between
   `family24 42` and `contender_24`, as in the accepted comparison pattern.

If any of these produces an elaboration mismatch, the preferred repair is a
local type annotation, `change`, or `simpa only`.  Broad simplification of
`F24 42`, `family24 42`, or `F25 42` must be avoided.

## Acceptance gate

Do not describe the proposal as kernel-validated until the following command
passes in the target checkout:

```bash
python3 scripts/check_contender25.py
```
