#!/usr/bin/env python3
"""Static validation for the Contender 25 proposal artifact.

This is deliberately not presented as a Lean kernel check.  It catches common
submission errors before external replay with Lean 4.34.0.
"""
from __future__ import annotations

import ast
import hashlib
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LEAN_FILES = [
    ROOT / "BusyLean" / "Ordinal" / "OmegaRound.lean",
    ROOT / "BusyLean" / "Contender25.lean",
    ROOT / "BusyLean" / "Comparison25.lean",
    ROOT / "test" / "Contender25Audit.lean",
]

FORBIDDEN = [
    r"\bnoncomputable\b",
    r"\bpartial\b",
    r"\bunsafe\b",
    r"\bopaque\b",
    r"\baxiom\b",
    r"\bsorry\b",
    r"\badmit\b",
    r"\bimplemented_by\b",
    r"\bextern\b",
    r"\bnative_decide\b",
    r"\bClassical\.choice\b",
]

EXPECTED = {
    "BusyLean/Ordinal/OmegaRound.lean": [
        "def omegaIndex",
        "def omegaRound",
        "def intoOmegaRound",
        "def omegaRoundTower",
        "theorem omegaRoundTower_wf",
    ],
    "BusyLean/Contender25.lean": [
        "def family24",
        "def iterateF24",
        "def orbit24",
        "def seedHeight25",
        "def metaHeight25",
        "theorem sn_erase_omegaRound",
        "def ovalue",
        "def reflectOFamily",
        "def schedule25",
        "def rank25",
        "def F25",
        "def contender_25",
    ],
    "BusyLean/Comparison25.lean": [
        "theorem oTransformer_progressive",
        "theorem iterateF24_lt_succ",
        "theorem orbit24_lt_F25",
        "theorem family24_lt_F25",
        "theorem ovalue_lt_F25",
        "theorem input_lt_F25",
        "theorem contender_24_lt_contender_25",
        "theorem long_F24_orbit_lt_contender_25",
    ],
}


def strip_lean_comments_and_strings(text: str) -> str:
    """Remove nested block comments, line comments, and string contents."""
    out: list[str] = []
    i = 0
    block_depth = 0
    in_string = False
    while i < len(text):
        if block_depth:
            if text.startswith("/-", i):
                block_depth += 1
                i += 2
            elif text.startswith("-/", i):
                block_depth -= 1
                i += 2
            else:
                if text[i] == "\n":
                    out.append("\n")
                i += 1
            continue
        if in_string:
            if text[i] == "\\" and i + 1 < len(text):
                i += 2
            elif text[i] == '"':
                in_string = False
                out.append('"')
                i += 1
            else:
                if text[i] == "\n":
                    out.append("\n")
                i += 1
            continue
        if text.startswith("/-", i):
            block_depth = 1
            i += 2
        elif text.startswith("--", i):
            j = text.find("\n", i)
            if j == -1:
                break
            out.append("\n")
            i = j + 1
        elif text[i] == '"':
            in_string = True
            out.append('"')
            i += 1
        else:
            out.append(text[i])
            i += 1
    if block_depth:
        raise AssertionError("unterminated Lean block comment")
    if in_string:
        raise AssertionError("unterminated Lean string")
    return "".join(out)


def check_delimiters(text: str, label: str) -> None:
    pairs = {")": "(", "]": "[", "}": "{", "⟩": "⟨"}
    opens = set(pairs.values())
    stack: list[tuple[str, int]] = []
    for pos, char in enumerate(text):
        if char in opens:
            stack.append((char, pos))
        elif char in pairs:
            if not stack or stack[-1][0] != pairs[char]:
                raise AssertionError(f"{label}: mismatched delimiter {char!r} at {pos}")
            stack.pop()
    if stack:
        raise AssertionError(f"{label}: unclosed delimiters: {stack[-5:]}")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def main() -> None:
    results: list[str] = []
    for path in LEAN_FILES:
        assert path.exists(), f"missing {path}"
        raw = path.read_text(encoding="utf-8")
        code = strip_lean_comments_and_strings(raw)
        check_delimiters(code, str(path.relative_to(ROOT)))
        for pattern in FORBIDDEN:
            if re.search(pattern, code):
                raise AssertionError(
                    f"forbidden construct {pattern!r} in {path.relative_to(ROOT)}"
                )
        results.append(f"PASS source scan: {path.relative_to(ROOT)}")

    definition_code = strip_lean_comments_and_strings(
        (ROOT / "BusyLean" / "Contender25.lean").read_text(encoding="utf-8")
    )
    if re.search(r"\bcontender_24\b", definition_code):
        raise AssertionError("Contender25 definition source mentions contender_24")
    results.append("PASS no-laziness textual precheck: contender_24 absent from definition code")

    for rel, needles in EXPECTED.items():
        text = (ROOT / rel).read_text(encoding="utf-8")
        for needle in needles:
            if needle not in text:
                raise AssertionError(f"missing expected declaration {needle!r} in {rel}")
    results.append("PASS expected declaration inventory")

    checker = ROOT / "scripts" / "check_contender25.py"
    ast.parse(checker.read_text(encoding="utf-8"), filename=str(checker))
    subprocess.run(
        ["python", "-m", "py_compile", str(checker)], check=True, cwd=ROOT
    )
    results.append("PASS Python build harness syntax")

    tex_log = ROOT / "validation" / "latex-build.log"
    log = tex_log.read_text(encoding="utf-8", errors="replace")
    bad_markers = ["LaTeX Error", "Overfull \\hbox", "undefined references"]
    for marker in bad_markers:
        if marker in log:
            raise AssertionError(f"LaTeX build log contains {marker!r}")
    pdf = ROOT / "article" / "contender25.pdf"
    assert pdf.exists() and pdf.stat().st_size > 100_000
    results.append(f"PASS PDF exists ({pdf.stat().st_size} bytes)")

    print("\n".join(results))
    print("\nSHA-256 core files:")
    for path in LEAN_FILES + [checker, ROOT / "article" / "contender25.tex", pdf]:
        print(f"{sha256(path)}  {path.relative_to(ROOT)}")
    print("\nNOTE: static validation is not a Lean kernel replay.")


if __name__ == "__main__":
    main()
