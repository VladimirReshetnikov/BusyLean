# BusyLean Contender 25 proposal: omega-round closure

This package proposes a new closed Lean natural number for
`VladimirReshetnikov/BusyLean`, based on repository commit
`4fe4f5ed921a8e861d33008a368c6e6ff5b40446` (2026-10-13).

## Main definition

```lean
def family24 (n : Nat) : Nat := F24 (F24 n)
def iterateF24 : Nat → Nat → Nat
  | 0, n => n
  | k + 1, n => F24 (iterateF24 k n)
def orbit24 : Family := fun i n => iterateF24 (i + 2) n
def seedHeight25 (n : Nat) : Nat := orbit24 (family24 n) n
def metaHeight25 (n : Nat) : Nat := seedHeight25 n + 1

def F25 (n : Nat) : Nat :=
  wDiagonalLift (schedule25 n) (rank25 n)
    oTransformer orbit24 n n

def contender_25 : Nat := F25 (F25 42)
```

The qualitative change is in the object language.  Contender 24 uses the
finite round `roundTower n`.  This proposal defines

```lean
def omegaRound : BuchB.WFO :=
  BuchB.WFO.sigma BuchB.WFO.omegaIndex roundTower

def omegaRoundTower : Nat → BuchB.WFO
  | 0 => omegaRound
  | k + 1 => (omegaRoundTower k).limitAlong
```

Thus `omegaRound` contains every finite `roundTower k` as a whole summand.  The
seed exposes the orbit `iterateF24 (i + 2) n`; its zero coordinate is
`family24 n`, and `seedHeight25 n` selects the much later coordinate
`family24 n`.  The reflected ladder uses
`omegaRoundTower (seedHeight25 n + 1)`.  The old finite-round hierarchy is
crossed at the language level before the existing W-tree-ranked reflection
amplifier is applied.

## Exact theorem supplied

```lean
theorem contender_24_lt_contender_25 :
    contender_24 < contender_25
```

The proof does not assume monotonicity of oracle-sensitive reflection.  It
uses the same explicit progressivity witnesses as the accepted Contender 24:
the prefix maximum exposes every visible orbit coordinate, and the generic
`wDiagonalLift_preservesProgressive` theorem lifts that strict inequality
through the W-ranked amplifier.  The package also proves the stronger closed
lower bound

```lean
iterateF24 (F25 42 + 2) (F25 42) < contender_25.
```

## Package contents

- `BusyLean/Ordinal/OmegaRound.lean`: the omega-limit atom order and its
  post-limit continuation.
- `BusyLean/Contender25.lean`: normalization, bounded evaluation, reflection,
  schedule, rank, and the closed number.
- `BusyLean/Comparison25.lean`: exact numerical domination and bounded-program
  domination theorems.
- `test/Contender25Audit.lean`: permitted-axiom and no-laziness audit.
- `scripts/check_contender25.py`: clean build, time-budget, and audit harness.
- `.github/workflows/contender25-check.yml`: CI replay workflow.
- `article/contender25.tex` and `article/contender25.pdf`: research article.
- `integration/`: overlay and patch instructions.
- `validation/`: static checks performed in the artifact-generation
  environment.

## Integration

Copy the `BusyLean/`, `test/`, `scripts/`, and `.github/` trees into a checkout
of the inspected base commit.  Add the three imports shown in
`integration/BusyLean.lean.patch`, then run:

```bash
python3 scripts/check_contender25.py
```

The harness expects the repository's pinned Lean 4.34.0 toolchain.

## Validation status

The source was designed declaration-by-declaration against the inspected
Contender 24 implementation and its generic theorems.  Static source scans, patch-application checks, PDF compilation, and artifact checks are included.  The
artifact-generation container did not contain Lean and had no outbound DNS,
so a Lean kernel replay could not be performed there.  Accordingly, the
included build and axiom receipts are **replay instructions**, not a claim of
completed kernel validation.  Any integration decision should be conditioned
on a clean run of `scripts/check_contender25.py`.

## Conceptual size claim

The theorem `contender_24_lt_contender_25` is exact.  The stronger claim that
the new construction represents an ordinal phase transition is an informed
proof-theoretic calibration, not a formal ordinal-isomorphism theorem.  In
schematic notation, if `R(J) = limitAlong J`, Contender 24 samples finite
`R^n` stages, while this proposal begins from an ordered omega-sum of all
finite stages and continues `R` for `seedHeight25 n + 1` further rounds, where
`seedHeight25 n` is an `F24` iterate whose iteration count is already
`family24 n + 2`.
