# Research notes: omega-round closure above BusyLean Contender 24

## 1. Design objective

The goal was not merely to wrap the current champion in ordinary numerical
iteration.  BusyLean's no-laziness rule permits the previous construction as a
seed only when it is placed inside a qualitatively stronger mechanism.  The
current champion already combines:

1. relativized level-bounded Buchholz systems;
2. transfinite towers along arbitrary well-founded indices;
3. finite iteration of the operation `J ↦ limitAlong J`; and
4. W-tree-ranked diagonal hyperreflection.

A credible successor therefore needs to move at least one of the two principal
axes: the object language or the amplifier.  Higher-order variants of the
amplifier have already appeared in reviewed proposals and were judged to lie
in the same broad class as W-ranked hyperreflection.  The present proposal
instead changes the object-language index.

## 2. The phase change

Write `R(J) = limitAlong J` and let `B = tower 1`.  The accepted hierarchy is

```
roundTower 0       = B
roundTower (k + 1) = R (roundTower k).
```

Contender 24 uses `roundTower n` at numerical input `n`.  The new order is

```
omegaRound = Σ (k : Nat), roundTower k,
```

with the outer coordinate compared first.  Hence every finite round is a
complete block in one certified well-founded order.  The continuation is

```
omegaRoundTower 0       = omegaRound
omegaRoundTower (k + 1) = R (omegaRoundTower k).
```

Let `iterateF24 k n` be the `k`-fold iterate of `F24` from `n`, and set
`orbit24 i n = iterateF24 (i + 2) n`.  Coordinate zero is definitionally
`family24 n = F24 (F24 n)`.  The self-fed height is

```
seedHeight25 n = orbit24 (family24 n) n
metaHeight25 n = seedHeight25 n + 1.
```

At input `n`, the ladder uses `omegaRoundTower (metaHeight25 n)`.  This gives
both an explicit limit of all finite rounds and a post-limit continuation whose
length is itself a long `F24` orbit value.

## 3. Why the ordered sum is deliberate

A true categorical direct limit would require explicit embeddings between
successive `roundTower` orders and coherence proofs.  The repository does not
yet expose those embeddings.  The ordered sum is more conservative:

- it is computable from the existing enumerations;
- its transitivity and well-foundedness are inherited from the generic
  `WFO.sigma` theorem;
- it contains each finite round definitionally as the summand
  `x ↦ ⟨k, x⟩`; and
- it avoids unproved claims that later rounds literally extend earlier ones
  as suborders.

The cost is that its exact order type is an ordinal sum rather than a quotient
or colimit.  For the purpose of making the ladder strictly broader than every
individual finite round, that is sufficient and formally cleaner.

## 4. Exact domination argument

The exact numerical comparison is intentionally independent of the heuristic
ordinal analysis.

1. `reflectOFamily fs n` adds `n + 1` to a maximum containing every visible
   oracle coordinate `fs i n`, `i ≤ n`.
2. Therefore `oTransformer` is progressive.
3. The already-proved generic theorem
   `wDiagonalLift_preservesProgressive` says that every W-ranked lift of a
   progressive transformer remains progressive.
4. Coordinate zero of the seed `orbit24` is `family24`, so
   `family24 n < F25 n`; every other visible orbit coordinate is also below
   `F25 n`.
5. Since `n < family24 n`, also `n < F25 n`.
6. At input 42, `family24 42` is definitionally `contender_24`; applying the
   last inequality again at `F25 42` yields
   `contender_24 < F25 (F25 42) = contender_25`.
7. Choosing the last visible orbit coordinate at input `F25 42` gives the
   additional exact bound
   `iterateF24 (F25 42 + 2) (F25 42) < contender_25`.

No oracle monotonicity lemma is used.  This matters because reflected programs
may branch on oracle values, so monotonicity is false in general.

## 5. Computability

All search spaces are finite at every numerical input:

- `omegaIndex.enum n = List.range (n + 1)`;
- `WFO.sigma.enum` forms a finite flat map over the finite prefix;
- `iterateF24 k n` and `omegaRoundTower K` are primitive recursions on their
  natural-number indices;
- each ladder enumeration is depth-bounded;
- each type-checked program is normalized using the repository's strong
  normalization theorem; and
- all W-tree traversals are structural.

The resulting natural number is therefore computable in principle, although
actual evaluation at contest input 42 is infeasible and should never be
attempted.

## 6. Audit expectations

The source intentionally contains none of:

- `noncomputable`, `partial`, `unsafe`, `opaque`, `extern`,
  `implemented_by`, `native_decide`, custom axioms, or `sorry`;
- a dependency on the closed constant `contender_24`; or
- an appeal to `Classical.choice`.

The expected axiom set is the repository's permitted set
`{propext, Quot.sound}`, inherited from the existing normalization and core
infrastructure.  The provided audit asks Lean to verify that expectation.

## 7. Proof-theoretic calibration

The following is heuristic.  Let `Φ(α)` denote the ordinal effect informally
attributed in the repository to one relativized Buchholz tower along an index
of type `α`, approximately `ψ₀(Ω_ω · α)`.  Then finite rounds resemble
iteration of `Φ`, and Contender 24 samples a finite iterate selected by the
input.  The omega-sum places all finite iterates in one index.  Applying
`limitAlong` another `seedHeight25 n + 1` times above that index should move
beyond the entire finite-iteration sequence and toward fixed-point behavior
for `Φ`; the height is itself an `F24` orbit value, not merely `family24 n`.

This calibration should not be mistaken for a theorem about the exact order
types of the Lean structures.  Establishing such a theorem is a major future
project.

## 8. Main risks

1. **Kernel replay risk.**  The source has not been replayed in Lean in the
   artifact-generation environment.  Minor elaboration adjustments may be
   needed.
2. **Budget risk.**  The declarations are small and reuse generic proofs, but
   only the supplied clean-build harness can establish the 15 s/60 s limits on
   the target machine.
3. **Calibration risk.**  The formal strict inequality is secure once the code
   compiles; the ordinal phase-transition description remains heuristic.
4. **Enumeration economy.**  `sigma` enumerates all early summands at every
   depth.  This is finite but may admit practical simplifications if future
   contenders are repeatedly layered over it.

## 9. Further research directions

- Prove order embeddings `roundTower k ↪ roundTower (k+1)` and replace the
  ordered sum by a coherent direct limit.
- Define transfinite iteration of `limitAlong` along an arbitrary `WFO`, rather
  than only natural recursion above `omegaRound`.
- Internalize a notation system for the least fixed point of
  `J ↦ limitAlong J`.
- Prove semantic translations of bounded System FL programs from every finite
  round into the omega-round language, preserving values.
- Develop exact upper and lower ordinal bounds for `towerAlong`, `limitAlong`,
  and `roundTower`.
- Compare the omega-round language with the autonomous W-tree universe
  proposal currently present in `incoming/`.
- Investigate whether the amplifier rank can itself be generated from the
  omega-round atom order without converting through the existing autonomous
  W-tree notation.
- Prove quantitative lower bounds that expose long explicit `F24` orbits below
  `F25`, analogous to earlier repository orbit theorems.
- Mechanize a generic “limit of contender languages” interface that packages
  syntax translation, normalization, enumeration, and reflection.
- Add a repository-level theorem distinguishing genuine language extensions
  from mere numerical wrappers under the no-laziness rule.
