## Current contender: Contender 25 (proposed)

```lean
def family24 (n : Nat) : Nat := F24 (F24 n)
def iterateF24 : Nat → Nat → Nat
  | 0, n => n
  | k + 1, n => F24 (iterateF24 k n)
def orbit24 : Family := fun i n => iterateF24 (i + 2) n
def seedHeight25 (n : Nat) : Nat := orbit24 (family24 n) n
def metaHeight25 (n : Nat) : Nat := seedHeight25 n + 1

def F25 (n : Nat) : Nat :=
  wDiagonalLift (schedule25 n) (rank25 n)
    oTransformer orbit24 n n

def contender_25 : Nat := F25 (F25 42)

theorem contender_24_lt_contender_25 : contender_24 < contender_25
```

The object language crosses the first explicit limit of the finite round
hierarchy.  `omegaRound` is the ordered sum of every `roundTower k`; input `n`
then uses `omegaRoundTower (seedHeight25 n + 1)`, continuing the
`limitAlong` operation an `F24`-orbit-sized number of times above that limit.  The amplifier
remains the certified W-tree-ranked diagonal lift, with an autonomous schedule
and rank placed above Contender 24's rank tree.

| Theorem | Statement |
|---|---|
| `Ordinal.omegaRoundTower_wf` | every post-omega atom order is well-founded |
| `orbit24_lt_F25` | every visible finite `F24` iterate is beaten |
| `family24_lt_F25` | Contender 24's family is beaten at every input |
| `ovalue_lt_F25` | every bounded post-omega ladder program is below `F25` |
| `contender_24_lt_contender_25` | exact comparison with Contender 24 |
| `long_F24_orbit_lt_contender_25` | closed predecessor-orbit lower bound |
