# Integration guide

## Validated target for source design

- Repository: `VladimirReshetnikov/BusyLean`
- Commit: `4fe4f5ed921a8e861d33008a368c6e6ff5b40446`
- Toolchain expected by the repository: Lean 4.34.0

## Overlay

From the BusyLean repository root, copy these package paths into the checkout:

```text
BusyLean/Ordinal/OmegaRound.lean
BusyLean/Contender25.lean
BusyLean/Comparison25.lean
test/Contender25Audit.lean
scripts/check_contender25.py
.github/workflows/contender25-check.yml
```

Then add the following imports to the end of `BusyLean.lean`:

```lean
import BusyLean.Ordinal.OmegaRound
import BusyLean.Contender25
import BusyLean.Comparison25
```

The ready-to-apply textual patch is `BusyLean.lean.patch`.

## Build and audit

```bash
python3 scripts/check_contender25.py
```

The harness performs:

1. a clean build of `BusyLean.Comparison24` as the precompiled predecessor;
2. a timed build of `BusyLean.Contender25` against the 15-second definition
   budget;
3. a timed build of `BusyLean.Comparison25` against the 60-second proof budget;
4. a Lean axiom audit; and
5. a closure audit ensuring that `contender_25` does not depend on any earlier
   closed contender constant.

## Expected repair surface

The proposal deliberately mirrors the elaboration patterns already accepted in
`Contender24.lean` and `Comparison24.lean`.  If Lean reports a definitional
unification problem, prefer a local `change` or a narrowly scoped `simpa only`
rather than broad unfolding.  Never simplify `family24 42`, `F24 42`, or
`F25 42`, because that can trigger attempted evaluation of a contender-sized
term.

## Suggested repository updates after validation

- Append the three imports to `BusyLean.lean`.
- Add a new “Current contender: Contender 25” section to `README.md`.
- Update `scripts/check.py` to use `Comparison24` as `PREVIOUS` and
  `Contender25` as `CURRENT_DEF`.
- Merge the new audit declarations into `test/Audit.lean` if a single audit
  file is preferred.
- Record actual definition/proof/full-build timings and the exact `#print
  axioms` output.
