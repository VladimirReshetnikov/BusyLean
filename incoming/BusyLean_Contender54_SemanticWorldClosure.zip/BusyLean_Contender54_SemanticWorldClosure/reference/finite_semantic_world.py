#!/usr/bin/env python3
"""Finite executable reference model for Contender 54's world operator.

The real Lean construction uses FT2, the ladder language, and stacked primitive
languages over well-founded trees.  This model replaces those languages by
small explicit lists of total Python functions.  It checks the update order,
four-channel tree step, finite-access limit join, feedback across stages, and
the comparison inequality used by the Lean proof.  It is not a substitute for
kernel elaboration or a model of the full language strength.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Callable, Iterable, Sequence


@dataclass(frozen=True)
class Tree:
    tag: str
    children: tuple["Tree", ...] = ()

    @staticmethod
    def zero() -> "Tree":
        return Tree("zero")

    @staticmethod
    def succ(child: "Tree") -> "Tree":
        return Tree("succ", (child,))

    @staticmethod
    def lim(children: Iterable["Tree"]) -> "Tree":
        return Tree("lim", tuple(children))


def node_at(tree: Tree, path: Sequence[int]) -> Tree:
    """Finite analogue of `FT2.nodeAt`; paths are innermost-index first."""
    current = tree
    for index in reversed(path):
        if current.tag == "succ":
            current = current.children[0]
        elif current.tag == "lim" and 0 <= index < len(current.children):
            current = current.children[index]
        else:
            return Tree.zero()
    return current


def truncated_size(tree: Tree, fuel: int) -> int:
    if fuel <= 0:
        return 1
    return 1 + sum(truncated_size(child, fuel - 1) for child in tree.children)


def truncated_height(tree: Tree, fuel: int) -> int:
    if fuel <= 0 or not tree.children:
        return 0
    return 1 + max(truncated_height(child, fuel - 1) for child in tree.children)


NatOracle = Callable[[int], int]
TreeProgram = Callable[[NatOracle, Tree], Tree]
NatProgram = Callable[[NatOracle, Tree, int], int]


def ft2_tree_programs() -> tuple[TreeProgram, ...]:
    return (
        lambda g, t: Tree.succ(t),
        lambda g, t: Tree.lim((t, Tree.succ(t))),
        lambda g, t: Tree.succ(Tree.succ(t)) if g(0) % 2 else Tree.succ(t),
    )


def ladder_tree_programs() -> tuple[TreeProgram, ...]:
    return (
        lambda g, t: Tree.lim((t, Tree.succ(t), Tree.succ(Tree.succ(t)))),
        lambda g, t: Tree.succ(t) if g(g(0) % 4) % 2 else Tree.lim((t, t)),
        lambda g, t: Tree.succ(Tree.lim((t, Tree.succ(t)))),
    )


def language_transformers() -> tuple[TreeProgram, ...]:
    """Finite proxy for programs over first-class iteration/closure operators."""
    return (
        lambda g, t: Tree.succ(Tree.succ(Tree.succ(t))),
        lambda g, t: Tree.lim((t, Tree.succ(t), Tree.lim((t, t)))),
        lambda g, t: Tree.succ(Tree.lim((Tree.succ(t), Tree.succ(Tree.succ(t))))),
    )


def ft2_nat_programs() -> tuple[NatProgram, ...]:
    return (
        lambda g, t, m: g(m),
        lambda g, t, m: truncated_size(t, min(m + 1, 5)),
        lambda g, t, m: truncated_height(t, min(m + 1, 5)),
    )


def ladder_nat_programs() -> tuple[NatProgram, ...]:
    return (
        lambda g, t, m: g(g(m)),
        lambda g, t, m: g(m) + truncated_size(t, min(m + 1, 4)),
        lambda g, t, m: g(truncated_height(t, min(m + 1, 4)) % (m + 1)),
    )


@dataclass(frozen=True)
class World:
    nat: NatOracle
    tree: Tree


def program_jump(programs: Sequence[TreeProgram], old_nat: NatOracle,
                 budget: int, old_tree: Tree) -> Tree:
    visible = programs[: min(budget + 1, len(programs))]
    return Tree.lim((old_tree, *(program(old_nat, old_tree) for program in visible)))


def language_stack(old_nat: NatOracle, budget: int, old_tree: Tree) -> Tree:
    visible = language_transformers()[: min(budget + 1, len(language_transformers()))]
    # Two finite levels mimic first-class reuse of the preceding closure.
    level_one = tuple(program(old_nat, old_tree) for program in visible)
    seed = Tree.lim((old_tree, *level_one))
    level_two = tuple(program(old_nat, seed) for program in visible)
    return Tree.lim((old_tree, seed, *level_two))


def tree_step(old_nat: NatOracle, budget: int, old_tree: Tree) -> Tree:
    ft2 = program_jump(ft2_tree_programs(), old_nat, budget, old_tree)
    ladder = program_jump(ladder_tree_programs(), old_nat, budget, old_tree)
    stacked = language_stack(old_nat, budget, old_tree)
    return Tree.lim((old_tree, ft2, ladder, stacked))


def ladder_reflect(old_nat: NatOracle, new_tree: Tree) -> NatOracle:
    ft2 = ft2_nat_programs()
    ladder = ladder_nat_programs()

    def reflected(m: int) -> int:
        visible_ft2 = ft2[: min(m + 1, len(ft2))]
        visible_ladder = ladder[: min(m + 1, len(ladder))]
        values = [old_nat(m)]
        values.extend(program(old_nat, new_tree, m) for program in visible_ft2)
        values.extend(program(old_nat, new_tree, m) for program in visible_ladder)
        return m + 1 + max(values)

    return reflected


def step(budget: int, world: World) -> World:
    new_tree = tree_step(world.nat, budget, world.tree)
    return World(ladder_reflect(world.nat, new_tree), new_tree)


def join(base: World, branches: Sequence[World]) -> World:
    def joined_nat(m: int) -> int:
        visible = branches[: m + 1]
        branch_max = max((branch.nat(m) for branch in visible), default=0)
        return max(base.nat(m), branch_max)

    return World(joined_nat, Tree.lim((base.tree, *(branch.tree for branch in branches))))


def close(budget: int, clock: Tree, world: World) -> World:
    if clock.tag == "zero":
        return world
    if clock.tag == "succ":
        return step(budget, close(budget, clock.children[0], world))
    if clock.tag == "lim":
        return join(world, tuple(close(budget, child, world) for child in clock.children))
    raise ValueError(f"unsupported clock node {clock.tag!r}")


def run_checks() -> dict[str, object]:
    seed_nat: NatOracle = lambda m: 2 * m + 3
    clock = Tree.lim(
        (
            Tree.succ(Tree.zero()),
            Tree.succ(Tree.succ(Tree.zero())),
            Tree.succ(Tree.lim((Tree.zero(), Tree.succ(Tree.zero())))),
        )
    )
    seed = World(seed_nat, clock)
    n = 2
    budget = seed_nat(n)

    one = step(budget, seed)
    core = close(budget, clock, seed)
    final = step(budget, core)
    sample_inputs = list(range(budget + 1))

    assert all(seed.nat(m) < one.nat(m) for m in sample_inputs)
    assert node_at(one.tree, [0]) == seed.tree
    assert node_at(one.tree, [1]) == program_jump(ft2_tree_programs(), seed.nat, budget, seed.tree)
    assert node_at(one.tree, [2]) == program_jump(ladder_tree_programs(), seed.nat, budget, seed.tree)
    assert node_at(one.tree, [3]) == language_stack(seed.nat, budget, seed.tree)
    assert all(seed.nat(m) <= core.nat(m) for m in sample_inputs)
    assert node_at(core.tree, [0]) == seed.tree
    assert all(core.nat(m) < final.nat(m) for m in sample_inputs)
    assert node_at(final.tree, [0]) == core.tree

    # Finite analogue of `family53 (family53 n) < world54(n).nat (family53 n)`.
    assert seed_nat(seed_nat(n)) <= core.nat(seed_nat(n))
    assert seed_nat(seed_nat(n)) < final.nat(budget)

    for m in sample_inputs:
        for program in ft2_nat_programs()[: min(m + 1, len(ft2_nat_programs()))]:
            assert program(core.nat, final.tree, m) < final.nat(m)
        for program in ladder_nat_programs()[: min(m + 1, len(ladder_nat_programs()))]:
            assert program(core.nat, final.tree, m) < final.nat(m)

    return {
        "model": "finite four-channel endogenous semantic-world recurrence",
        "seed_input": n,
        "budget": budget,
        "clock_truncated_size": truncated_size(clock, 10),
        "sample_inputs": sample_inputs,
        "seed_values": [seed.nat(m) for m in sample_inputs],
        "core_values": [core.nat(m) for m in sample_inputs],
        "final_values": [final.nat(m) for m in sample_inputs],
        "fourfold_proxy_margin": {
            "seed_seed_n": seed_nat(seed_nat(n)),
            "final_at_budget": final.nat(budget),
            "strict": seed_nat(seed_nat(n)) < final.nat(budget),
        },
        "checks": {
            "step_pointwise_strict": True,
            "four_tree_channels_retained": True,
            "close_preserves_seed_oracle": True,
            "limit_join_preserves_seed_tree": True,
            "final_step_pointwise_strict": True,
            "ft2_numeric_programs_dominated": True,
            "ladder_numeric_programs_dominated": True,
        },
        "scope_note": (
            "This model checks the recurrence laws on finite explicit total programs; "
            "the Lean overlay carries the actual FT2/FLT2/PTL definitions."
        ),
    }


def main() -> None:
    report = run_checks()
    out = Path(__file__).resolve().parents[1] / "validation" / "finite_model_report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
