# Integration guide

## Safe path

1. Create a detached worktree at commit
   `a0b88878a48e149e8c337ca050c891ccf93263bb`.
2. Run `python3 scripts/integrate.py WORKTREE` from the unpacked archive.
3. In the worktree, run `python3 scripts/check54.py`.
4. Inspect timing output, smoke tests, axiom reports, and the named-dependency
   audit.
5. Only after that replay, move the patch onto a development branch.

The integration script copies six Lean files, adds four umbrella imports, and
installs `scripts/check54.py`.  It is idempotent when files are unchanged and
refuses to overwrite differing files.

## Manual patch path

```bash
git apply /path/to/BusyLean_Contender54.patch
python3 scripts/check54.py
```

## Descendant checkouts

`--allow-descendant` permits a descendant of the pin, but this is intentionally
noisy.  A descendant may already use number 54 or may have changed the current
family, language interfaces, audit policy, or theorem names.  Review and
renumber before accepting such an integration.

## Expected budgets

The checker mirrors the repository policy:

- accepted predecessor build: reported, not charged;
- Contender 54 definition phase: at most 15 seconds;
- Contender 54 proof phase: at most 60 seconds;
- permitted axioms: `propext` and `Quot.sound` only.
