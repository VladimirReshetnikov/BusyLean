# Theorem map

| Declaration | Role |
|---|---|
| `SemanticWorld54.step_nat_strict` | Every coupled successor raises the numeric oracle pointwise. |
| `SemanticWorld54.ft2_jump_is_treeStep_branch_one` | The current-oracle FT2 jump is retained explicitly. |
| `SemanticWorld54.ladder_jump_is_treeStep_branch_two` | The current-oracle ladder jump is retained explicitly. |
| `SemanticWorld54.language_stack_is_treeStep_branch_three` | The stacked primitive-language closure is retained explicitly. |
| `SemanticWorld54.branch_le_join_nat` | At input `m`, every limit branch `i <= m` is retained. |
| `SemanticWorld54.le_close_nat` | Tree-indexed closure never lowers the seed oracle. |
| `SemanticWorld54.natValue_lt_step` | Every admitted FT2 numeric program over the enlarged tree is beaten. |
| `SemanticWorld54.readNat_lt_step` | Every admitted numeric ladder reader over the enlarged tree is beaten. |
| `family53_iter2_lt_world54_base` | Before the final hierarchy, the base beats two applications of `family53`. |
| `world54_base_le_F54` | The final hierarchy dominates its enlarged base. |
| `F53_fourfold_lt_F54` | Four nested `F53` applications are below one `F54`. |
| `final_ft2_program_lt_F54` | Final-stage FT2 programs below the semantic budget lie below `F54`. |
| `final_ladder_program_lt_F54` | Final-stage ladder readers below the semantic budget lie below `F54`. |
| `contender_53_lt_contender_54` | Required strict comparison with the accepted predecessor. |
| `F53_fourfold_42_lt_contender_54` | Concrete closed-number margin at seed `42`. |

## Dependency structure

```text
Contender53 / Comparison53
             |
             +-- SemanticWorld54 -----------+
             |                              |
             +-- SemanticWorld54Facts       |
                                            |
SemanticWorld54 ----------------------------+-- Contender54
                                                     |
                                                     +-- Comparison54
```

`test/Audit54.lean` traverses declaration types and bodies to check that
`contender_54` does not depend on the named closed constants `contender_53`
through `contender_49`.  Dependence on predecessor functions and language
infrastructure is intentional and permitted.
