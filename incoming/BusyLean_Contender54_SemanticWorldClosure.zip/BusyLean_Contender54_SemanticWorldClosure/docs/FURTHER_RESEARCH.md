# Further research questions

1. **Kernel replay and proof repair.** Replay the overlay under Lean 4.34.0,
   record exact timings, and minimize any elaboration-sensitive proof terms.
2. **World simulation preorder.** Define a relation combining pointwise numeric
   domination with explicit tree embeddings; prove `treeStep`, `step`, `join`,
   and `close` monotone.
3. **Internal successor-chain lower bounds.** Extract long successor chains from
   `stackTree` and convert them into explicit iteration counts for world steps,
   strengthening the conservative fourfold-`F53` margin.
4. **Symmetric two-phase feedback.** After reflection produces the new numeric
   oracle, run a second tree jump before returning the world; compare one-phase
   and symmetric feedback.
5. **First-class world language.** Design a strongly normalizing language with a
   type of complete semantic worlds and certified world transformers.
6. **Dynamic primitive environments.** Replace `primEnv51 N` by an environment
   whose seed and selected operators are derived from the current world.
7. **Limit fairness.** Study computable pairings exposing more than the first
   `m+1` branch worlds at input `m` while retaining simple totality proofs.
8. **Tree-branch embedding library.** Generalize the four branch facts into
   reusable path embeddings through arbitrary later world stages.
9. **Ordinal calibration.** Separate extensional tree height from intensional
   language strength and seek a notation system for alternating tree/number
   reflection.
10. **Repository-wide dependency linting.** Promote the custom closure audit to
    a standard BusyLean command for every contender.
