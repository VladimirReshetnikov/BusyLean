# Design review

## Rejected direction 1: another bounded semantic census

An early direction maximized values of a bounded total language.  BusyLean's
proposal review already treats a stratified semantic-Rayo mechanism as too
close to Contenders 6–14.  Re-ranking that language would not supply a new
architectural idea.

## Rejected direction 2: a first-order proof-carrying machine census

A proof-carrying register-machine census is constructive, but the repository
already has stronger higher-order, tree-reading, dynamically typed ladder, and
first-class closure languages.  A first-order census would mainly repackage a
weaker class of computations.

## Immediate predecessor

Contender 53 defines `reflAlong T g a`: the numerical reflection over one fixed
tree `T` is iterated along a tree `a`.  This is a substantial hyperreflection,
but the tree oracle itself remains externally selected and unchanged during the
iteration.

## Selected direction: endogenous two-sorted closure

The selected operator treats the *whole semantic environment* as state.  For a
world `w = (g,T)` and fixed budget `N`:

1. `treeStep N w` joins `T`, `FT2.jumpF g N T`, `FLT2.jumpL g N T`, and a
   `ptlStack` whose level index and argument are the current tree;
2. `step N w` sets the next numerical oracle to
   `ladderReflect g (treeStep N w)`;
3. the resulting pair becomes the input to the next stage;
4. a finite-access join combines worlds at limits;
5. structural recursion along `stackTree (family53 n)` performs the closure.

There is no circular definition inside one stage.  The order is

```text
old number/tree pair -> enlarged tree -> enlarged number oracle.
```

Mutual feedback appears between successive stages.  Totality comes from the
existing total interpreters and structural recursion on a well-founded tree.

## Relative novelty

- Contender 50 strengthens the numerical reader.
- Contender 51 makes iteration operators language primitives.
- Contender 52 stacks those languages.
- Contender 53 iterates numerical reflection along one fixed tree.
- Contender 54 iterates the pair `(number oracle, tree oracle)`: the current
  number oracle changes future tree jumps, and the changed tree changes future
  numerical reflection.

The novelty claim is relative to the pinned BusyLean snapshot, not a claim of
global priority.
