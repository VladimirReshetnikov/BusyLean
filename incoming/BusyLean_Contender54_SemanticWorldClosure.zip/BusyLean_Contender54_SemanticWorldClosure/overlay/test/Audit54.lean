import BusyLean.Comparison54
import Lean

/-! Focused axiom and named-dependency audit for Contender 54. -/

open Lean Elab Command

/-- Constants reachable through declaration types and values. -/
def constClosure54 (env : Environment) (root : Name) : NameSet := Id.run do
  let mut seen : NameSet := {}
  let mut stack := #[root]
  while stack.size > 0 do
    let c := stack.back!
    stack := stack.pop
    if seen.contains c then continue
    seen := seen.insert c
    let some ci := env.find? c | continue
    let body : Array Name := match ci with
      | .defnInfo v => v.value.getUsedConstants
      | .thmInfo v => v.value.getUsedConstants
      | .opaqueInfo v => v.value.getUsedConstants
      | _ => #[]
    stack := stack ++ ci.type.getUsedConstants ++ body
  return seen

elab "#assert54_not_in_closure " root:ident " : " bad:ident* : command => do
  let env ← getEnv
  let r ← liftCoreM <| realizeGlobalConstNoOverloadWithInfo root
  let cl := constClosure54 env r
  for b in bad do
    let n ← liftCoreM <| realizeGlobalConstNoOverloadWithInfo b
    if cl.contains n then throwError m!"{r} depends on forbidden constant {n}"
  logInfo m!"{r}: closure of {cl.size} constants avoids all {bad.size} forbidden names"

#print axioms BusyLean.SemanticWorld54.treeStep
#print axioms BusyLean.SemanticWorld54.step
#print axioms BusyLean.SemanticWorld54.close
#print axioms BusyLean.SemanticWorld54.le_close_nat
#print axioms BusyLean.SemanticWorld54.readNat_lt_step
#print axioms BusyLean.contender_54
#print axioms BusyLean.family53_iter2_lt_F54
#print axioms BusyLean.F53_fourfold_lt_F54
#print axioms BusyLean.final_ft2_program_lt_F54
#print axioms BusyLean.contender_53_lt_contender_54

-- The old family is an allowed seed; named old closed contenders are forbidden.
#assert54_not_in_closure BusyLean.contender_54 :
  BusyLean.contender_53 BusyLean.contender_52 BusyLean.contender_51
  BusyLean.contender_50 BusyLean.contender_49
