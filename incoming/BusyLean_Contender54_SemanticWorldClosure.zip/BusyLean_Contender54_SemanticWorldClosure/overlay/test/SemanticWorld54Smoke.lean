import BusyLean.Comparison54

open BusyLean

/-! Small elaboration smoke tests for Contender 54. -/

example (g : Nat → Nat) (T : BusyLean.Ordinal.CTree) (N m : Nat) :
    g m < (SemanticWorld54.step N ⟨g, T⟩).nat m :=
  SemanticWorld54.step_nat_strict N ⟨g, T⟩ m

example (g : Nat → Nat) (T : BusyLean.Ordinal.CTree) (N : Nat) :
    BusyLean.FT2.nodeAt (SemanticWorld54.step N ⟨g, T⟩).tree [0] = T :=
  SemanticWorld54.old_tree_is_step_branch_zero N ⟨g, T⟩

example : contender_53 < contender_54 := contender_53_lt_contender_54
example (n : Nat) : family53 (family53 n) < F54 n := family53_iter2_lt_F54 n
example (n : Nat) : F53 (F53 (F53 (F53 n))) < F54 n := F53_fourfold_lt_F54 n
example : F53 (F53 (F53 (F53 42))) < contender_54 :=
  F53_fourfold_42_lt_contender_54
