import BusyLean.Contender54
import BusyLean.SemanticWorld54Facts

/-! # Contender 54: comparison and margin theorems -/

namespace BusyLean

/-- Contender 53's doubled family is strictly inflationary. -/
theorem input_lt_family53 (n : Nat) : n < family53 n :=
  Nat.lt_trans (input_lt_F53 n) (input_lt_F53 (F53 n))

/-- The tree-indexed closure preserves the full seed number oracle. -/
theorem family53_le_coreWorld54 (n x : Nat) :
    family53 x ≤ (coreWorld54 n).nat x := by
  simpa [coreWorld54, seedWorld54] using
    (SemanticWorld54.le_close_nat (semanticBudget54 n)
      (semanticClock54 n) (seedWorld54 n) x)

/-- The seed clock remains branch zero of the closed world. -/
theorem semanticClock54_is_core_branch_zero (n : Nat) :
    FT2.nodeAt (coreWorld54 n).tree [0] = semanticClock54 n := by
  rfl

/-- The final semantic step is pointwise strict. -/
theorem coreWorld54_nat_lt_world54_nat (n x : Nat) :
    (coreWorld54 n).nat x < (world54 n).nat x := by
  simpa [world54] using
    (SemanticWorld54.step_nat_strict (semanticBudget54 n) (coreWorld54 n) x)

/-- The final number oracle is strictly inflationary at every input. -/
theorem input_lt_world54_nat (n x : Nat) : x < (world54 n).nat x := by
  have h1 : x < (coreWorld54 n).nat x :=
    Nat.lt_of_lt_of_le (input_lt_family53 x) (family53_le_coreWorld54 n x)
  exact Nat.lt_trans h1 (coreWorld54_nat_lt_world54_nat n x)

/-- Every admitted FT2 number program is beaten in the final world. -/
theorem ft2_program_lt_world54_nat (n : Nat) {m : Nat} {t : FT2.CTm}
    (ht : t ∈ FT2.ctmsUpTo m) :
    FT2.natValue ⟨(coreWorld54 n).nat, (world54 n).tree⟩ t <
      (world54 n).nat m := by
  simpa [world54] using
    (SemanticWorld54.natValue_lt_step
      (semanticBudget54 n) (coreWorld54 n) ht)

/-- Every admitted numeric ladder reader is beaten in the final world. -/
theorem ladder_program_lt_world54_nat (n : Nat) {m : Nat}
    {p : FLT2.CTm (Ordinal.Addr (SemanticWorld54.treeStep
      (semanticBudget54 n) (coreWorld54 n)))}
    (hp : p ∈ FLT2.ctmsUpTo (Ordinal.addrUpTo
      (SemanticWorld54.treeStep (semanticBudget54 n) (coreWorld54 n)) m) m) :
    FLT2.readNat (coreWorld54 n).nat
      (SemanticWorld54.treeStep (semanticBudget54 n) (coreWorld54 n)) m p <
      (world54 n).nat m := by
  simpa [world54] using
    (SemanticWorld54.readNat_lt_step
      (semanticBudget54 n) (coreWorld54 n) hp)

/-- The pre-final tree survives as branch zero of the final tree. -/
theorem core_tree_is_world54_branch_zero (n : Nat) :
    FT2.nodeAt (world54 n).tree [0] = (coreWorld54 n).tree := by
  simpa [world54] using
    (SemanticWorld54.old_tree_is_step_branch_zero
      (semanticBudget54 n) (coreWorld54 n))

/-- The final tree exposes the FT2 jump as branch one. -/
theorem final_ft2_jump_is_branch_one (n : Nat) :
    FT2.nodeAt (world54 n).tree [1] =
      FT2.jumpF (coreWorld54 n).nat (semanticBudget54 n) (coreWorld54 n).tree := by
  simpa [world54] using
    (SemanticWorld54.ft2_jump_is_treeStep_branch_one
      (semanticBudget54 n) (coreWorld54 n))

/-- The final tree exposes the ladder jump as branch two. -/
theorem final_ladder_jump_is_branch_two (n : Nat) :
    FT2.nodeAt (world54 n).tree [2] =
      FLT2.jumpL (coreWorld54 n).nat (semanticBudget54 n) (coreWorld54 n).tree := by
  simpa [world54] using
    (SemanticWorld54.ladder_jump_is_treeStep_branch_two
      (semanticBudget54 n) (coreWorld54 n))

/-- The final tree exposes stacked languages over the evolving tree as branch three. -/
theorem final_language_stack_is_branch_three (n : Nat) :
    FT2.nodeAt (world54 n).tree [3] =
      Ordinal.ptlStack prims51 (primEnv51 (semanticBudget54 n))
        (coreWorld54 n).tree (metaJump (semanticBudget54 n)) (coreWorld54 n).tree := by
  simpa [world54] using
    (SemanticWorld54.language_stack_is_treeStep_branch_three
      (semanticBudget54 n) (coreWorld54 n))

/-- Before the final hierarchy, the new base beats two applications of `family53`. -/
theorem family53_iter2_lt_world54_base (n : Nat) :
    family53 (family53 n) < (world54 n).nat (semanticBudget54 n) := by
  have h1 : family53 (family53 n) ≤
      (coreWorld54 n).nat (family53 n) :=
    family53_le_coreWorld54 n (family53 n)
  have h2 : (coreWorld54 n).nat (family53 n) <
      (world54 n).nat (family53 n) :=
    coreWorld54_nat_lt_world54_nat n (family53 n)
  simpa [semanticBudget54] using (Nat.lt_of_le_of_lt h1 h2)

/-- The final hierarchy dominates its enlarged base. -/
theorem world54_base_le_F54 (n : Nat) :
    (world54 n).nat (semanticBudget54 n) ≤ F54 n := by
  exact (Ordinal.le_hier
    (fun x => Nat.le_of_lt (input_lt_world54_nat n x))
    (world54 n).tree (semanticBudget54 n)).1

/-- The quantitative margin survives the final hierarchy. -/
theorem family53_iter2_lt_F54 (n : Nat) :
    family53 (family53 n) < F54 n :=
  Nat.lt_of_lt_of_le (family53_iter2_lt_world54_base n)
    (world54_base_le_F54 n)

/-- In unfolded notation, one `F54` beats four nested `F53` applications. -/
theorem F53_fourfold_lt_F54 (n : Nat) :
    F53 (F53 (F53 (F53 n))) < F54 n := by
  simpa [family53] using family53_iter2_lt_F54 n

/-- Every final-stage FT2 numeric program below the huge budget lies below `F54`. -/
theorem final_ft2_program_lt_F54 (n : Nat) {t : FT2.CTm}
    (ht : t ∈ FT2.ctmsUpTo (semanticBudget54 n)) :
    FT2.natValue ⟨(coreWorld54 n).nat, (world54 n).tree⟩ t < F54 n :=
  Nat.lt_of_lt_of_le (ft2_program_lt_world54_nat n ht)
    (world54_base_le_F54 n)

/-- Every final-stage numeric ladder reader below the huge budget lies below `F54`. -/
theorem final_ladder_program_lt_F54 (n : Nat)
    {p : FLT2.CTm (Ordinal.Addr (SemanticWorld54.treeStep
      (semanticBudget54 n) (coreWorld54 n)))}
    (hp : p ∈ FLT2.ctmsUpTo (Ordinal.addrUpTo
      (SemanticWorld54.treeStep (semanticBudget54 n) (coreWorld54 n))
      (semanticBudget54 n)) (semanticBudget54 n)) :
    FLT2.readNat (coreWorld54 n).nat
      (SemanticWorld54.treeStep (semanticBudget54 n) (coreWorld54 n))
      (semanticBudget54 n) p < F54 n :=
  Nat.lt_of_lt_of_le (ladder_program_lt_world54_nat n hp)
    (world54_base_le_F54 n)

/-- At every input, Contender 54 beats Contender 53's family. -/
theorem family53_lt_F54 (n : Nat) : family53 n < F54 n :=
  Nat.lt_trans (input_lt_family53 (family53 n)) (family53_iter2_lt_F54 n)

/-- `F54` is strictly inflationary. -/
theorem input_lt_F54 (n : Nat) : n < F54 n :=
  Nat.lt_trans (input_lt_family53 n) (family53_lt_F54 n)

/-- **Required comparison:** Contender 53 is strictly below Contender 54. -/
theorem contender_53_lt_contender_54 : contender_53 < contender_54 :=
  Nat.lt_trans (family53_lt_F54 42) (input_lt_F54 (F54 42))

/-- A concrete closed-number margin at the contest seed. -/
theorem F53_fourfold_42_lt_contender_54 :
    F53 (F53 (F53 (F53 42))) < contender_54 :=
  Nat.lt_trans (F53_fourfold_lt_F54 42) (input_lt_F54 (F54 42))

/-- The accepted comparison chain is preserved. -/
theorem contender_52_lt_contender_54 : contender_52 < contender_54 :=
  Nat.lt_trans contender_52_lt_contender_53 contender_53_lt_contender_54

end BusyLean
