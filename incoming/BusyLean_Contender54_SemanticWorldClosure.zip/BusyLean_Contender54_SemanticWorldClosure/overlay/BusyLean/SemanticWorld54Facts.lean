import BusyLean.SemanticWorld54
import BusyLean.Comparison53

/-! # Basic theorems for Contender 54's semantic worlds -/

namespace BusyLean.SemanticWorld54

/-- The numerical field is ladder reflection over the newly generated tree. -/
theorem step_nat_eq (N : Nat) (w : SemanticWorld54) :
    (step N w).nat = ladderReflect w.nat (treeStep N w) := by
  rfl

/-- The tree field is the four-channel tree update. -/
theorem step_tree_eq (N : Nat) (w : SemanticWorld54) :
    (step N w).tree = treeStep N w := by
  rfl

/-- Every world successor strictly raises the number oracle pointwise. -/
theorem step_nat_strict (N : Nat) (w : SemanticWorld54) (m : Nat) :
    w.nat m < (step N w).nat m := by
  exact Nat.lt_trans
    (oracle_lt_treeReflect w.nat (treeStep N w) m)
    (treeReflect_lt_ladderReflect w.nat (treeStep N w) m)

/-- The old tree is branch zero of the tree update. -/
theorem old_tree_is_treeStep_branch_zero (N : Nat) (w : SemanticWorld54) :
    FT2.nodeAt (treeStep N w) [0] = w.tree := by
  rfl

/-- The FT2 tree jump is branch one. -/
theorem ft2_jump_is_treeStep_branch_one (N : Nat) (w : SemanticWorld54) :
    FT2.nodeAt (treeStep N w) [1] = FT2.jumpF w.nat N w.tree := by
  rfl

/-- The ladder tree jump is branch two. -/
theorem ladder_jump_is_treeStep_branch_two (N : Nat) (w : SemanticWorld54) :
    FT2.nodeAt (treeStep N w) [2] = FLT2.jumpL w.nat N w.tree := by
  rfl

/-- The stacked language closure is branch three. -/
theorem language_stack_is_treeStep_branch_three (N : Nat) (w : SemanticWorld54) :
    FT2.nodeAt (treeStep N w) [3] =
      Ordinal.ptlStack prims51 (primEnv51 N) w.tree (metaJump N) w.tree := by
  rfl

/-- The old tree is therefore branch zero of a complete semantic step. -/
theorem old_tree_is_step_branch_zero (N : Nat) (w : SemanticWorld54) :
    FT2.nodeAt (step N w).tree [0] = w.tree := by
  rfl

/-- The base number oracle is retained by a limit join. -/
theorem base_le_join_nat (base : SemanticWorld54) (f : Nat → SemanticWorld54) (m : Nat) :
    base.nat m ≤ (join base f).nat m := by
  exact Nat.le_max_left _ _

/-- Every branch visible at input `m` is retained by the numerical join. -/
theorem branch_le_join_nat (base : SemanticWorld54) (f : Nat → SemanticWorld54)
    {i m : Nat} (hi : i ≤ m) : (f i).nat m ≤ (join base f).nat m := by
  exact Nat.le_trans (Ordinal.le_maxUpTo (fun j => (f j).nat m) hi)
    (Nat.le_max_right _ _)

/-- The base tree is branch zero of a limit join. -/
theorem base_tree_is_join_branch_zero (base : SemanticWorld54)
    (f : Nat → SemanticWorld54) :
    FT2.nodeAt (join base f).tree [0] = base.tree := by
  rfl

/-- Tree-indexed closure never lowers the seed number oracle. -/
theorem le_close_nat (N : Nat) :
    ∀ (a : Ordinal.CTree) (w : SemanticWorld54) (m : Nat),
      w.nat m ≤ (close N a w).nat m := by
  intro a
  induction a with
  | zero =>
      intro w m
      exact Nat.le_refl _
  | succ a ih =>
      intro w m
      exact Nat.le_trans (ih w m)
        (Nat.le_of_lt (step_nat_strict N (close N a w) m))
  | lim f ih =>
      intro w m
      exact base_le_join_nat w (fun i => close N (f i) w) m
  | supL _ _ =>
      intro w m
      exact Nat.le_refl _
  | supH _ _ =>
      intro w m
      exact Nat.le_refl _

/-- Every successor node in the clock performs a strict semantic update. -/
theorem close_succ_nat_strict (N : Nat) (a : Ordinal.CTree)
    (w : SemanticWorld54) (m : Nat) :
    (close N a w).nat m < (close N (.succ a) w).nat m := by
  exact step_nat_strict N (close N a w) m

/-- A limit node retains every branch whose index is visible at the input. -/
theorem close_limit_branch_le (N : Nat) (f : Nat → Ordinal.CTree)
    (w : SemanticWorld54) {i m : Nat} (hi : i ≤ m) :
    (close N (f i) w).nat m ≤ (close N (.lim f) w).nat m := by
  exact branch_le_join_nat w (fun j => close N (f j) w) hi

/-- Every admitted FT2 number program over the enlarged tree lies below a step. -/
theorem natValue_lt_step (N : Nat) (w : SemanticWorld54) {m : Nat} {t : FT2.CTm}
    (ht : t ∈ FT2.ctmsUpTo m) :
    FT2.natValue ⟨w.nat, (step N w).tree⟩ t < (step N w).nat m := by
  have h1 : FT2.natValue ⟨w.nat, treeStep N w⟩ t <
      treeReflect w.nat (treeStep N w) m :=
    natValue_lt_treeReflect w.nat (treeStep N w) ht
  have h2 : treeReflect w.nat (treeStep N w) m <
      ladderReflect w.nat (treeStep N w) m :=
    treeReflect_lt_ladderReflect w.nat (treeStep N w) m
  simpa [step] using Nat.lt_trans h1 h2

/-- Every admitted numeric ladder reader over the enlarged tree lies below a step. -/
theorem readNat_lt_step (N : Nat) (w : SemanticWorld54) {m : Nat}
    {p : FLT2.CTm (Ordinal.Addr (treeStep N w))}
    (hp : p ∈ FLT2.ctmsUpTo (Ordinal.addrUpTo (treeStep N w) m) m) :
    FLT2.readNat w.nat (treeStep N w) m p < (step N w).nat m := by
  simpa [step] using readNat_lt_ladderReflect w.nat (treeStep N w) hp

end BusyLean.SemanticWorld54
