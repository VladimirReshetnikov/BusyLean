import BusyLean.Contender53

/-!
# Endogenous semantic worlds beyond Contender 53

A `SemanticWorld54` is the complete pair of oracles seen by BusyLean's
strongly normalizing reader languages: a numerical oracle and a well-founded
tree.  The successor operator updates both fields and feeds the resulting pair
to the next stage.

The tree phase joins four channels:

1. the old tree itself;
2. the System-FT2 tree jump, evaluated with the current number oracle;
3. the ladder tree jump, also evaluated with the current number oracle;
4. Contender 52's stacked primitive-language closure, indexed by the current
   tree rather than by one externally fixed seed tree.

The number phase applies `ladderReflect` to the current number oracle and the
enlarged tree.  One stage is acyclic (tree first, number second), while
successive stages create genuine number/tree feedback.
-/

namespace BusyLean

/-- The evolving pair of numerical and tree oracles. -/
structure SemanticWorld54 where
  nat : Nat → Nat
  tree : Ordinal.CTree

namespace SemanticWorld54

/--
The tree half of one world update.  Branches `0`, `1`, `2`, and `3` retain the
old tree, the FT2 jump, the ladder jump, and the stacked primitive-language
closure respectively.
-/
def treeStep (N : Nat) (w : SemanticWorld54) : Ordinal.CTree :=
  .lim fun i =>
    if i = 0 then w.tree
    else if i = 1 then FT2.jumpF w.nat N w.tree
    else if i = 2 then FLT2.jumpL w.nat N w.tree
    else Ordinal.ptlStack prims51 (primEnv51 N) w.tree (metaJump N) w.tree

/-- One endogenous update: enlarge the tree, then reflect numbers over it. -/
def step (N : Nat) (w : SemanticWorld54) : SemanticWorld54 :=
  let T := treeStep N w
  { nat := ladderReflect w.nat T
    tree := T }

/--
A computable limit join.  At numerical input `m`, only branch worlds
`0, ..., m` are inspected; the tree component stores all branches lazily.
-/
def join (base : SemanticWorld54) (f : Nat → SemanticWorld54) : SemanticWorld54 where
  nat m := max (base.nat m) (Ordinal.maxUpTo (fun i => (f i).nat m) m)
  tree := .lim fun i => if i = 0 then base.tree else (f (i - 1)).tree

/-- Iterate endogenous world reflection by structural recursion on a tree. -/
def close (N : Nat) : Ordinal.CTree → SemanticWorld54 → SemanticWorld54
  | .zero => fun w => w
  | .succ a => fun w => step N (close N a w)
  | .lim f => fun w => join w (fun i => close N (f i) w)
  | .supL _ => fun w => w
  | .supH _ => fun w => w

end SemanticWorld54
end BusyLean
