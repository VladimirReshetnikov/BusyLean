#!/usr/bin/env python3
"""Integrate the Contender 54 overlay into a pinned BusyLean checkout."""
from __future__ import annotations

import argparse
import shutil
import subprocess
from pathlib import Path

PINNED = "a0b88878a48e149e8c337ca050c891ccf93263bb"
IMPORTS = [
    "import BusyLean.SemanticWorld54",
    "import BusyLean.SemanticWorld54Facts",
    "import BusyLean.Contender54",
    "import BusyLean.Comparison54",
]


def git(repo: Path, *args: str) -> str:
    proc = subprocess.run(
        ["git", *args], cwd=repo, capture_output=True, text=True, check=False
    )
    if proc.returncode != 0:
        raise SystemExit(proc.stderr.strip() or f"git {' '.join(args)} failed")
    return proc.stdout.strip()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", type=Path, help="path to a BusyLean checkout")
    parser.add_argument(
        "--allow-descendant",
        action="store_true",
        help="accept a descendant of the pin; numbering/conflicts still need manual review",
    )
    args = parser.parse_args()
    repo = args.repo.resolve()
    package = Path(__file__).resolve().parents[1]

    if not (repo / ".git").exists() or not (repo / "BusyLean.lean").exists():
        raise SystemExit(f"not a BusyLean git checkout: {repo}")
    head = git(repo, "rev-parse", "HEAD")
    if head != PINNED:
        if not args.allow_descendant:
            raise SystemExit(
                f"expected {PINNED}, found {head}; use a detached worktree at the pinned commit"
            )
        proc = subprocess.run(
            ["git", "merge-base", "--is-ancestor", PINNED, head], cwd=repo
        )
        if proc.returncode != 0:
            raise SystemExit(f"{head} is not a descendant of the pinned commit")
        print("WARNING: descendant integration; review contender numbering and conflicts.")

    for source in (package / "overlay" / "BusyLean").glob("*.lean"):
        target = repo / "BusyLean" / source.name
        if target.exists() and target.read_bytes() != source.read_bytes():
            raise SystemExit(f"refusing to overwrite different file: {target}")
        shutil.copy2(source, target)

    for source in (package / "overlay" / "test").glob("*.lean"):
        target = repo / "test" / source.name
        if target.exists() and target.read_bytes() != source.read_bytes():
            raise SystemExit(f"refusing to overwrite different file: {target}")
        shutil.copy2(source, target)

    shutil.copy2(package / "scripts" / "check54.py", repo / "scripts" / "check54.py")

    umbrella = repo / "BusyLean.lean"
    text = umbrella.read_text(encoding="utf-8").rstrip() + "\n"
    for line in IMPORTS:
        if line not in text:
            text += line + "\n"
    umbrella.write_text(text, encoding="utf-8")

    print(f"Integrated Contender 54 into {repo}")
    print("Next: python3 scripts/check54.py")


if __name__ == "__main__":
    main()
