#!/usr/bin/env python3
"""Static integrity checks for the Contender 54 overlay.

This is deliberately weaker than Lean kernel replay.  It catches placeholders,
unsafe escape hatches, malformed delimiter structure, missing declarations, and
direct dependence on the named previous closed contender in the definition
layer.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LEAN_DIR = ROOT / "overlay" / "BusyLean"
TEST_DIR = ROOT / "overlay" / "test"
REPORT = ROOT / "validation" / "static_audit_report.json"

EXPECTED_FILES = [
    LEAN_DIR / "SemanticWorld54.lean",
    LEAN_DIR / "SemanticWorld54Facts.lean",
    LEAN_DIR / "Contender54.lean",
    LEAN_DIR / "Comparison54.lean",
    TEST_DIR / "SemanticWorld54Smoke.lean",
    TEST_DIR / "Audit54.lean",
]

EXPECTED_DECLARATIONS = {
    "SemanticWorld54.lean": [
        "structure SemanticWorld54", "def treeStep", "def step", "def join", "def close"
    ],
    "SemanticWorld54Facts.lean": [
        "theorem step_nat_strict", "theorem le_close_nat",
        "theorem natValue_lt_step", "theorem readNat_lt_step",
    ],
    "Contender54.lean": ["def family53", "def world54", "def F54", "def contender_54"],
    "Comparison54.lean": [
        "theorem family53_iter2_lt_F54", "theorem F53_fourfold_lt_F54",
        "theorem final_ft2_program_lt_F54", "theorem final_ladder_program_lt_F54",
        "theorem contender_53_lt_contender_54",
    ],
}

FORBIDDEN_WORDS = (
    "sorry", "admit", "axiom", "unsafe", "partial", "noncomputable",
    "extern", "implemented_by",
)


def strip_comments(text: str) -> str:
    out: list[str] = []
    i = 0
    depth = 0
    in_string = False
    while i < len(text):
        if depth:
            if text.startswith("/-", i):
                depth += 1
                i += 2
            elif text.startswith("-/", i):
                depth -= 1
                i += 2
            else:
                i += 1
            continue
        if not in_string and text.startswith("/-", i):
            depth = 1
            i += 2
            continue
        if not in_string and text.startswith("--", i):
            j = text.find("\n", i)
            if j < 0:
                break
            out.append("\n")
            i = j + 1
            continue
        ch = text[i]
        out.append(ch)
        if ch == '"' and (i == 0 or text[i - 1] != "\\"):
            in_string = not in_string
        i += 1
    return "".join(out)


def balanced(text: str) -> tuple[bool, str]:
    pairs = {")": "(", "]": "[", "}": "{"}
    stack: list[tuple[str, int]] = []
    in_string = False
    escaped = False
    for idx, ch in enumerate(text):
        if in_string:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
            continue
        if ch == '"':
            in_string = True
        elif ch in "([{":
            stack.append((ch, idx))
        elif ch in ")]}" :
            if not stack or stack[-1][0] != pairs[ch]:
                return False, f"unmatched {ch!r} at byte {idx}"
            stack.pop()
    if stack:
        ch, idx = stack[-1]
        return False, f"unclosed {ch!r} from byte {idx}"
    if in_string:
        return False, "unclosed string literal"
    return True, "ok"


def main() -> int:
    failures: list[str] = []
    details: dict[str, object] = {}

    for path in EXPECTED_FILES:
        if not path.is_file():
            failures.append(f"missing file: {path.relative_to(ROOT)}")
            continue
        raw = path.read_text(encoding="utf-8")
        code = strip_comments(raw)
        ok, note = balanced(code)
        file_info: dict[str, object] = {
            "bytes": len(raw.encode("utf-8")),
            "lines": raw.count("\n") + 1,
            "balanced_delimiters": ok,
            "balance_note": note,
        }
        if not ok:
            failures.append(f"{path.name}: {note}")

        found_forbidden = [
            token for token in FORBIDDEN_WORDS
            if re.search(rf"\b{re.escape(token)}\b", code)
        ]
        file_info["forbidden_tokens"] = found_forbidden
        if found_forbidden:
            failures.append(f"{path.name}: forbidden tokens {found_forbidden}")

        expected = EXPECTED_DECLARATIONS.get(path.name, [])
        missing = [decl for decl in expected if decl not in code]
        file_info["missing_expected_declarations"] = missing
        if missing:
            failures.append(f"{path.name}: missing declarations {missing}")

        details[str(path.relative_to(ROOT))] = file_info

    definition_text = "\n".join(
        strip_comments((LEAN_DIR / name).read_text(encoding="utf-8"))
        for name in ("SemanticWorld54.lean", "Contender54.lean")
    )
    direct_named_previous = bool(re.search(r"\bcontender_53\b", definition_text))
    if direct_named_previous:
        failures.append("definition layer directly names contender_53")

    comparison_text = strip_comments((LEAN_DIR / "Comparison54.lean").read_text(encoding="utf-8"))
    has_required_comparison = "contender_53_lt_contender_54" in comparison_text
    if not has_required_comparison:
        failures.append("required comparison theorem is absent")

    report = {
        "status": "PASS" if not failures else "FAIL",
        "scope": "static source integrity; not Lean kernel validation",
        "definition_layer_avoids_named_contender_53": not direct_named_previous,
        "required_comparison_present": has_required_comparison,
        "files": details,
        "failures": failures,
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if not failures else 1


if __name__ == "__main__":
    sys.exit(main())
