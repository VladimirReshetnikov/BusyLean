#!/usr/bin/env python3
"""Kernel-build and audit Contender 54 after the overlay is integrated.

Run from a BusyLean checkout pinned to the commit listed in PINNED_BASELINE.md:

    python3 scripts/check54.py

The script mirrors BusyLean's 15-second definition / 60-second proof budgets.
"""
from __future__ import annotations

import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BUILD_DIRS = [
    ROOT / ".lake" / "build",
    ROOT / "proposals" / "P5-w-reflection" / "lean" / ".lake" / "build",
]
PERMITTED = {"propext", "Quot.sound"}
PREVIOUS = "BusyLean.Comparison53"
CURRENT_DEF = "BusyLean.Contender54"
CURRENT_PROOF = "BusyLean.Comparison54"
DEFINITION_BUDGET = 15.0
PROOF_BUDGET = 60.0
LAKE = shutil.which("lake") or "lake"


def run_lake(args: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run([LAKE, *args], cwd=ROOT, capture_output=True, text=True)


def timed_build(label: str, target: list[str], budget: float | None) -> float:
    start = time.monotonic()
    build = run_lake(["build", *target])
    elapsed = time.monotonic() - start
    if build.returncode != 0:
        print(build.stdout)
        print(build.stderr, file=sys.stderr)
        raise SystemExit(f"FAIL: {label} build failed")
    note = f"budget {budget:.0f} s" if budget is not None else "accepted baseline"
    print(f"{label}: {elapsed:.2f} s ({note})")
    if budget is not None and elapsed > budget:
        raise SystemExit(f"FAIL: {label} exceeded {budget:.0f} s")
    return elapsed


def run_lean(path: str) -> str:
    proc = run_lake(["env", "lean", path])
    output = proc.stdout + proc.stderr
    print(output)
    if proc.returncode != 0:
        raise SystemExit(f"FAIL: Lean check failed for {path}")
    return output


def main() -> None:
    for directory in BUILD_DIRS:
        shutil.rmtree(directory, ignore_errors=True)

    total = timed_build("previous contender", [PREVIOUS], None)
    total += timed_build("Contender 54 definitions", [CURRENT_DEF], DEFINITION_BUDGET)
    total += timed_build("Contender 54 proofs", [CURRENT_PROOF], PROOF_BUDGET)
    print(f"total clean build: {total:.2f} s")

    run_lean("test/SemanticWorld54Smoke.lean")
    audit = run_lean("test/Audit54.lean")
    reports = re.findall(
        r"'([^']+)' (?:depends on axioms: \[([^\]]*)\]|does not depend)", audit
    )
    bad = [
        (name, axioms)
        for name, axioms in reports
        if axioms and set(a.strip() for a in axioms.split(",")) - PERMITTED
    ]
    if not reports:
        raise SystemExit("FAIL: no #print axioms reports were recognized")
    if bad:
        raise SystemExit(f"FAIL: forbidden axioms: {bad}")
    print(f"PASS: {len(reports)} declarations audited; permitted axioms {sorted(PERMITTED)}")


if __name__ == "__main__":
    main()
