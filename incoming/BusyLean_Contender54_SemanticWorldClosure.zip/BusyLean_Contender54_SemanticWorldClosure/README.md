# BusyLean Contender 54: endogenous semantic-world closure

This research package proposes **Contender 54** against BusyLean commit
`a0b88878a48e149e8c337ca050c891ccf93263bb`, whose accepted latest entry is
Contender 53 (“reflection iterated along the tree”).

## Central construction

The new state is not only a number function or only a tree:

```lean
structure SemanticWorld54 where
  nat  : Nat → Nat
  tree : Ordinal.CTree
```

For a fixed finite program budget `N`, one successor first builds a four-channel
tree containing:

1. the old tree;
2. `FT2.jumpF` evaluated with the current number oracle;
3. `FLT2.jumpL` evaluated with the current number oracle;
4. `ptlStack` indexed by the current tree.

It then sets the next number oracle to `ladderReflect` over that enlarged tree.
The complete pair is fed to the next successor.  Limits use finite numerical
maxima and a lazy countable tree join.  This paired update is iterated by
structural recursion along a Contender-53-sized clock.

```lean
def family53 (n : Nat) : Nat := F53 (F53 n)
def contender_54 : Nat := F54 (F54 42)
```

The conservative formal margin encoded by the overlay is

```text
F53 (F53 (F53 (F53 n))) < F54 n
contender_53 < contender_54
```

The mechanism is stronger than the margin used to compare the closed terms:
the overlay also gives explicit branch witnesses and bounds every admitted FT2
numeric program and every admitted numeric ladder reader at the final stage.

## Why this is not merely another outer wrapper

Contender 53 iterates **numerical reflection** along one fixed tree.  Contender
54 iterates the entire semantic environment.  The current number oracle changes
the next FT2 and ladder tree jumps; the changed tree then changes the next
number oracle.  The predecessor's function `F53` is used only to seed and budget
this new dynamical system; the definition does not depend on the named closed
constant `contender_53`.

## Contents

- `article/contender54_semantic_world.tex` and `.pdf` — research article.
- `overlay/BusyLean/` — definition and comparison modules.
- `overlay/test/` — elaboration smoke tests and axiom/dependency audit.
- `BusyLean_Contender54.patch` — patch against the pinned commit.
- `scripts/integrate.py` — pin-aware overlay installer.
- `scripts/check54.py` — clean build, timing, smoke, and axiom replay.
- `scripts/static_audit.py` — source-integrity checks only.
- `reference/finite_semantic_world.py` — executable finite recurrence model.
- `docs/` — design review, theorem map, integration instructions, limitations,
  and further research questions.
- `validation/` — generated reports and PDF quality checks.

## Reproduction

Package-local checks:

```bash
python3 scripts/static_audit.py
python3 reference/finite_semantic_world.py
```

Kernel replay in a pinned BusyLean worktree:

```bash
git -C /path/to/BusyLean worktree add /tmp/busylean-c54 \
  a0b88878a48e149e8c337ca050c891ccf93263bb
python3 scripts/integrate.py /tmp/busylean-c54
cd /tmp/busylean-c54
python3 scripts/check54.py
```

## Validation status

Static source checks, the finite reference model, LaTeX compilation, PDF
preflight, text extraction, and visual rendering checks are completed in this
package.  The preparation environment did not contain Lean 4.34.0 or Lake, so
the new modules are **not represented as kernel-replayed**.  The exact replay
script is included and enforces the repository's definition/proof time budgets,
smoke tests, permitted-axiom policy, and named-predecessor dependency audit.
