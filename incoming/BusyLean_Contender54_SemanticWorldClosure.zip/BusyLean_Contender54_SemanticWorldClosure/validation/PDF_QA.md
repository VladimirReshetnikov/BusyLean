# PDF quality assurance

- File: `article/contender54_semantic_world.pdf`
- Pages: 25, US Letter, unencrypted, text-based.
- Compilation: `latexmk -pdf`, multi-pass, no fatal LaTeX errors.
- Preflight: openable by PyMuPDF; not likely scanned; no XFA.
- Text extraction: 25 form-feed page breaks; zero U+FFFD replacement characters.
- Warning review: no overfull or underfull box warnings found in the captured build log.
- Visual inspection at 160 dpi:
  - page 1: title, abstract, displayed definitions, and footer are clean;
  - page 2: table of contents is aligned and unclipped;
  - page 9: Lean listing and comparison equations are readable;
  - pages 12-13: architecture/model/validation tables fit within margins;
  - page 15: full-page Lean source listing is legible and unclipped;
  - page 25: reproduction commands and bibliography are complete.

Result: **PASS**.
