#!/usr/bin/env python3
"""Static validation for the BusyLean Contender 35 proposal.

This script deliberately distinguishes static artifact checks from Lean kernel
replay.  It validates the overlay, screens executable source for forbidden
constructs, checks the integration patch against the recorded baseline
contexts, and records cryptographic hashes.  If a BusyLean checkout is passed
with --repo and Lake is available, it can additionally run the authoritative
repository checker after integration.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

TARGET_COMMIT = "43513401d8929d60b2e3e40a4a20835a1271e94f"
REQUIRED_FILES = [
    "README.md",
    "MANIFEST.md",
    "THEOREM_MAP.md",
    "VALIDATION.md",
    "RESEARCH_NOTES.md",
    "metadata/target.json",
    "article/contender35.tex",
    "article/contender35.pdf",
    "validation/pdf-visual-inspection.md",
    "validation/environment.txt",
    "BusyLean/Contender35.lean",
    "BusyLean/Comparison35.lean",
    "test/Contender35Audit.lean",
    "patches/contender35.patch",
    "overlay/BusyLean.lean",
    "overlay/BusyLean/Contender35.lean",
    "overlay/BusyLean/Comparison35.lean",
    "overlay/scripts/check.py",
    "overlay/test/Contender35Audit.lean",
    "scripts/integrate.sh",
    "scripts/replay.sh",
    "scripts/check_submission.sh",
]
REQUIRED_DECLS = {
    "BusyLean/Contender35.lean": [
        "def iterateF34", "def family34", "def treeIndex35", "def seed35",
        "def reflectTSFamilyAt", "def indexedTSTransformer",
        "def schedule35", "def rank35", "def F35", "def contender_35",
    ],
    "BusyLean/Comparison35.lean": [
        "theorem iterateF34_step_lt", "theorem input_lt_iterateF34_succ",
        "theorem family34_lt_treeIndex35", "theorem treeIndex35_lt_seed35",
        "theorem seed35_lt_F35", "theorem treeIndex35_lt_F35",
        "theorem family34_lt_F35", "theorem tsvalue_lt_F35",
        "theorem long_F34_orbit_lt_contender_35",
        "theorem contender_34_lt_contender_35",
    ],
}
FORBIDDEN = [
    r"\bsorry\b", r"\badmit\b", r"\baxiom\b", r"\bnoncomputable\b",
    r"\bpartial\b", r"\bunsafe\b", r"\bopaque\b", r"\bnative_decide\b",
    r"#eval\b",
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def strip_lean_comments_and_strings(text: str) -> str:
    """Remove nested block comments, line comments, and string contents."""
    out: list[str] = []
    i = 0
    depth = 0
    in_string = False
    while i < len(text):
        if depth:
            if text.startswith("/-", i):
                depth += 1
                i += 2
            elif text.startswith("-/", i):
                depth -= 1
                i += 2
            else:
                if text[i] == "\n":
                    out.append("\n")
                i += 1
            continue
        if in_string:
            if text[i] == "\\":
                i += 2
            elif text[i] == '"':
                in_string = False
                out.append('"')
                i += 1
            else:
                if text[i] == "\n":
                    out.append("\n")
                i += 1
            continue
        if text.startswith("/-", i):
            depth = 1
            i += 2
        elif text.startswith("--", i):
            j = text.find("\n", i)
            if j < 0:
                break
            out.append("\n")
            i = j + 1
        elif text[i] == '"':
            in_string = True
            out.append('"')
            i += 1
        else:
            out.append(text[i])
            i += 1
    if depth:
        raise ValueError("unterminated Lean block comment")
    if in_string:
        raise ValueError("unterminated Lean string")
    return "".join(out)


def check_delimiters(text: str, label: str) -> None:
    stripped = strip_lean_comments_and_strings(text)
    pairs = {")": "(", "]": "[", "}": "{"}
    stack: list[tuple[str, int]] = []
    for pos, ch in enumerate(stripped):
        if ch in "([{":
            stack.append((ch, pos))
        elif ch in pairs:
            if not stack or stack[-1][0] != pairs[ch]:
                raise ValueError(f"{label}: unmatched {ch!r} at byte {pos}")
            stack.pop()
    if stack:
        ch, pos = stack[-1]
        raise ValueError(f"{label}: unmatched {ch!r} at byte {pos}")


def run(cmd: list[str], cwd: Path | None = None, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, cwd=cwd, text=True, capture_output=True, check=check)


def patch_preflight(root: Path) -> str:
    with tempfile.TemporaryDirectory(prefix="c35-preflight-") as td:
        repo = Path(td)
        (repo / "scripts").mkdir(parents=True)
        shutil.copy2(root / "validation/baseline/BusyLean.lean", repo / "BusyLean.lean")
        shutil.copy2(root / "validation/baseline/scripts/check.py", repo / "scripts/check.py")
        patch = str(root / "patches/contender35.patch")
        run(["git", "apply", "--check", patch], cwd=repo)
        run(["git", "apply", patch], cwd=repo)
        for rel in [
            "BusyLean.lean",
            "BusyLean/Contender35.lean",
            "BusyLean/Comparison35.lean",
            "scripts/check.py",
            "test/Contender35Audit.lean",
        ]:
            expected = root / "overlay" / rel
            actual = repo / rel
            if not actual.is_file() or actual.read_bytes() != expected.read_bytes():
                raise ValueError(f"applied patch differs from overlay: {rel}")
        return "git apply --check, apply, and overlay comparison: success"


def optional_kernel_replay(repo: Path) -> dict[str, object]:
    lake = shutil.which("lake")
    if lake is None:
        return {"attempted": False, "reason": "lake is not installed"}
    cp = run([sys.executable, "scripts/check.py"], cwd=repo, check=False)
    return {
        "attempted": True,
        "returncode": cp.returncode,
        "stdout": cp.stdout,
        "stderr": cp.stderr,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--repo", type=Path, help="optional already-integrated BusyLean checkout")
    parser.add_argument("--json", type=Path, help="write a machine-readable report")
    args = parser.parse_args()
    root = args.root.resolve()
    errors: list[str] = []
    notes: list[str] = []

    for rel in REQUIRED_FILES:
        if not (root / rel).is_file():
            errors.append(f"missing required file: {rel}")

    for rel, decls in REQUIRED_DECLS.items():
        path = root / rel
        if not path.is_file():
            continue
        text = path.read_text(encoding="utf-8")
        try:
            check_delimiters(text, rel)
        except ValueError as exc:
            errors.append(str(exc))
        executable = strip_lean_comments_and_strings(text)
        for pat in FORBIDDEN:
            if re.search(pat, executable):
                errors.append(f"{rel}: forbidden executable token matching {pat}")
        for decl in decls:
            if decl not in text:
                errors.append(f"{rel}: required declaration missing: {decl}")

    definition_text = strip_lean_comments_and_strings(
        (root / "BusyLean/Contender35.lean").read_text(encoding="utf-8")
    )
    if re.search(r"\bcontender_(?:[5-9]|[12][0-9]|3[0-4])\b", definition_text):
        errors.append("definition module directly mentions a prior closed contender constant")
    if "def contender_35 : Nat := F35 (F35 42)" not in definition_text:
        errors.append("exact final equation for contender_35 not found")
    if "def family34 (n : Nat) : Nat := F34 (F34 n)" not in definition_text:
        errors.append("exact predecessor-family equation not found")

    for rel in ["BusyLean/Contender35.lean", "BusyLean/Comparison35.lean", "test/Contender35Audit.lean"]:
        source = root / rel
        overlay = root / "overlay" / rel
        if source.is_file() and overlay.is_file() and source.read_bytes() != overlay.read_bytes():
            errors.append(f"overlay copy differs from canonical source: {rel}")

    try:
        notes.append(patch_preflight(root))
    except Exception as exc:
        errors.append(f"patch preflight failed: {exc}")

    py_files = [root / "validation/validate_overlay.py"]
    for path in py_files:
        cp = run([sys.executable, "-m", "py_compile", str(path)], check=False)
        if cp.returncode:
            errors.append(f"Python compile failed for {path.name}: {cp.stderr.strip()}")

    excluded_hashes = {
        "SHA256SUMS",
        "validation/static-validation.json",
        "validation/static-validation.log",
    }
    hashes = {
        rel: sha256(path)
        for path in sorted(root.rglob("*"))
        if path.is_file()
        and ".git" not in path.parts
        and "__pycache__" not in path.parts
        and (rel := str(path.relative_to(root))) not in excluded_hashes
        and not rel.endswith(".pyc")
    }
    replay: dict[str, object] = {"attempted": False, "reason": "no --repo supplied"}
    if args.repo:
        replay = optional_kernel_replay(args.repo.resolve())
        if replay.get("attempted") and replay.get("returncode") != 0:
            errors.append("optional Lean kernel replay failed")

    report = {
        "target_repository": "VladimirReshetnikov/BusyLean",
        "target_commit": TARGET_COMMIT,
        "status": "PASS" if not errors else "FAIL",
        "static_checks": {
            "required_files": len(REQUIRED_FILES),
            "forbidden_token_screen": "pass" if not any("forbidden" in e for e in errors) else "fail",
            "delimiter_scan": "pass" if not any("unmatched" in e or "unterminated" in e for e in errors) else "fail",
            "patch_preflight": notes,
        },
        "kernel_replay": replay,
        "errors": errors,
        "sha256": hashes,
    }
    rendered = json.dumps(report, indent=2, sort_keys=True)
    print(rendered)
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(rendered + "\n", encoding="utf-8")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
