import BusyLean
import Lean

/-!
# Contender 35 audit

Run with:

```
lake env lean test/Contender35Audit.lean
```

The file prints the axiom dependencies of the new principal declarations,
checks their exact theorem types, and verifies that the closed definition uses
Contender 34's construction family but none of the earlier closed contender
constants.
-/

open Lean Elab Command

/-- All constants reachable from `root` through declaration types and values. -/
def contender35ConstClosure (env : Environment) (root : Name) : NameSet := Id.run do
  let mut seen : NameSet := {}
  let mut stack := #[root]
  while stack.size > 0 do
    let c := stack.back!
    stack := stack.pop
    if seen.contains c then continue
    seen := seen.insert c
    let some ci := env.find? c | continue
    let body : Array Name := match ci with
      | .defnInfo v => v.value.getUsedConstants
      | .thmInfo v => v.value.getUsedConstants
      | .opaqueInfo v => v.value.getUsedConstants
      | _ => #[]
    stack := stack ++ ci.type.getUsedConstants ++ body
  return seen

/-- Fail if any listed constant is in the closure of the first one. -/
elab "#assert_not_in_closure35 " root:ident " : " bad:ident* : command => do
  let env ← getEnv
  let r ← liftCoreM <| realizeGlobalConstNoOverloadWithInfo root
  let cl := contender35ConstClosure env r
  for b in bad do
    let n ← liftCoreM <| realizeGlobalConstNoOverloadWithInfo b
    if cl.contains n then throwError m!"{r} depends on forbidden constant {n}"
  logInfo m!"{r}: closure of {cl.size} constants avoids all {bad.size} forbidden names"

#print axioms BusyLean.contender_35
#print axioms BusyLean.contender_34_lt_contender_35
#print axioms BusyLean.family34_lt_F35
#print axioms BusyLean.treeIndex35_lt_F35
#print axioms BusyLean.tsvalue_lt_F35
#print axioms BusyLean.long_F34_orbit_lt_contender_35
#print axioms BusyLean.iterateF34_step_lt
#print axioms BusyLean.input_lt_iterateF34_succ

#assert_not_in_closure35 BusyLean.contender_35 :
  BusyLean.contender_34 BusyLean.contender_33 BusyLean.contender_32
  BusyLean.contender_31 BusyLean.contender_30 BusyLean.contender_29
  BusyLean.contender_28 BusyLean.contender_27 BusyLean.contender_26
  BusyLean.contender_25 BusyLean.contender_24 BusyLean.contender_23
  BusyLean.contender_22 BusyLean.contender_21 BusyLean.contender_20
  BusyLean.contender_19 BusyLean.contender_18 BusyLean.contender_17
  BusyLean.contender_16 BusyLean.contender_15 BusyLean.contender_14
  BusyLean.contender_13 BusyLean.contender_12 BusyLean.contender_11
  BusyLean.contender_10 BusyLean.contender_9 BusyLean.contender_8
  BusyLean.contender_7 BusyLean.contender_6 BusyLean.contender_5

#check @BusyLean.contender_34_lt_contender_35
#check @BusyLean.family34_lt_treeIndex35
#check @BusyLean.treeIndex35_lt_seed35
#check @BusyLean.seed35_lt_F35
#check @BusyLean.treeIndex35_lt_F35
#check @BusyLean.family34_lt_F35
#check @BusyLean.tsvalue_lt_F35
#check @BusyLean.long_F34_orbit_lt_contender_35
