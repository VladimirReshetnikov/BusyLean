# BusyLean Contender 35 proposal

## Self-indexed transfinite-language hyperreflection

This archive proposes a new constructive natural number for
[`VladimirReshetnikov/BusyLean`](https://github.com/VladimirReshetnikov/BusyLean),
targeting repository commit
`43513401d8929d60b2e3e40a4a20835a1271e94f` and Lean toolchain
`leanprover/lean4:v4.34.0`.

The target repository's current endpoint is Contender 34. The proposal defines

```lean
def iterateF34 : Nat → Nat → Nat
  | 0, x => x
  | k + 1, x => F34 (iterateF34 k x)

def family34 (n : Nat) : Nat := F34 (F34 n)

def treeIndex35 (n : Nat) : Nat :=
  iterateF34 (family34 n + 1) (family34 n)

def seed35 (i n : Nat) : Nat :=
  iterateF34 (i + 2) (treeIndex35 n)

def F35 (n : Nat) : Nat :=
  wDiagonalLift (schedule35 n) (rank35 n)
    (indexedTSTransformer treeIndex35) seed35 n n

def contender_35 : Nat := F35 (F35 42)
```

At input `n`, the reflected object language is no longer built over
`treeStackedTree n`. It is built over
`treeStackedTree (treeIndex35 n)`, where `treeIndex35 n` is reached by an
`F34` orbit whose length is itself greater than the Contender 34 family value.
The visible seed is a continuation of that same orbit. The schedule and W-rank
are rebuilt above a far-out seed coordinate.

## Principal formal claims

The proposed comparison module is organized to prove, without any monotonicity
assumption on `F34` or on oracle-sensitive program evaluation,

```text
family34 n < treeIndex35 n < seed35 0 n < F35 n
```

and therefore

```lean
theorem contender_34_lt_contender_35 :
    contender_34 < contender_35
```

A stronger closed lower bound is also supplied:

```lean
theorem long_F34_orbit_lt_contender_35 :
    iterateF34 (F35 42 + 2) (treeIndex35 (F35 42)) < contender_35
```

Thus the intended formal margin is not merely one successor step: an explicit
`F34` orbit of length `F35 42 + 2` lies below the proposed closed number.

## Archive map

- `article/contender35.tex` - comprehensive research article source.
- `article/contender35.pdf` - compiled 15-page article.
- `BusyLean/Contender35.lean` - executable definitions.
- `BusyLean/Comparison35.lean` - comparison and domination theorems.
- `test/Contender35Audit.lean` - axiom, theorem-type, and dependency-closure audit.
- `patches/contender35.patch` - integration patch for the exact target commit.
- `overlay/` - ready-to-copy repository overlay.
- `scripts/integrate.sh` - guarded patch application.
- `scripts/replay.sh` - authoritative post-integration replay.
- `validation/validate_overlay.py` - static validation and patch preflight.
- `THEOREM_MAP.md` - mathematical claim to Lean declaration map.
- `VALIDATION.md` - exact completed and outstanding validation status.
- `RESEARCH_NOTES.md` - design rationale, rejected alternatives, and next steps.
- `metadata/target.json` - machine-readable target and proposal metadata.
- `SHA256SUMS` - checksums for distributed files.

## Integration

From the unpacked archive:

```bash
./scripts/integrate.sh /path/to/BusyLean
```

The script requires a clean checkout at the exact target commit. After applying
the patch, run the repository's authoritative checks:

```bash
cd /path/to/BusyLean
python3 scripts/check.py
lake env lean test/Contender35Audit.lean
```

The wrapper below runs the same sequence:

```bash
/path/to/archive/scripts/replay.sh /path/to/BusyLean
```

## Validation status

The archive passed static source screening, exact-equation checks, overlay
consistency checks, Python and shell syntax checks, and a full patch preflight:
`git apply --check`, temporary application, and byte-for-byte comparison with
the distributed overlay. The LaTeX article compiled, the PDF passed
structural preflight, and all 15 pages were rendered and visually inspected.

The artifact-generation environment did **not** contain Lean 4.34.0 or Lake.
Consequently this archive does not claim that elaboration, kernel checking,
`#print axioms`, dependency-closure execution, or the repository's 15-second /
60-second build budgets have been replayed locally. Those remain mandatory
integration gates; see `VALIDATION.md`.

## Computability and evaluation warning

Every new executable definition is primitive or structural recursion over
finite data and ultimately returns `Nat`, so the number is computable in
principle. It is intentionally infeasible to evaluate in practice.

**Do not run `#eval contender_35`, `#reduce contender_35`, or force any of its
large constituents.**
