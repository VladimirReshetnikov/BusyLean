# Validation status

## Scope

This proposal targets the exact BusyLean commit
`43513401d8929d60b2e3e40a4a20835a1271e94f`, whose recorded toolchain is
`leanprover/lean4:v4.34.0` and whose current endpoint is Contender 34.

## Completed checks

The following checks were completed in the artifact-generation environment:

1. **Repository audit**
   - inspected the current Contender 34 definition and comparison modules;
   - inspected the transfinite language stack (`TreeLanguage`,
     `TreeLanguage2`, and `TreeLanguage3`);
   - inspected the generic W-ranked hyperreflection definitions and growth
     theorems;
   - inspected root imports, staged checker, and existing audit structure.

2. **Static source validation**
   - verified all required files and principal declarations;
   - screened executable Lean source for `sorry`, `admit`, new `axiom`,
     `noncomputable`, `partial`, `unsafe`, `opaque`, `native_decide`, and
     evaluation commands;
   - checked balanced nested comments, strings, and delimiters;
   - checked the exact equations
     `family34 n = F34 (F34 n)` and
     `contender_35 = F35 (F35 42)`;
   - checked that the executable definition module does not textually mention
     any closed prior contender constant;
   - checked byte-for-byte equality between canonical Lean sources and overlay
     copies.

3. **Patch and script validation**
   - `git apply --check patches/contender35.patch` succeeded against the
     recorded baseline contexts;
   - the patch was then applied in an isolated temporary tree and every
     resulting modified or added file matched the distributed overlay byte for
     byte;
   - Python sources passed `python3 -m py_compile`;
   - shell scripts passed `bash -n`;
   - integration and replay scripts use strict shell mode.

4. **Article and PDF**
   - `article/contender35.tex` compiled successfully with pdfLaTeX via
     `latexmk`;
   - the result is a 15-page, letter-size, non-encrypted PDF;
   - structural preflight found no XFA and no scan-only pages;
   - all pages were rendered at 160 dpi and visually inspected;
   - no clipping, overlap, missing glyph blocks, or broken figures were found.

5. **Reproducibility artifacts**
   - machine-readable static report in `validation/static-validation.json`;
   - human-readable log in `validation/static-validation.log`;
   - PDF metadata and preflight records in `validation/`;
   - SHA-256 inventory in `SHA256SUMS`.

## Mandatory gate not completed locally

The environment did not contain Lean 4.34.0, Lake, or Elan, and network access
was insufficient to install the 4.34.0 toolchain. Therefore the archive does
**not** claim that any of the following have succeeded:

- Lean parsing, elaboration, termination checking, or kernel checking of the
  new modules;
- `#print axioms` confirmation for the new declarations;
- execution of the dependency-closure audit;
- the repository's 15-second definition and 60-second proof budgets;
- a clean Lake build of the complete original module graph.

Static validation is not a substitute for those checks. The Lean source was
written to mirror theorem signatures and proof patterns already present in
Contender 34 and in the generic W-ranked amplifier modules, but the authoritative
status must be determined by replay.

## Authoritative replay

Apply the patch to a clean checkout at the target commit:

```bash
./scripts/integrate.sh /path/to/BusyLean
```

Then run:

```bash
cd /path/to/BusyLean
python3 scripts/check.py
lake env lean test/Contender35Audit.lean
```

The packaged wrapper is equivalent:

```bash
/path/to/archive/scripts/replay.sh /path/to/BusyLean
```

A successful replay should establish all of the following:

- `BusyLean.Contender35` builds within the definition budget;
- `BusyLean.Comparison35` and the remainder build within the proof budget;
- all new theorem declarations elaborate and kernel-check;
- axiom dependencies remain within the repository's permitted set
  `{propext, Quot.sound}`;
- the closure of `BusyLean.contender_35` excludes every closed prior contender
  constant.

## Current classification

**Serious, integration-ready research proposal with completed static and PDF
validation; Lean kernel replay pending.**
