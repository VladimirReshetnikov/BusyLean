# Artifact manifest

## Primary deliverables

| Path | Description |
|---|---|
| `article/contender35.pdf` | Compiled 15-page research article. |
| `article/contender35.tex` | Complete LaTeX source. |
| `BusyLean/Contender35.lean` | Proposed executable definition module. |
| `BusyLean/Comparison35.lean` | Proposed comparison and domination proofs. |
| `patches/contender35.patch` | Patch against the exact target commit. |

## Integration and audit

| Path | Description |
|---|---|
| `overlay/BusyLean.lean` | Root import file with Contender 35 imports. |
| `overlay/BusyLean/Contender35.lean` | Overlay copy of the definition module. |
| `overlay/BusyLean/Comparison35.lean` | Overlay copy of the comparison module. |
| `overlay/scripts/check.py` | Staged checker updated to Contender 35. |
| `overlay/test/Contender35Audit.lean` | Overlay copy of the dedicated audit. |
| `test/Contender35Audit.lean` | Axiom, theorem-type, and closure audit source. |
| `scripts/integrate.sh` | Commit-checked patch application. |
| `scripts/replay.sh` | Authoritative clean-build and audit replay. |
| `scripts/check_submission.sh` | Static package check. |

## Validation and provenance

| Path | Description |
|---|---|
| `validation/validate_overlay.py` | Static validator and optional replay driver. |
| `validation/static-validation.json` | Machine-readable PASS report. |
| `validation/static-validation.log` | Human-readable validator and PDF metadata output. |
| `validation/baseline/BusyLean.lean` | Exact root-import baseline used by patch preflight. |
| `validation/baseline/scripts/check.py` | Exact checker baseline used by patch preflight. |
| `validation/pdf-preflight.txt` | Structural PDF preflight. |
| `validation/pdf-inspect.txt` | PDF metadata, outline, and font inspection. |
| `validation/pdfinfo.txt` | `pdfinfo` output. |
| `validation/pdf-visual-inspection.md` | Render-and-inspect record for all 15 pages. |
| `validation/latex-warnings.txt` | Concise LaTeX warning/build record. |
| `validation/environment.txt` | Tool versions and explicit record that Lean/Lake were unavailable. |
| `metadata/target.json` | Machine-readable repository target and proposal status. |
| `SHA256SUMS` | SHA-256 checksums for all other distributed files. |

## Explanatory documents

| Path | Description |
|---|---|
| `README.md` | Executive summary, file map, and replay instructions. |
| `THEOREM_MAP.md` | Claim-to-declaration correspondence. |
| `VALIDATION.md` | Completed checks and outstanding kernel gate. |
| `RESEARCH_NOTES.md` | Design rationale, rejected alternatives, and research agenda. |
| `MANIFEST.md` | This inventory. |
