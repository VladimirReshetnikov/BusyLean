#!/usr/bin/env bash
set -euo pipefail
HERE=$(cd "$(dirname "$0")/.." && pwd)
python3 -m py_compile "$HERE/validation/validate_overlay.py"
for script in "$HERE"/scripts/*.sh; do bash -n "$script"; done
python3 "$HERE/validation/validate_overlay.py" \
  --root "$HERE" --json "$HERE/validation/static-validation.json"
if command -v pdfinfo >/dev/null 2>&1 && [[ -f "$HERE/article/contender35.pdf" ]]; then
  pdfinfo "$HERE/article/contender35.pdf" | sed -n '1,20p'
fi
