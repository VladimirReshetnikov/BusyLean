#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 || $# -gt 2 ]]; then
  echo "usage: $0 /path/to/BusyLean [--allow-rebase]" >&2
  exit 2
fi
TARGET=$(cd "$1" && pwd)
ALLOW_REBASE=${2:-}
HERE=$(cd "$(dirname "$0")/.." && pwd)
EXPECTED=43513401d8929d60b2e3e40a4a20835a1271e94f

if [[ ! -d "$TARGET/.git" ]]; then
  echo "not a Git checkout: $TARGET" >&2
  exit 1
fi
HEAD=$(git -C "$TARGET" rev-parse HEAD)
if [[ "$HEAD" != "$EXPECTED" && "$ALLOW_REBASE" != "--allow-rebase" ]]; then
  echo "target HEAD is $HEAD; package targets $EXPECTED" >&2
  echo "rerun with --allow-rebase only after reviewing the patch" >&2
  exit 1
fi
if [[ -n "$(git -C "$TARGET" status --porcelain)" ]]; then
  echo "target worktree is not clean" >&2
  exit 1
fi

git -C "$TARGET" apply --check "$HERE/patches/contender35.patch"
git -C "$TARGET" apply "$HERE/patches/contender35.patch"
echo "Contender 35 overlay applied to $TARGET"
echo "Next: python3 scripts/check.py"
