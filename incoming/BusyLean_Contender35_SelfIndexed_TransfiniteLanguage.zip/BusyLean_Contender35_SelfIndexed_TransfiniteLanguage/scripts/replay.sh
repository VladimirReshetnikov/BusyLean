#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then
  echo "usage: $0 /path/to/integrated/BusyLean" >&2
  exit 2
fi
TARGET=$(cd "$1" && pwd)
cd "$TARGET"
python3 scripts/check.py
lake env lean test/Contender35Audit.lean
