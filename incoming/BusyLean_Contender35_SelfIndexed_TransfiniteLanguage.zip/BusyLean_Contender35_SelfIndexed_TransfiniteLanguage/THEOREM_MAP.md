# Contender 35 theorem map

Target: `VladimirReshetnikov/BusyLean` at
`43513401d8929d60b2e3e40a4a20835a1271e94f`.

| Mathematical claim | Lean declaration | Source | Proof mechanism |
|---|---|---|---|
| One additional predecessor iterate increases the current orbit value. | `BusyLean.iterateF34_step_lt` | `BusyLean/Comparison35.lean` | Direct instance of the existing `input_lt_F34`; no monotonicity assumption. |
| Every positive-length `F34` orbit lies above its start. | `BusyLean.input_lt_iterateF34_succ` | `BusyLean/Comparison35.lean` | Induction on orbit length using adjacent-step strictness. |
| The Contender 34 pointwise family lies below the self-index. | `BusyLean.family34_lt_treeIndex35` | `BusyLean/Comparison35.lean` | Instantiates the positive-orbit theorem at length `family34 n + 1`. |
| Every visible seed coordinate lies above the self-index. | `BusyLean.treeIndex35_lt_seed35` | `BusyLean/Comparison35.lean` | Instantiates the same orbit theorem at length `i + 2`. |
| A finite maximum entry lies below the raw indexed reflector. | `BusyLean.lt_reflectTSFamilyAt` | `BusyLean/Comparison35.lean` | The reflector adds `n + 1` above a maximum. |
| Every visible oracle coordinate lies below one raw reflection. | `BusyLean.oracle_lt_reflectTSFamilyAt` | `BusyLean/Comparison35.lean` | Explicit inclusion in `prefixMax`; avoids oracle monotonicity. |
| Every enumerated program value lies below one raw reflection. | `BusyLean.tsvalue_lt_reflectTSFamilyAt` | `BusyLean/Comparison35.lean` | Explicit inclusion in `BigNumber.maximum`; avoids evaluator monotonicity. |
| Every level-indexed reflector is progressive. | `BusyLean.indexedTSTransformer_progressive` | `BusyLean/Comparison35.lean` | Reuses the explicit oracle-coordinate bound. |
| Every visible long-orbit seed coordinate lies below `F35 n`. | `BusyLean.seed35_lt_F35` | `BusyLean/Comparison35.lean` | Existing `wDiagonalLift_preservesProgressive`. |
| The self-index lies below `F35 n`. | `BusyLean.treeIndex35_lt_F35` | `BusyLean/Comparison35.lean` | `treeIndex35_lt_seed35` followed by `seed35_lt_F35`. |
| The predecessor family lies below `F35 n`. | `BusyLean.family34_lt_F35` | `BusyLean/Comparison35.lean` | Self-index chain. |
| The unamplified indexed reflection lies below `F35 n`. | `BusyLean.raw_reflection_lt_F35` | `BusyLean/Comparison35.lean` | Existing `wDiagonalLift_strictlyInflationary`. |
| Every accepted depth-`n` program over `Addr (treeStackedTree (treeIndex35 n))` lies below `F35 n`. | `BusyLean.tsvalue_lt_F35` | `BusyLean/Comparison35.lean` | Raw program bound followed by strict amplification. |
| The numerical input lies below `F35 n`. | `BusyLean.input_lt_F35` | `BusyLean/Comparison35.lean` | Existing input growth for `F34`, then the pointwise family bound. |
| An explicit `F34` orbit of length `F35 42 + 2` lies below the final contender. | `BusyLean.long_F34_orbit_lt_contender_35` | `BusyLean/Comparison35.lean` | Selects seed coordinate `i = n = F35 42`. |
| Contender 34 is strictly below Contender 35. | `BusyLean.contender_34_lt_contender_35` | `BusyLean/Comparison35.lean` | `family34_lt_F35 42` and `input_lt_F35 (F35 42)`. |
| Contenders 33 and 32 are also below Contender 35. | `BusyLean.contender_33_lt_contender_35`, `BusyLean.contender_32_lt_contender_35` | `BusyLean/Comparison35.lean` | Transitivity with accepted predecessor comparisons. |

## Executable definitions

| Object | Declaration | Role |
|---|---|---|
| Predecessor iterator | `BusyLean.iterateF34` | Finite iteration of `F34` by primitive recursion. |
| Pointwise predecessor family | `BusyLean.family34` | Uniform family with `family34 42` definitionally equal to `contender_34`. |
| Self-index | `BusyLean.treeIndex35` | Long predecessor orbit controlling the tree-language parameter. |
| Visible oracle family | `BusyLean.seed35` | Continuation of the same orbit, exposed to reflection. |
| Parameterized ladder | `BusyLean.FL.tstreeLadderAt` | Depth-bounded terms over addresses of `treeStackedTree L`. |
| Parameterized reflector | `BusyLean.reflectTSFamilyAt` | Finite maximum of visible oracle and accepted program values. |
| Base transformer | `BusyLean.indexedTSTransformer` | Converts a level function into a reflection transformer. |
| Schedule / rank | `BusyLean.schedule35`, `BusyLean.rank35` | Autonomous W-trees rebuilt above a far-out seed coordinate. |
| Pointwise contender family | `BusyLean.F35` | W-ranked hyperreflection of the indexed language reflector. |
| Closed number | `BusyLean.contender_35` | `F35 (F35 42)`. |

## Audit declarations

`test/Contender35Audit.lean` prints axiom dependencies for the principal new
definitions and theorems, checks their types, and rejects dependency of
`BusyLean.contender_35` on any closed constant `contender_5` through
`contender_34`.
