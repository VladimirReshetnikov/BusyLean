# Research notes: why this Contender 35

## Design criterion

By the target commit, BusyLean already combines four powerful mechanisms:

1. a typed language for constructing countable tree ordinals;
2. promotion of the entire language to a new primitive;
3. iteration of that language promotion along a tree ordinal;
4. W-tree-ranked diagonal hyperreflection over address ladders.

A successor should therefore feed the predecessor's own growth back into more
than the final scalar output. The present proposal makes it control the
reflected tree parameter, the visible oracle family, and the scale of the new
schedule and rank.

## Why the construction has a robust proof margin

The tempting argument “larger oracle means larger program value” is invalid:
a program may branch on an oracle answer. Likewise, no monotonicity theorem for
`F34` or `treeStackedTree` is assumed. The proof uses only:

- the accepted pointwise theorem `x < F34 x`;
- induction along an explicitly defined finite orbit;
- literal membership in finite maxima;
- the accepted progressivity and strict-inflation theorems for
  `wDiagonalLift`.

This makes the intended proof resilient to the semantic non-monotonicity of
reflected programs.

## Alternatives considered

### 1. A trivial scalar wrapper

Definitions such as `F34 (F34 (F34 42))`, a power, or a tower over
`contender_34` would be constructive but would contribute little new structure
and would risk violating the dependency-closure discipline if written using the
closed predecessor constant.

### 2. Increasing only the program depth

Replacing the depth budget `n` by `family34 n` would make the finite term
enumeration enormous but would not strengthen the underlying tree-language
universe as directly. It would also make the definition phase harder to keep
within the repository's build budget.

### 3. Assuming monotonicity

A concise monotonicity-based proof would be mathematically unjustified without
new semantic theorems. The selected design avoids it completely.

### 4. A new self-interpreting operator language

A qualitatively stronger direction would add `langLift`, universe operators,
or W-ranked reflection constructors as first-class primitives of a typed
meta-language, then enumerate closed operator programs. This could dominate the
present proposal conceptually, but it creates a substantially larger trusted
surface: syntax, typing, semantics, enumeration, and new comparison lemmas.
The current Contender 35 is deliberately conservative enough to be reviewable.

## High-priority next questions

1. Prove a semantic monotonicity theorem for a syntactically positive fragment
   of the reflected language, and exploit it to compare whole ladders.
2. Define an operator language whose base objects are `CTree → CTree`
   transformers and whose primitives include `langLift`, `boostT`, and universe
   collapse.
3. Internalize W-ranked hyperreflection as an object-language primitive while
   preserving totality and an executable interpreter.
4. Replace the natural-number self-index by a tree-ordinal-indexed orbit of
   language transformers, with limits handled by structural recursion.
5. Prove explicit embeddings between successive schedule and rank W-trees,
   rather than using only numerical domination.
6. Derive a canonical proof-theoretic ordinal interpretation for Contenders
   32-35, separating formal numerical comparisons from heuristic notation.
7. Mechanize the static dependency-closure policy as a reusable Lean command
   or theorem and integrate it into every future contender template.
8. Investigate whether the finite raw-term enumerators can be represented
   intensionally, avoiding accidental elaboration or evaluation blowups while
   retaining computability.
