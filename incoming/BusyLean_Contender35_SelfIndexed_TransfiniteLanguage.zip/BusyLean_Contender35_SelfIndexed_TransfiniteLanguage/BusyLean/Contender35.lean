import BusyLean.Contender34

/-!
# Contender 35: self-indexed transfinite-language hyperreflection

```
family34 n    := F34 (F34 n)
treeIndex35 n := iterateF34 (family34 n + 1) (family34 n)
seed35 i n    := iterateF34 (i + 2) (treeIndex35 n)
F35 n         := wDiagonalLift (schedule35 n) (rank35 n)
                   (indexedTSTransformer treeIndex35) seed35 n n
contender_35  := F35 (F35 42)
```

Contender 34 reflects programs over the addresses of `treeStackedTree n`.
Contender 35 first constructs a numerical index far above Contender 34's
pointwise family: starting at `family34 n`, it performs `family34 n + 1`
further iterations of `F34`.  The reflected language at input `n` is then
built over `treeStackedTree (treeIndex35 n)`, while the visible oracle family
continues with an `F34` orbit above that index.

The W-ranked schedule and rank are also rebuilt above the self-indexed level.
All definitions are total and structurally or primitively recursive.  They are
computable in principle, but the closed contender must never be evaluated.
-/

namespace BusyLean.FL

open Ordinal

/-- Programs of depth at most `n` over the addresses of `treeStackedTree L`. -/
def tstreeLadderAt (L n : Nat) : List (CTm (Addr (treeStackedTree L))) :=
  ctmsUpTo (addrUpTo (treeStackedTree L) n) n

end BusyLean.FL

namespace BusyLean

open BigNumber (WTree)
open BusyLean.W

/-- Primitive recursion for finite iteration of Contender 34's construction. -/
def iterateF34 : Nat → Nat -> Nat
  | 0, x => x
  | k + 1, x => F34 (iterateF34 k x)

/-- Contender 34's construction as a function of its input.
Definitionally, `family34 42 = contender_34`. -/
def family34 (n : Nat) : Nat := F34 (F34 n)

/-- A self-index chosen by a predecessor orbit whose length is itself above
Contender 34 at the same input. -/
def treeIndex35 (n : Nat) : Nat :=
  iterateF34 (family34 n + 1) (family34 n)

/-- The visible seed family is an `F34` orbit beginning above the self-index. -/
def seed35 (i n : Nat) : Nat :=
  iterateF34 (i + 2) (treeIndex35 n)

/-- Address-ladder reflection over `treeStackedTree (level n)`.  The program
budget remains `n`; only the tree parameter is self-indexed. -/
def reflectTSFamilyAt (level : Nat → Nat) (fs : Family) (n : Nat) : Nat :=
  n + 1 + BigNumber.maxN (prefixMax (fun i => fs i n) n)
    (BigNumber.maximum
      (FL.tsvalue (level n) (packFamily fs) n)
      (FL.tstreeLadderAt (level n) n))

/-- The indexed transfinite-language reflector as a transformer. -/
def indexedTSTransformer (level : Nat → Nat) : Transformer :=
  fun fs _ n => reflectTSFamilyAt level fs n

/-- The W-ranked schedule is rebuilt above a far-out visible seed coordinate
and above Contender 34's schedule at the self-indexed level. -/
def schedule35 (n : Nat) : WTree Nat :=
  Autonomous.realize
    (Autonomous.hyper (seed35 n n + 42)
      (Autonomous.encode (schedule34 (treeIndex35 n))))

/-- The W-rank is one further autonomous hyperreflection above the schedule. -/
def rank35 (n : Nat) : WTree Nat :=
  Autonomous.realize
    (Autonomous.hyper (seed35 n n + 42)
      (Autonomous.encode (schedule35 n)))

/-- W-ranked hyperreflection of the self-indexed transfinite-language ladders. -/
def F35 (n : Nat) : Nat :=
  wDiagonalLift (schedule35 n) (rank35 n)
    (indexedTSTransformer treeIndex35) seed35 n n

/-- **Contender 35.** Never evaluate it. -/
def contender_35 : Nat := F35 (F35 42)

end BusyLean
