import BusyLean.Contender35
import BusyLean.Comparison34

/-! # Contender 35: comparison and domination theorems -/

namespace BusyLean

open BusyLean.W

/-- One more `F34` iterate strictly increases the current value.  This uses
only `input_lt_F34`; no monotonicity of `F34` is assumed. -/
theorem iterateF34_step_lt (k x : Nat) :
    iterateF34 k x < iterateF34 (k + 1) x := by
  change iterateF34 k x < F34 (iterateF34 k x)
  exact input_lt_F34 _

/-- Every positive-length `F34` orbit lies strictly above its starting point. -/
theorem input_lt_iterateF34_succ (k x : Nat) :
    x < iterateF34 (k + 1) x := by
  induction k with
  | zero =>
      simpa [iterateF34] using iterateF34_step_lt 0 x
  | succ k ih =>
      exact Nat.lt_trans ih (iterateF34_step_lt (k + 1) x)

/-- Contender 34's pointwise family is below the self-index. -/
theorem family34_lt_treeIndex35 (n : Nat) :
    family34 n < treeIndex35 n := by
  simpa only [treeIndex35] using
    (input_lt_iterateF34_succ (family34 n) (family34 n))

/-- Every visible seed coordinate is already above the self-index. -/
theorem treeIndex35_lt_seed35 (i n : Nat) :
    treeIndex35 n < seed35 i n := by
  simpa [seed35, Nat.add_assoc] using
    (input_lt_iterateF34_succ (i + 1) (treeIndex35 n))

/-- The generic strictness lemma for the indexed reflector. -/
theorem lt_reflectTSFamilyAt {level : Nat → Nat} {fs : Family} {n m : Nat}
    (h : m ≤ BigNumber.maxN (prefixMax (fun i => fs i n) n)
      (BigNumber.maximum
        (FL.tsvalue (level n) (packFamily fs) n)
        (FL.tstreeLadderAt (level n) n))) :
    m < reflectTSFamilyAt level fs n := by
  show m < n + 1 + _
  have hM : ∀ M : Nat, M + 1 ≤ n + 1 + M := fun M => by
    rw [Nat.add_comm M 1]
    exact Nat.add_le_add_right (Nat.le_add_left 1 n) M
  exact Nat.lt_of_le_of_lt h
    (Nat.lt_of_lt_of_le (Nat.lt_succ_self _) (hM _))

/-- Every visible oracle coordinate is strictly below one raw reflection. -/
theorem oracle_lt_reflectTSFamilyAt (level : Nat → Nat) (fs : Family)
    {i n : Nat} (hi : i ≤ n) :
    fs i n < reflectTSFamilyAt level fs n :=
  lt_reflectTSFamilyAt
    (Nat.le_trans (le_prefixMax (fun j => fs j n) hi)
      (BigNumber.le_maxN_left _ _))

/-- Every enumerated program value is strictly below one raw reflection. -/
theorem tsvalue_lt_reflectTSFamilyAt (level : Nat → Nat) (fs : Family)
    {n : Nat}
    {t : FL.CTm (Ordinal.Addr (Ordinal.treeStackedTree (level n)))}
    (ht : t ∈ FL.tstreeLadderAt (level n) n) :
    FL.tsvalue (level n) (packFamily fs) n t <
      reflectTSFamilyAt level fs n :=
  lt_reflectTSFamilyAt
    (Nat.le_trans
      (le_maximum (FL.tsvalue (level n) (packFamily fs) n) ht)
      (BigNumber.le_maxN_right _ _))

/-- Every indexed transfinite-language reflector is progressive. -/
theorem indexedTSTransformer_progressive (level : Nat → Nat) :
    Progressive (indexedTSTransformer level) :=
  fun seed _ _ _ hi => oracle_lt_reflectTSFamilyAt level seed hi

/-- Every visible coordinate of the long `F34` seed orbit is below `F35`. -/
theorem seed35_lt_F35 {i n : Nat} (hi : i ≤ n) :
    seed35 i n < F35 n :=
  ((wDiagonalLift_preservesProgressive (schedule35 n) (rank35 n))
    (indexedTSTransformer treeIndex35)
    (indexedTSTransformer_progressive treeIndex35))
    seed35 i n n hi

/-- The self-index itself is below `F35`. -/
theorem treeIndex35_lt_F35 (n : Nat) : treeIndex35 n < F35 n :=
  Nat.lt_trans (treeIndex35_lt_seed35 0 n)
    (seed35_lt_F35 (i := 0) (n := n) (Nat.zero_le n))

/-- At every input, `F35` exceeds Contender 34's pointwise family by a long
predecessor orbit, not merely by one application. -/
theorem family34_lt_F35 (n : Nat) : family34 n < F35 n :=
  Nat.lt_trans (family34_lt_treeIndex35 n) (treeIndex35_lt_F35 n)

/-- The unamplified self-indexed reflection is strictly below `F35`. -/
theorem raw_reflection_lt_F35 (n : Nat) :
    reflectTSFamilyAt treeIndex35 seed35 n < F35 n :=
  (wDiagonalLift_strictlyInflationary (schedule35 n) (rank35 n))
    (indexedTSTransformer treeIndex35)
    (indexedTSTransformer_progressive treeIndex35)
    seed35 n n n (Nat.le_refl n)

/-- Every accepted depth-`n` program over the addresses of
`treeStackedTree (treeIndex35 n)`, run with the packed long-orbit seed, is below
`F35 n`. -/
theorem tsvalue_lt_F35 {n : Nat}
    {t : FL.CTm (Ordinal.Addr (Ordinal.treeStackedTree (treeIndex35 n)))}
    (ht : t ∈ FL.tstreeLadderAt (treeIndex35 n) n) :
    FL.tsvalue (treeIndex35 n) (packFamily seed35) n t < F35 n :=
  Nat.lt_trans
    (tsvalue_lt_reflectTSFamilyAt treeIndex35 seed35 ht)
    (raw_reflection_lt_F35 n)

/-- The numerical input is below Contender 34's pointwise family. -/
theorem input_lt_family34 (n : Nat) : n < family34 n :=
  Nat.lt_trans (input_lt_F34 n) (input_lt_F34 (F34 n))

/-- `F35` is pointwise strictly above its numerical input. -/
theorem input_lt_F35 (n : Nat) : n < F35 n :=
  Nat.lt_trans (input_lt_family34 n) (family34_lt_F35 n)

/-- A strong closed lower bound: Contender 35 exceeds an `F34` orbit whose
length is itself `F35 42 + 2`, starting from the outer self-index. -/
theorem long_F34_orbit_lt_contender_35 :
    iterateF34 (F35 42 + 2) (treeIndex35 (F35 42)) < contender_35 := by
  simpa [seed35, contender_35, Nat.add_assoc] using
    (seed35_lt_F35 (i := F35 42) (n := F35 42) (Nat.le_refl _))

/-- **The required comparison:** Contender 34 is strictly below Contender 35. -/
theorem contender_34_lt_contender_35 : contender_34 < contender_35 :=
  Nat.lt_trans (family34_lt_F35 42) (input_lt_F35 (F35 42))

/-- Consequently the immediately preceding transfinite-language contenders are
also strictly below Contender 35. -/
theorem contender_33_lt_contender_35 : contender_33 < contender_35 :=
  Nat.lt_trans contender_33_lt_contender_34 contender_34_lt_contender_35

theorem contender_32_lt_contender_35 : contender_32 < contender_35 :=
  Nat.lt_trans contender_32_lt_contender_34 contender_34_lt_contender_35

end BusyLean
