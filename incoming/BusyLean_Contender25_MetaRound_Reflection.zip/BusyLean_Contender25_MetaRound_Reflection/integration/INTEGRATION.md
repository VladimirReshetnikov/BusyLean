# Integration into BusyLean

Target repository: `VladimirReshetnikov/BusyLean`

Target base commit:

```
4fe4f5ed921a8e861d33008a368c6e6ff5b40446
```

The base commit's accepted incumbent is Contender 24. Copy the package's
`BusyLean/`, `test/`, and `scripts/` files to the matching repository paths.
Then append these imports to `BusyLean.lean`:

```lean
import BusyLean.Ordinal.MetaRoundTower
import BusyLean.Contender25
import BusyLean.Comparison25
```

Run:

```bash
python3 scripts/check_contender25.py
```

The check performs a clean predecessor build, times the definition and proof
phases against the repository's 15 s and 60 s budgets, runs the smoke test,
prints axiom dependencies, and checks that `contender_25`'s transitive closure
does not contain any predecessor contender constant.

## Suggested review sequence

1. Inspect `BusyLean/Ordinal/MetaRoundTower.lean`.  The only new recursive
   definition follows the same `termination_by` pattern as `towerAlong`.
2. Build `BusyLean.Contender25` without the proof module.
3. Build `BusyLean.Comparison25`.
4. Run `test/Contender25Audit.lean` independently.
5. Review the exact-versus-heuristic boundary in the article before assigning
   any standard ordinal notation to the meta-round system.

Do not evaluate `BusyLean.contender_25`.
