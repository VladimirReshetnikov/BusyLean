# Research notes: self-indexed meta-round reflection

## Central move

Contender 24 applies `limitAlong` finitely many times.  The new construction
forms a transfinite iteration of the whole round-forming operation along a
well-founded order.  At stage `j`, it aggregates all earlier meta-stages,
runs `limitAlong` over that aggregate, and then applies `next`.  The union of
all stages is a new WFO and can index a further meta-round.

## Why this is not merely another amplifier

The W-ranked hyperreflection layer is deliberately retained so comparisons can
reuse the repository's generic progressivity theorems.  The qualitative change
is below it, in the reflected object language.  Programs are typed over a
universe ladder whose atom order is obtained by iterating the entire round
operator, rather than by choosing a larger finite rank or one more autonomous
W-tree.

## Exact formal target

The crucial theorem is:

```lean
theorem contender_24_lt_contender_25 :
  contender_24 < contender_25
```

The proof does not need a monotonicity theorem for `F24`.  Coordinate zero of
`orbit24` is definitionally `F24 (F24 n)`, and generic progressivity puts every
visible coordinate below `F25 n`.

The stronger closed lower bound is:

```lean
theorem long_F24_orbit_lt_contender_25 :
  iterateF24 (F25 42 + 2) (F25 42) < contender_25
```

## Exact claims versus calibration

Exact intended Lean claims:

- well-foundedness of every `metaRoundTower k`;
- strong normalization of accepted System FL programs over its atoms;
- progressivity of the new reflection transformer;
- domination of every visible `F24` orbit coordinate;
- domination of every enumerated program at the same input;
- strict numerical domination of Contender 24;
- a self-length `F24`-orbit lower bound.

Heuristic claims only:

- the meta-round operator is one structural level above finite iteration of
  `limitAlong`;
- its proof-theoretic calibration should be described by a fixed-point or
  closure process for the round operator;
- the precise standard ordinal notation, if any, has not been identified.

## Deliberately rejected alternatives

- `F24 (F24 (F24 42))`: exact but structurally trivial.
- a larger natural rank for `diagonalLift`: already subsumed by W-ranked
  hyperreflection and prior proposals.
- another autonomous W-tree universe ladder: close to proposal P25 and not a
  clear successor to accepted Contender 24.
- higher-order transformer lifts alone: close to pending second-order and
  third-order hyperreflection proposals, while leaving the object language
  unchanged.
- an unproved distinguished-set notation: potentially much stronger, but too
  risky without a complete normal-form and accessibility proof.

## Further work

1. Prove an explicit embedding of every `roundTower k` into a suitably chosen
   meta-round stage.
2. Define an abstract transfinite iterator for endofunctors on `WFO` and derive
   `towerAlong`, `roundClosureAlong`, and higher closures as instances.
3. Add a certified transitive-descendant W-tree atom order and compare it with
   the current sigma-based systems.
4. Replace the natural-number outer iteration by a direct WFO-indexed hierarchy
   of meta-round operators.
5. Investigate distinguished-set systems as a genuinely stronger base
   language, while retaining executable enumeration and constructive
   normalization.
6. Formalize ordinal assignments for the tower operators, separating lower
   bounds, upper bounds, and exact identifications.
