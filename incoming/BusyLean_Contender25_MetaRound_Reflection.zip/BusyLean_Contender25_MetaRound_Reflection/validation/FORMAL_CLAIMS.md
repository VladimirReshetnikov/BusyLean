# Formal claims supplied by the overlay

These are intended Lean declarations.  Their source is complete in the package;
local kernel compilation remains pending as recorded in `VALIDATION.md`.

## New well-founded system

```lean
BusyLean.Ordinal.metaRoundTower_wf
```

Every finite meta-round tower exposes a well-founded System FL atom order.

## Certified evaluator

```lean
BusyLean.FL.sn_erase_metaRound
```

A term accepted at natural type over the selected atom system is strongly
normalizing after erasure.

## Reflection bounds

```lean
BusyLean.metaRoundTransformer_progressive
BusyLean.metaRoundValue_lt_F25
BusyLean.orbit24_lt_F25
BusyLean.family24_lt_F25
BusyLean.input_lt_F25
BusyLean.F24_lt_F25
```

These establish oracle, program, predecessor-family, input, and pointwise
predecessor domination without monotonicity assumptions.

## Closed-number results

```lean
BusyLean.contender_24_lt_contender_25
BusyLean.long_F24_orbit_lt_contender_25
BusyLean.contender_23_lt_contender_25
```

The second theorem states:

```lean
iterateF24 (F25 42 + 2) (F25 42) < contender_25
```

It is the strongest concise numerical lower bound included in the proposal.
