# Validation status

## Baseline audited

The proposal targets BusyLean commit
`4fe4f5ed921a8e861d33008a368c6e6ff5b40446`, whose accepted incumbent is
Contender 24.  The definition, comparison module, tower implementation, contest
rules, and audit harness at that revision were inspected before designing the
proposal.

## Checks completed in the authoring environment

- all generated files are UTF-8 text;
- Python validator parses and passes `py_compile`;
- library-source screening finds no `sorry`, `native_decide`,
  `noncomputable`, `partial`, `unsafe`, `implemented_by`, `extern`,
  elaboration-time commands, or `#eval`;
- the predecessor constant `contender_24` does not occur in executable code in
  `BusyLean/Contender25.lean`;
- delimiter, trailing-whitespace, and line-length checks pass;
- the LaTeX article compiles successfully;
- the resulting PDF was rendered page by page and visually inspected.

## Lean kernel status

The authoring container did not contain `lean` or `lake`, and downloading the
pinned 4.34.0 toolchain was unavailable in that environment.  Consequently,
the Lean overlay has **not been kernel-compiled here**.  The package does not
claim a successful Lean build.  `scripts/check_contender25.py` is supplied to
perform the required clean build, timing, axiom, and dependency audits in a
BusyLean checkout with its pinned toolchain.

This distinction is intentional: the PDF build is validated; the mathematical
and Lean design has been statically reviewed against the exact current APIs;
the final kernel verdict remains to be obtained by running the supplied
validator.
