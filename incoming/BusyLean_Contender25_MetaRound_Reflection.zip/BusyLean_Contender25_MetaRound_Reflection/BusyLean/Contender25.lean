import BusyLean.Ordinal.MetaRoundTower
import BusyLean.Contender24

/-!
# Contender 25: self-indexed meta-round reflection

```
family24 n      := F24 (F24 n)
orbit24 i n     := iterateF24 (i + 2) n
seedHeight25 n  := orbit24 (family24 n) n
towerSystem25 n := metaRoundTower (seedHeight25 n)

F25 n :=
  wDiagonalLift (schedule25 n) (rank25 n)
    metaRoundTransformer orbit24 n n

contender_25 := F25 (F25 42)
```

The object language is System FL over `towerSystem25 n`.  Its atom order is a
meta-round tower: one meta-stage unions every earlier stage, runs a complete
round tower over that union, and applies one further relativized Buchholz
step.  The number of finite meta-rounds is itself a very large value obtained
from a self-length orbit of `F24`.

The seed exposes the entire finite `F24` orbit as a countable family.  In
particular, coordinate zero is definitionally Contender 24's family, while
coordinate `i` is the `(i + 2)`-fold iterate of `F24`.

Every definition is executable in principle.  Do not evaluate the contest
input.
-/

namespace BusyLean

open BigNumber (WTree)
open BusyLean.W

/-- Contender 24's construction as a function of its input.
At input `42`, this is exactly `contender_24`, without using that constant. -/
def family24 (n : Nat) : Nat := F24 (F24 n)

/-- Finite iteration of `F24`, oriented so that one more step exposes
`input_lt_F24` directly and requires no monotonicity theorem. -/
def iterateF24 : Nat → Nat → Nat
  | 0, n => n
  | k + 1, n => F24 (iterateF24 k n)

/-- Coordinate `i` is the `(i + 2)`-fold iterate of `F24` from `n`.
Coordinate zero is definitionally `family24 n`. -/
def orbit24 : Family := fun i n => iterateF24 (i + 2) n

/-- A self-fed orbit value controlling the object language and both W-trees. -/
def seedHeight25 (n : Nat) : Nat := orbit24 (family24 n) n

/-- The well-founded atom system used by the reflected language at input `n`. -/
def towerSystem25 (n : Nat) : Ordinal.BuchB.WFO :=
  Ordinal.metaRoundTower (seedHeight25 n)

end BusyLean

namespace BusyLean.FL

open Ordinal

/-- The atom order selected by `towerSystem25 n` is well-founded. -/
theorem towerSystem25_wf (n : Nat) :
    WellFounded (ALt (α := (towerSystem25 n).T)) := by
  simpa only [towerSystem25] using metaRoundTower_wf (seedHeight25 n)

/-- Strong normalization of an accepted meta-round-ladder program after
erasure to the executable System F core. -/
theorem sn_erase_metaRound {f : Nat → Nat} (n : Nat) {fuel : Nat}
    {t : CTm (towerSystem25 n).T}
    (h : infer fuel [] [] t = some Ty.nat) : F.SN f (erase t) :=
  sn_of_typed (wfUniv f (towerSystem25_wf n))
    (infer_sound fuel t (goodCtx_nil []) h).1

/-- Value of a meta-round-ladder program, relative to oracle `f`.
Ill-typed or non-numeral terms contribute zero. -/
def metaRoundValue (n : Nat) (f : Nat → Nat) (fuel : Nat)
    (t : CTm (towerSystem25 n).T) : Nat :=
  match h : infer fuel [] [] t with
  | some A =>
      if hA : A = Ty.nat then
        F.decode
          (F.nf f
            ⟨erase t,
              sn_erase_metaRound n (h.trans (congrArg some hA))⟩)
      else 0
  | none => 0

/-- Programs of enumeration depth and syntax depth at most `n` over the
self-fed meta-round atom system. -/
def metaRoundLadderUpTo (n : Nat) :
    List (CTm (towerSystem25 n).T) :=
  ctmsUpTo ((towerSystem25 n).enum n) n

end BusyLean.FL

namespace BusyLean

/-- One family-aware reflection step over the self-fed meta-round language. -/
def reflectMetaRoundFamily (fs : Family) (n : Nat) : Nat :=
  n + 1 +
    BigNumber.maxN
      (prefixMax (fun i => fs i n) n)
      (BigNumber.maximum
        (FL.metaRoundValue n (packFamily fs) n)
        (FL.metaRoundLadderUpTo n))

/-- The corresponding transformer on countable oracle families. -/
def metaRoundTransformer : Transformer :=
  fun fs _ n => reflectMetaRoundFamily fs n

/-- A schedule above Contender 24's rank tree at a self-fed hyper level. -/
def schedule25 (n : Nat) : BigNumber.WTree Nat :=
  Autonomous.realize
    (Autonomous.hyper (seedHeight25 n + 42)
      (Autonomous.encode (rank24 (seedHeight25 n))))

/-- A W-tree rank built above the new schedule at the same self-fed level. -/
def rank25 (n : Nat) : BigNumber.WTree Nat :=
  Autonomous.realize
    (Autonomous.hyper (seedHeight25 n + 42)
      (Autonomous.encode (schedule25 n)))

/-- W-ranked hyperreflection of the self-indexed meta-round language. -/
def F25 (n : Nat) : Nat :=
  wDiagonalLift (schedule25 n) (rank25 n)
    metaRoundTransformer orbit24 n n

/-- **Contender 25.** Never evaluate it. -/
def contender_25 : Nat := F25 (F25 42)

end BusyLean
