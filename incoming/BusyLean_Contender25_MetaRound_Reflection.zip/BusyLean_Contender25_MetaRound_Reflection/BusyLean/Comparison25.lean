import BusyLean.Contender25
import BusyLean.Comparison24

/-! # Contender 25: exact comparison and lower-bound theorems -/

namespace BusyLean

open BusyLean.W

/-- The additive guard in one meta-round reflection step strictly exceeds its
finite reflected maximum. -/
theorem lt_reflectMetaRoundFamily {fs : Family} {n m : Nat}
    (h : m ≤
      BigNumber.maxN
        (prefixMax (fun i => fs i n) n)
        (BigNumber.maximum
          (FL.metaRoundValue n (packFamily fs) n)
          (FL.metaRoundLadderUpTo n))) :
    m < reflectMetaRoundFamily fs n := by
  show m < n + 1 + _
  have hM : ∀ M : Nat, M + 1 ≤ n + 1 + M := fun M => by
    rw [Nat.add_comm M 1]
    exact Nat.add_le_add_right (Nat.le_add_left 1 n) M
  exact Nat.lt_of_le_of_lt h
    (Nat.lt_of_lt_of_le (Nat.lt_succ_self _) (hM _))

/-- Every visible oracle coordinate lies below one reflection step. -/
theorem oracle_lt_reflectMetaRoundFamily (fs : Family)
    {i n : Nat} (hi : i ≤ n) :
    fs i n < reflectMetaRoundFamily fs n :=
  lt_reflectMetaRoundFamily
    (Nat.le_trans
      (le_prefixMax (fun j => fs j n) hi)
      (BigNumber.le_maxN_left _ _))

/-- Every enumerated meta-round program lies below one reflection step. -/
theorem metaRoundValue_lt_reflectMetaRoundFamily (fs : Family)
    {n : Nat} {t : FL.CTm (towerSystem25 n).T}
    (ht : t ∈ FL.metaRoundLadderUpTo n) :
    FL.metaRoundValue n (packFamily fs) n t <
      reflectMetaRoundFamily fs n :=
  lt_reflectMetaRoundFamily
    (Nat.le_trans
      (le_maximum (FL.metaRoundValue n (packFamily fs) n) ht)
      (BigNumber.le_maxN_right _ _))

/-- Meta-round reflection is progressive. -/
theorem metaRoundTransformer_progressive :
    Progressive metaRoundTransformer :=
  fun seed _ _ _ hi => oracle_lt_reflectMetaRoundFamily seed hi

/-- One more `F24` iteration is strictly larger.  No monotonicity of `F24` is
used. -/
theorem iterateF24_lt_succ (k n : Nat) :
    iterateF24 k n < iterateF24 (k + 1) n := by
  simpa only [iterateF24] using input_lt_F24 (iterateF24 k n)

/-- Coordinate zero of the seed orbit is Contender 24's family. -/
theorem orbit24_zero (n : Nat) : orbit24 0 n = family24 n := rfl

/-- The exposed orbit is strictly increasing coordinate by coordinate. -/
theorem orbit24_lt_next (i n : Nat) :
    orbit24 i n < orbit24 (i + 1) n := by
  simpa only [orbit24, Nat.add_assoc, Nat.add_comm, Nat.add_left_comm]
    using iterateF24_lt_succ (i + 2) n

/-- Every seed-orbit coordinate visible at input `n` lies below `F25 n`. -/
theorem orbit24_lt_F25 {i n : Nat} (hi : i ≤ n) :
    orbit24 i n < F25 n := by
  have h :=
    ((wDiagonalLift_preservesProgressive (schedule25 n) (rank25 n))
      metaRoundTransformer metaRoundTransformer_progressive)
      orbit24 i n n hi
  simpa only [F25] using h

/-- At every input, `F25` exceeds Contender 24's family. -/
theorem family24_lt_F25 (n : Nat) : family24 n < F25 n := by
  have h := orbit24_lt_F25 (i := 0) (n := n) (Nat.zero_le n)
  simpa only [orbit24_zero] using h

/-- The raw meta-round reflection step is below the full W-ranked lift. -/
theorem raw_metaRound_reflection_lt_F25 (n : Nat) :
    reflectMetaRoundFamily orbit24 n < F25 n :=
  (wDiagonalLift_strictlyInflationary (schedule25 n) (rank25 n))
    metaRoundTransformer metaRoundTransformer_progressive
    orbit24 n n n (Nat.le_refl n)

/-- Every enumerated program in the self-fed meta-round language is below
`F25 n`. -/
theorem metaRoundValue_lt_F25 {n : Nat}
    {t : FL.CTm (towerSystem25 n).T}
    (ht : t ∈ FL.metaRoundLadderUpTo n) :
    FL.metaRoundValue n (packFamily orbit24) n t < F25 n :=
  Nat.lt_trans
    (metaRoundValue_lt_reflectMetaRoundFamily orbit24 ht)
    (raw_metaRound_reflection_lt_F25 n)

/-- The input is below Contender 24's two-fold family. -/
theorem input_lt_family24 (n : Nat) : n < family24 n :=
  Nat.lt_trans (input_lt_F24 n) (input_lt_F24 (F24 n))

/-- `F25` is strictly inflationary on numerical inputs. -/
theorem input_lt_F25 (n : Nat) : n < F25 n :=
  Nat.lt_trans (input_lt_family24 n) (family24_lt_F25 n)

/-- Pointwise, the old function `F24` is already below the new function. -/
theorem F24_lt_F25 (n : Nat) : F24 n < F25 n :=
  Nat.lt_trans (input_lt_F24 (F24 n)) (family24_lt_F25 n)

/-- A closed lower bound showing that the outer contender dominates an
`F24` orbit whose length is itself `F25 42 + 2`. -/
theorem long_F24_orbit_lt_contender_25 :
    iterateF24 (F25 42 + 2) (F25 42) < contender_25 := by
  simpa only [orbit24, contender_25] using
    (orbit24_lt_F25
      (i := F25 42) (n := F25 42) (Nat.le_refl _))

/-- **The required exact comparison:** Contender 24 is strictly smaller than
Contender 25. -/
theorem contender_24_lt_contender_25 :
    contender_24 < contender_25 :=
  Nat.lt_trans (family24_lt_F25 42) (input_lt_F25 (F25 42))

/-- Consequently, Contender 23 is also strictly below Contender 25. -/
theorem contender_23_lt_contender_25 :
    contender_23 < contender_25 :=
  Nat.lt_trans contender_23_lt_contender_24
    contender_24_lt_contender_25

end BusyLean
