import BusyLean.Ordinal.TowerAlong

/-!
# Transfinite iteration of the round-tower operator

`TowerAlong` defines `limitAlong J`, one complete transfinite tower whose
stages are indexed by a well-founded order `J`.  Contender 24 then iterates
`limitAlong` a finite number of times:

```
roundTower 0       = tower 1
roundTower (k + 1) = limitAlong (roundTower k).
```

This module raises that iteration by one structural level.  At an index `j`
of a well-founded order `J`, `roundClosureAlong J j` first takes the union of
all earlier meta-stages, performs a complete `limitAlong` round over that
union, and finally applies `WFO.next`.  The union of all such stages is
`roundClosureLimit J`.  Thus one application of `roundClosureLimit` is a
transfinite iteration of the entire round-forming operation, not merely one
more finite round.

All data are computable.  As in `towerAlong`, recursion uses Lean's
well-founded equation compiler and the executable order packaged by `WFO`.
No choice principle and no noncomputable definition is used.
-/

namespace BusyLean.Ordinal

open BuchB

namespace BuchB.WFO

/-- The meta-stage at `j`.

The recursive `sigma` is the union of all meta-stages with index below `j`.
We run a complete `limitAlong` round over that union and then one `next` step.
-/
def roundClosureAlong (J : WFO) (j : J.T) : WFO :=
  ((sigma (sub J j) (fun i => roundClosureAlong J i.1)).limitAlong).next
termination_by j
decreasing_by exact i.2

/-- The union of all meta-stages indexed by `J`.

This is a transfinite iteration of the round-forming operation along `J`.
-/
def roundClosureLimit (J : WFO) : WFO :=
  sigma J (roundClosureAlong J)

end BuchB.WFO

/-- Finite self-indexed iterations of the meta-round operator.

Already `metaRoundTower 0` is a transfinite iteration of complete rounds along
`roundTower 0`.  Every successor uses the entire preceding meta-round as the
index of the next transfinite iteration.
-/
def metaRoundTower : Nat → BuchB.WFO
  | 0 => (roundTower 0).roundClosureLimit
  | k + 1 => (metaRoundTower k).roundClosureLimit

/-- Every meta-round tower carries a well-founded atom order. -/
theorem metaRoundTower_wf (k : Nat) :
    WellFounded (FL.ALt (α := (metaRoundTower k).T)) :=
  ⟨(metaRoundTower k).wf⟩

end BusyLean.Ordinal
