import BusyLean.Ordinal.MetaRoundTower
import BusyLean.Contender25

/-!
Small kernel-level smoke checks.  This file deliberately contains no `#eval`:
the contest number must never be evaluated.
-/

open BusyLean

#check Ordinal.BuchB.WFO.roundClosureAlong
#check Ordinal.BuchB.WFO.roundClosureLimit
#check Ordinal.metaRoundTower
#check Ordinal.metaRoundTower_wf
#check towerSystem25
#check FL.metaRoundValue
#check contender_25

example (k : Nat) :
    WellFounded (FL.ALt (α := (Ordinal.metaRoundTower k).T)) :=
  Ordinal.metaRoundTower_wf k
