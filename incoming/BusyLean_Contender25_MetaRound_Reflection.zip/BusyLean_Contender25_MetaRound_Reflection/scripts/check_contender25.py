#!/usr/bin/env python3
"""Clean-build and audit the proposed BusyLean Contender 25.

Copy this package over a checkout of BusyLean at the target commit, add the
three imports documented in integration/INTEGRATION.md, then run from the
repository root:

    python3 scripts/check_contender25.py

The accepted predecessor is prebuilt and is not charged to the new contender.
"""
from __future__ import annotations

import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BUILD_DIRS = [
    ROOT / ".lake" / "build",
    ROOT / "proposals" / "P5-w-reflection" / "lean" / ".lake" / "build",
]
PERMITTED = {"propext", "Quot.sound"}
PREVIOUS = "BusyLean.Comparison24"
CURRENT_DEF = "BusyLean.Contender25"
CURRENT_PROOF = "BusyLean.Comparison25"
DEFINITION_BUDGET = 15.0
PROOF_BUDGET = 60.0
LAKE = shutil.which("lake") or "lake"

LIBRARY_FILES = [
    ROOT / "BusyLean" / "Ordinal" / "MetaRoundTower.lean",
    ROOT / "BusyLean" / "Contender25.lean",
    ROOT / "BusyLean" / "Comparison25.lean",
]
FORBIDDEN_TOKENS = {
    "sorry",
    "native_decide",
    "noncomputable",
    "partial",
    "unsafe",
    "implemented_by",
    "extern",
    "run_cmd",
    "initialize",
    "#eval",
}


def run_lake(args: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [LAKE, *args], cwd=ROOT, capture_output=True, text=True, check=False
    )


def timed_build(label: str, targets: list[str], budget: float | None) -> float:
    start = time.monotonic()
    build = run_lake(["build", *targets])
    elapsed = time.monotonic() - start
    if build.returncode != 0:
        print(build.stdout)
        print(build.stderr, file=sys.stderr)
        raise SystemExit(f"FAIL: {label} build failed")
    note = f"budget {budget:.0f} s" if budget else "accepted earlier; not budgeted"
    print(f"{label}: {elapsed:.3f} s ({note})")
    if budget is not None and elapsed > budget:
        raise SystemExit(f"FAIL: {label} exceeded its budget")
    return elapsed


def strip_lean_comments_and_strings(text: str) -> str:
    """Remove strings, line comments, and nested block comments for screening."""
    out: list[str] = []
    i = 0
    block_depth = 0
    in_string = False
    while i < len(text):
        if block_depth:
            if text.startswith("/-", i):
                block_depth += 1
                i += 2
            elif text.startswith("-/", i):
                block_depth -= 1
                i += 2
            else:
                i += 1
            continue
        if in_string:
            if text[i] == "\\":
                i += 2
            elif text[i] == '"':
                in_string = False
                i += 1
            else:
                i += 1
            continue
        if text.startswith("/-", i):
            block_depth = 1
            i += 2
        elif text.startswith("--", i):
            newline = text.find("\n", i)
            i = len(text) if newline < 0 else newline + 1
        elif text[i] == '"':
            in_string = True
            i += 1
        else:
            out.append(text[i])
            i += 1
    return "".join(out)


def source_screen() -> None:
    for path in LIBRARY_FILES:
        if not path.exists():
            raise SystemExit(f"FAIL: missing {path.relative_to(ROOT)}")
        code = strip_lean_comments_and_strings(path.read_text(encoding="utf-8"))
        words = set(re.findall(r"[#A-Za-z_][A-Za-z0-9_#]*", code))
        bad = sorted(tok for tok in FORBIDDEN_TOKENS if tok in words)
        if bad:
            raise SystemExit(f"FAIL: forbidden tokens in {path}: {bad}")
    contender_code = strip_lean_comments_and_strings(
        (ROOT / "BusyLean" / "Contender25.lean").read_text(encoding="utf-8")
    )
    if re.search(r"\bcontender_24\b", contender_code):
        raise SystemExit("FAIL: definition module mentions predecessor constant contender_24")
    print("source screen: pass")


def audit() -> None:
    result = run_lake(["env", "lean", "test/Contender25Audit.lean"])
    output = result.stdout + result.stderr
    print(output)
    if result.returncode != 0:
        raise SystemExit("FAIL: audit did not run cleanly")
    reports = re.findall(
        r"'([^']+)' (?:depends on axioms: \[([^\]]*)\]|does not depend)",
        output,
    )
    bad = [
        (name, axioms)
        for name, axioms in reports
        if axioms
        and {a.strip() for a in axioms.split(",")} - PERMITTED
    ]
    if not reports or bad:
        raise SystemExit(f"FAIL: forbidden axioms or missing reports: {bad}")
    print(f"axiom audit: pass ({len(reports)} declarations)")


def main() -> None:
    source_screen()
    if shutil.which("lake") is None:
        raise SystemExit("FAIL: lake is not installed or not on PATH")
    for directory in BUILD_DIRS:
        shutil.rmtree(directory, ignore_errors=True)
    total = timed_build("predecessor", [PREVIOUS], None)
    total += timed_build("new definitions", [CURRENT_DEF], DEFINITION_BUDGET)
    total += timed_build("new proofs", [CURRENT_PROOF], PROOF_BUDGET)
    smoke = run_lake(["env", "lean", "test/MetaRoundTowerSmoke.lean"])
    if smoke.returncode != 0:
        print(smoke.stdout)
        print(smoke.stderr, file=sys.stderr)
        raise SystemExit("FAIL: smoke test failed")
    audit()
    print(f"PASS: total clean build {total:.3f} s")


if __name__ == "__main__":
    main()
