# BusyLean Contender 25: Self-Indexed Meta-Round Reflection

This package proposes a new computable-in-principle natural number for
`VladimirReshetnikov/BusyLean`, targeting repository revision:

```
4fe4f5ed921a8e861d33008a368c6e6ff5b40446
```

At that revision, the accepted incumbent is Contender 24.

## Proposed construction

The new object-language atom order is a **meta-round tower**.  Contender 24
iterates `limitAlong` a finite number of times.  Here, each stage of
`roundClosureAlong J`:

1. unions every earlier meta-stage;
2. runs an entire `limitAlong` round over that union;
3. applies one further `WFO.next` step.

The union of these stages is again a computably presented WFO and can index the
next meta-round.

The numerical definitions are:

```lean
def family24 (n : Nat) : Nat := F24 (F24 n)

def iterateF24 : Nat → Nat → Nat
  | 0, n => n
  | k + 1, n => F24 (iterateF24 k n)

def orbit24 : Family := fun i n => iterateF24 (i + 2) n

def seedHeight25 (n : Nat) : Nat := orbit24 (family24 n) n

def towerSystem25 (n : Nat) : Ordinal.BuchB.WFO :=
  Ordinal.metaRoundTower (seedHeight25 n)

def F25 (n : Nat) : Nat :=
  wDiagonalLift (schedule25 n) (rank25 n)
    metaRoundTransformer orbit24 n n

def contender_25 : Nat := F25 (F25 42)
```

Do not evaluate `contender_25`.

## Intended exact theorems

```lean
theorem contender_24_lt_contender_25 :
  contender_24 < contender_25

theorem long_F24_orbit_lt_contender_25 :
  iterateF24 (F25 42 + 2) (F25 42) < contender_25
```

The comparison does not assume monotonicity of `F24` or reflection.  It uses
only the accepted theorem `n < F24 n`, progressivity of the new reflection
transformer, and generic progressivity of W-ranked diagonal lifting.

## Validation status

The article is compiled and its 24-page PDF was rendered and inspected.  The
Python validator and static source screens pass.  The authoring container did
not have `lean` or `lake`, so this package **does not claim a local Lean kernel
build**.  Run the supplied validator in a BusyLean checkout with the pinned
Lean 4.34.0 toolchain:

```bash
python3 scripts/check_contender25.py
```

It performs a clean predecessor build, times the new definition and proof
phases, runs smoke tests, prints axiom dependencies, and checks the transitive
constant closure for forbidden predecessor constants.

## Package map

- `article/meta_round_contender.tex` and `.pdf` - 24-page research article.
- `BusyLean/Ordinal/MetaRoundTower.lean` - transfinite round-closure WFO.
- `BusyLean/Contender25.lean` - evaluator, reflection, orbit, and number.
- `BusyLean/Comparison25.lean` - exact comparison and lower bounds.
- `test/MetaRoundTowerSmoke.lean` - non-evaluating type checks.
- `test/Contender25Audit.lean` - axiom and dependency closure audit.
- `scripts/check_contender25.py` - contest-style clean validator.
- `integration/contender25.patch` - overlay patch for the target revision.
- `integration/INTEGRATION.md` - review and installation instructions.
- `validation/VALIDATION.md` - precise completed/pending validation record.
- `RESEARCH_NOTES.md` - alternatives, limitations, and research roadmap.
- `MANIFEST.txt` and `SHA256SUMS` - inventory and integrity ledger.
