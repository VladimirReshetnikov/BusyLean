import BusyLean.Contender60
import BusyLean.Comparison59

/-! # Contender 60: comparison theorems -/

namespace BusyLean.SelfWreath

/-- Adding the next finite group cannot reduce the accumulated mass. -/
theorem mass_le_step (s : State) : s.mass ≤ (step s).mass := by
  change s.mass ≤ s.mass + nextOrder s.order
  exact Nat.le_add_right _ _

/-- Accumulated mass is monotone through any number of self-wreathing steps. -/
theorem mass_le_iter (k : Nat) (s : State) : s.mass ≤ (iter k s).mass := by
  induction k generalizing s with
  | zero =>
      exact Nat.le_refl _
  | succ k ih =>
      change s.mass ≤ (iter k (step s)).mass
      exact Nat.le_trans (mass_le_step s) (ih (step s))

/-- The tower score retains the `q+1` elements of its seed group. -/
theorem seed_mass_le_score (q : Nat) : q + 1 ≤ score q := by
  simpa [score, tower, seed] using mass_le_iter (q + 1) (seed q)

/-- The score already contains the complete first wreath-product group. -/
theorem first_order_le_score (q : Nat) : nextOrder (q + 1) ≤ score q := by
  have hfirst : nextOrder (q + 1) ≤ (step (seed q)).mass := by
    change nextOrder (q + 1) ≤ (q + 1) + nextOrder (q + 1)
    exact Nat.le_add_left _ _
  have htail : (step (seed q)).mass ≤ score q := by
    simpa [score, tower] using mass_le_iter q (step (seed q))
  exact Nat.le_trans hfirst htail

/-- The self-wreathing score strictly exceeds its input. -/
theorem input_lt_score (q : Nat) : q < score q :=
  Nat.lt_of_lt_of_le (Nat.lt_succ_self q) (seed_mass_le_score q)

end BusyLean.SelfWreath

namespace BusyLean

/-- Contender 59's family is inflationary. -/
theorem input_lt_family59 (n : Nat) : n < family59 n :=
  Nat.lt_trans (input_lt_F59 n) (input_lt_F59 (F59 n))

/-- At every input, `F60` strictly exceeds Contender 59's family. -/
theorem family59_lt_F60 (n : Nat) : family59 n < F60 n := by
  simpa [F60] using SelfWreath.input_lt_score (family59 n)

/-- The new family is itself inflationary. -/
theorem input_lt_F60 (n : Nat) : n < F60 n :=
  Nat.lt_trans (input_lt_family59 n) (family59_lt_F60 n)

/-- **The required comparison:** Contender 59 is strictly smaller. -/
theorem contender_59_lt_contender_60 : contender_59 < contender_60 := by
  exact Nat.lt_trans (family59_lt_F60 42) (input_lt_F60 (F60 42))

/-- A transitive comparison with Contender 58. -/
theorem contender_58_lt_contender_60 : contender_58 < contender_60 :=
  Nat.lt_trans contender_58_lt_contender_59 contender_59_lt_contender_60

end BusyLean
