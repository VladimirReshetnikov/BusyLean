/-!
# Self-wreathing Cayley towers

The underlying set of a finite group of order `a` canonically supplies `a`
coordinates.  Let its full symmetric group permute those coordinates in the
wreath product `G^G \rtimes Sym(G)`; the resulting group has order
`a^a * a!`.
`State.mass` records the cardinality of the disjoint union of all groups built
so far.  The implementation stores only cardinalities; the article gives the
finite-group construction whose counting recurrence this file computes.
-/

namespace BusyLean.SelfWreath

/-- A local factorial, kept independent of any library implementation. -/
def fact : Nat → Nat
  | 0 => 1
  | n + 1 => (n + 1) * fact n

/-- Cardinality of `G wr S_a` when `|G| = a` and `S_a` permutes `a` copies. -/
def nextOrder (a : Nat) : Nat := a ^ a * fact a

/--
`order` is the order of the current group.  `mass` is the cardinality of the
finite disjoint union of all groups encountered through the current stage.
-/
structure State where
  order : Nat
  mass : Nat

/-- Start from the cyclic group `C_(q+1)`. -/
def seed (q : Nat) : State :=
  { order := q + 1, mass := q + 1 }

/-- Replace the current group by its self-sized symmetric wreath product. -/
def step (s : State) : State :=
  let a' := nextOrder s.order
  { order := a', mass := s.mass + a' }

/-- Iterate the self-wreathing step. -/
def iter : Nat → State → State
  | 0, s => s
  | k + 1, s => iter k (step s)

/-- The complete tower state after `q+1` self-wreathing stages. -/
def tower (q : Nat) : State := iter (q + 1) (seed q)

/-- Cardinality of the disjoint union of every finite group in the tower. -/
def score (q : Nat) : Nat := (tower q).mass

end BusyLean.SelfWreath
