import BusyLean.Contender59
import BusyLean.SelfWreath

/-!
# Contender 60: the self-wreathing Cayley tower

Let `q = family59 n`. Begin with the cyclic group of order `q+1`. If the
current group is `G`, let the full symmetric group of its underlying set
permute the coordinates of `G^G`; the resulting wreath product has order
`a^a * a!` when `|G| = a`. Repeat this `q+1` times and return the
cardinality of the disjoint union of all groups in the tower.

This is a finite, primitive-recursive construction. The previous contender is
used only to choose the seed and tower height; the growth engine is the new
finite-group feedback operation.

**Do not evaluate `contender_60`.**
-/

namespace BusyLean

/-- Contender 59's construction as a family; `family59 42 = contender_59`. -/
def family59 (n : Nat) : Nat := F59 (F59 n)

/-- One self-wreathing tower at the scale supplied by Contender 59. -/
def F60 (n : Nat) : Nat := SelfWreath.score (family59 n)

/-- **Contender 60.** Never evaluate it. -/
def contender_60 : Nat := F60 (F60 42)

end BusyLean
