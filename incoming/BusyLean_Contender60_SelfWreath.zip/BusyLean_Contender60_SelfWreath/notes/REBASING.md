# Rebasing the independent engine

`BusyLean/SelfWreath.lean` is independent of any incumbent. Only the two small
bridge files are numbered and tied to the pinned snapshot.

To retarget a later verified incumbent `K` with construction `FK`:

1. Rename `Contender60.lean` and `Comparison60.lean` to the next free number.
2. Replace the imports of `Contender59`/`Comparison59` by the later files.
3. Define `familyK n := FK (FK n)`.
4. Define the new family as `SelfWreath.score (familyK n)`.
5. Reuse the same arithmetic comparison pattern, starting from the later
   repository theorem `input_lt_FK`.
6. Update the closure audit so the new definition cannot mention the closed
   incumbent constant.
7. Re-run kernel, axiom, timing, PDF, and checksum checks.

The algebraic engine and recurrence need no change. A rebase changes only the
external seed/round scale and theorem names. This note is not a claim that the
archived Contender 60 beats commits made after its exact target pin.
