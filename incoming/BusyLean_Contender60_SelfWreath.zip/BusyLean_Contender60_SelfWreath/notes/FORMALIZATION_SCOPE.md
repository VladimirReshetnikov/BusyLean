# Formalization scope

The supplied Lean code formalizes, subject to successful kernel replay:

- the primitive-recursive cardinality recurrence;
- the closed natural-number definition;
- monotonicity of accumulated tower mass;
- retention of the entire first wreath-product group in the score;
- inflationarity of the incumbent-derived scale `family59`;
- the strict comparison with verified Contender 59 at the pinned commit.

The code does **not** yet formalize finite groups, permutation actions,
semidirect products, or the cardinality theorem

```text
|G wr S_a| = |G|^a * a!.
```

The article proves the counting identity mathematically, shows that the
operation is canonical on finite-group isomorphism classes, and records its
normal base subgroup, symmetric quotient, and alternating composition factors.
Those results motivate the recurrence but are not dependencies of the Lean
comparison proof.

Formalizing the semantic bridge without Mathlib is a valuable follow-up. It
would require a small finite-group API, finite function/permutation counting,
and a cardinality proof for semidirect products. It is intentionally separated
from the contest-critical arithmetic core so reviewers can audit the closed
number independently.
