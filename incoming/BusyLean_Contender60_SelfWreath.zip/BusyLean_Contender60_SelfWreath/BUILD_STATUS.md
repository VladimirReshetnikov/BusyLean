# Build and verification status

Target repository commit:
`e5bdd4fa78779fa762f74150f4d524a42135bf46`

Target commit time: `2026-10-13T20:49:51Z`

Pinned repository toolchain: `leanprover/lean4:v4.34.0`

| Check | Status | Evidence / command |
|---|---|---|
| Exact baseline inspected | PASS | Inspected `Contender59.lean`, `Comparison59.lean`, commit metadata, toolchain, and audit conventions at the pinned snapshot. |
| Forbidden-token static audit | PASS | `python3 scripts/static_audit.py` |
| Closed-incumbent textual dependency check | PASS | The audit strips comments and rejects executable references to `contender_59` in `Contender60.lean`. |
| Independent small model | PASS | `python3 scripts/small_model.py --q 0 --q 1 --q 2` |
| LaTeX compilation | PASS | `latexmk -pdf -interaction=nonstopmode -halt-on-error article/contender60_self_wreath.tex` |
| PDF structural inspection | PASS | 17 US-letter pages; unencrypted; 27 outline items; all listed fonts embedded; no forms or attachments. |
| PDF visual render inspection | PASS | Every page rendered at 160 dpi and checked for clipping, overlap, broken glyphs, and listing overflow. |
| Lean 4.34.0 kernel build | **NOT RUN** | No `lean`, `lake`, or `elan` executable was installed. Retrieval of the exact 4.34.0 release could not be completed in the execution environment. |
| `#print axioms` replay | **NOT RUN** | Requires the preceding Lean build. Commands are in `test/Audit60.lean`. |
| Repository timing budgets | **NOT RUN** | Must be measured from a clean build in the pinned repository. |

## Intended kernel facts in the supplied Lean source

Subject to successful kernel replay, the source establishes:

- accumulated tower mass is monotone under every step and iteration;
- `q + 1 <= SelfWreath.score q`, hence `q < SelfWreath.score q`;
- `SelfWreath.nextOrder (q+1) <= SelfWreath.score q`;
- `n < family59 n` using the repository theorem `input_lt_F59`;
- `family59 n < F60 n` for every input;
- `n < F60 n` for every input;
- `contender_59 < contender_60`;
- transitively, `contender_58 < contender_60`.

## Mathematics proved in the article, not yet kernelized

The article gives self-contained finite counting arguments for

```text
|G^(underlying G) semidirect Sym(underlying G)| = |G|^|G| * |G|!
```

and proves, for `q >= 1`,

```text
SelfWreath.score(q) >= E_(q+1)(q+1),
E_0(x) = x,
E_(r+1)(x) = 2^(E_r(x)).
```

The Lean files intentionally do not formalize finite groups, semidirect
products, composition factors, or the semantic bridge from the group
construction to the recurrence. That omission does not affect the closed
natural-number definition or the intended strict comparison theorem, but it is
a real formalization boundary.

## Required acceptance procedure

1. Check out the pinned commit.
2. Copy the three `BusyLean/*.lean` files into the repository.
3. Apply or reproduce the imports from `patches/BusyLean.lean.patch`.
4. Run `lake build` from a clean build directory.
5. Run `lake env lean test/Small60.lean`.
6. Run `lake env lean test/Audit60.lean` and inspect all reported axioms.
7. Add the closure assertion from `patches/Audit.lean.patch` to the repository audit.
8. Measure definition and proof checking times under the contest rules.
9. Record any elaboration repair as a separate review commit.
10. Never evaluate the contender itself.
