import BusyLean.SelfWreath

/-! Small definitional checks. This file deliberately never evaluates the contender. -/

example : BusyLean.SelfWreath.fact 5 = 120 := rfl
example : BusyLean.SelfWreath.nextOrder 2 = 8 := rfl
example : BusyLean.SelfWreath.score 0 = 2 := rfl
