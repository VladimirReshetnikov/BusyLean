import BusyLean.Comparison60

/-!
Run with:

  lake env lean test/Audit60.lean

The commands below ask Lean to report every axiom used by the new definitions
and comparison theorems. The intended result is no forbidden axiom; in
particular there is no `Classical.choice`.
-/

#print axioms BusyLean.SelfWreath.fact
#print axioms BusyLean.SelfWreath.nextOrder
#print axioms BusyLean.SelfWreath.score
#print axioms BusyLean.contender_60
#print axioms BusyLean.SelfWreath.mass_le_iter
#print axioms BusyLean.SelfWreath.first_order_le_score
#print axioms BusyLean.family59_lt_F60
#print axioms BusyLean.contender_59_lt_contender_60
