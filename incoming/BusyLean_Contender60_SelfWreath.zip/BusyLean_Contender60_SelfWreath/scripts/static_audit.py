#!/usr/bin/env python3
"""Conservative text audit for forbidden BusyLean proposal constructs.

This is not a substitute for `#print axioms` or a Lean kernel build.  It is a
fast packaging check that rejects common forbidden tokens and the previous
closed contender constant in the new definition file.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import re
import sys

FORBIDDEN = (
    "sorry",
    "admit",
    "axiom ",
    "Classical.choice",
    "native_decide",
    "noncomputable",
    "partial ",
    "unsafe ",
    "implemented_by",
    "extern ",
    "run_cmd",
    "initialize",
    "#eval",
)


def code_only(text: str) -> str:
    # Lean block comments nest, so this deliberately conservative regexp is
    # only a packaging aid; the kernel audit remains authoritative.
    text = re.sub(r"/\-.*?\-/", "", text, flags=re.DOTALL)
    text = re.sub(r"--.*", "", text)
    return text


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "root", nargs="?", type=Path, default=Path(__file__).resolve().parents[1]
    )
    args = parser.parse_args()

    files = sorted((args.root / "BusyLean").glob("*.lean"))
    failures: list[str] = []
    for path in files:
        text = code_only(path.read_text(encoding="utf-8"))
        for token in FORBIDDEN:
            if token in text:
                failures.append(
                    f"{path.relative_to(args.root)}: forbidden token {token!r}"
                )

    contender_path = args.root / "BusyLean" / "Contender60.lean"
    contender = code_only(contender_path.read_text(encoding="utf-8"))
    definition_region = contender.split("end BusyLean", 1)[0]
    if "contender_59" in definition_region:
        failures.append(
            "Contender60.lean: definition depends on closed constant contender_59"
        )

    if failures:
        print("STATIC AUDIT FAILED", file=sys.stderr)
        for failure in failures:
            print(f"- {failure}", file=sys.stderr)
        return 1

    print(f"STATIC AUDIT PASSED: {len(files)} Lean source files checked")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
