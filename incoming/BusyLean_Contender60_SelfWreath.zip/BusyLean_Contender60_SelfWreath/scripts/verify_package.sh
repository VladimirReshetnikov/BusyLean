#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

python3 "$ROOT/scripts/static_audit.py" "$ROOT"
python3 "$ROOT/scripts/small_model.py" \
  --q 0 --q 1 --q 2 \
  --json "$ROOT/data/small_values.json" \
  --csv "$ROOT/data/small_values.csv" \
  >/dev/null

if command -v lake >/dev/null 2>&1; then
  echo "Lean found: running kernel checks"
  (cd "$ROOT" && lake env lean test/Small60.lean)
  (cd "$ROOT" && lake env lean test/Audit60.lean)
else
  echo "Lean/lake not found; kernel checks skipped" >&2
fi
