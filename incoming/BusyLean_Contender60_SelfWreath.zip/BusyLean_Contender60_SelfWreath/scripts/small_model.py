#!/usr/bin/env python3
"""Small exact model of the self-wreathing recurrence.

The actual contender must never be computed.  This script emits exact values
only while they remain modest.  Once a current order is too large even for a
floating-point logarithm, it records a rigorous lower bound on the number of
decimal digits of the next order, using `2^a <= next_order(a)` for `a >= 2`.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass(frozen=True)
class Row:
    q: int
    stage: int
    order: str
    decimal_digits: str
    digit_claim: str
    mass: str
    exact: bool


def next_order(a: int) -> int:
    return pow(a, a) * math.factorial(a)


def abbreviated(n: int, edge: int = 24) -> str:
    text = str(n)
    if len(text) <= 2 * edge + 8:
        return text
    return f"{text[:edge]}...{text[-edge:]} ({len(text)} digits)"


def generate(q: int, max_exact_digits: int = 5000) -> list[Row]:
    if q < 0:
        raise ValueError("q must be nonnegative")
    a = q + 1
    mass = a
    rows = [Row(q, 0, str(a), str(len(str(a))), "exact", str(mass), True)]

    for stage in range(1, q + 2):
        # For very large a, do not convert it to float.  Since a^a a! >= 2^a
        # for a >= 2 and log10(2) > 30102/100000, this is a rigorous lower
        # bound on the next decimal digit count.
        if a > 100_000:
            lower_digits = (30_102 * a) // 100_000 + 1
            rows.append(
                Row(
                    q,
                    stage,
                    f"({abbreviated(a)})^({abbreviated(a)}) * ({abbreviated(a)})!",
                    abbreviated(lower_digits),
                    "rigorous lower bound",
                    f"{abbreviated(mass)} + next_order",
                    False,
                )
            )
            break

        log10_next = a * math.log10(a) + math.lgamma(a + 1) / math.log(10)
        digits = int(math.floor(log10_next)) + 1
        if digits > max_exact_digits:
            rows.append(
                Row(
                    q,
                    stage,
                    f"({a})^({a}) * ({a})!",
                    str(digits),
                    "estimated before exact construction",
                    f"{mass} + next_order",
                    False,
                )
            )
            break

        a = next_order(a)
        mass += a
        rows.append(
            Row(q, stage, str(a), str(len(str(a))), "exact", str(mass), True)
        )
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--q", type=int, action="append")
    parser.add_argument("--json", type=Path)
    parser.add_argument("--csv", type=Path)
    parser.add_argument("--max-exact-digits", type=int, default=5000)
    args = parser.parse_args()

    qs = args.q if args.q is not None else [0, 1, 2]
    rows: list[Row] = []
    for q in dict.fromkeys(qs):
        rows.extend(generate(q, args.max_exact_digits))

    payload = [asdict(row) for row in rows]
    if args.json:
        args.json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    if args.csv:
        with args.csv.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=Row.__annotations__.keys())
            writer.writeheader()
            writer.writerows(payload)

    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
