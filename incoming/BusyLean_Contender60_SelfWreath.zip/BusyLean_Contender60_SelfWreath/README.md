# BusyLean Contender 60 proposal: Self-Wreathing Cayley Tower

This archive proposes a constructive successor to the verified BusyLean
Contender 59 at the exact repository commit
`e5bdd4fa78779fa762f74150f4d524a42135bf46` (2026-10-13 20:49:51 UTC).
The repository was changing minute by minute while the package was assembled,
so the pin is part of the statement: this archive is a successor to that
snapshot, not a claim about uninspected later commits.

## Core construction

For a finite group `G_r`, let the full symmetric group of its underlying set
permute the coordinates of `G_r^(G_r)`, and form the canonical semidirect
product

```text
G_(r+1) = G_r^(underlying G_r) semidirect Sym(underlying G_r).
```

If `a_r = |G_r|`, then the exact order recurrence is

```text
a_(r+1) = a_r^(a_r) * a_r!.
```

Thus the current group order becomes both the number of direct-product factors
and the permutation degree of the next symmetric group. The base subgroup is
normal with symmetric-group quotient; once `a_r >= 5`, the tower also acquires
an alternating composition factor of degree `a_r`.

Starting from the cyclic group of order `q+1`, the construction performs `q+1`
self-wreathing steps and returns the cardinality of the tagged disjoint union
of all groups built. Its Lean cardinality engine is independent of BusyLean's
reflection and language-tower machinery.

The contest bridge is

```lean
def family59 (n : Nat) : Nat := F59 (F59 n)
def F60 (n : Nat) : Nat := SelfWreath.score (family59 n)
def contender_60 : Nat := F60 (F60 42)
```

The intended kernel theorem is

```lean
theorem contender_59_lt_contender_60 : contender_59 < contender_60
```

and the definition file does not reference the closed constant
`contender_59`.

## Quantitative scale

For `q >= 1`, define

```text
E_0(x) = x,
E_(r+1)(x) = 2^(E_r(x)).
```

The article proves

```text
SelfWreath.score(q) >= E_(q+1)(q+1).
```

For the proposed family, the height of this explicit base-two exponential
lower bound is already `family59(n)+1`.

## Why the idea is new here

Contender 59 is a tree-indexed language-strength tower: a pair of tree and
number closures is advanced by an operator exposing height-indexed joint stacks
as primitives, and that operator is iterated along a `CTree`. This proposal
adds no evaluator, program enumeration, reflection interface, syntax budget,
or new language stack. Its new layer is a finite-algebraic endofunctor
`G -> G wr Sym(G)` with endogenous arity.

The package is explicit about a review risk: BusyLean has previously retired a
finite combinatorial amplifier as less important than a language-strength
jump. This construction is not claimed to establish a new proof-theoretic
ordinal. Its claim is a genuinely different algebraic mechanism, an exact
finite-object semantics, a strict comparison, and a transparent tower-height
lower bound.

## Archive contents

- `article/contender60_self_wreath.tex` - complete research article.
- `article/contender60_self_wreath.pdf` - compiled article.
- `BusyLean/SelfWreath.lean` - independent cardinality engine.
- `BusyLean/Contender60.lean` - contest bridge and closed number.
- `BusyLean/Comparison60.lean` - comparison lemmas and endpoint theorem.
- `test/Audit60.lean` - `#print axioms` commands.
- `test/Small60.lean` - tiny definitional checks; it never evaluates the contender.
- `scripts/static_audit.py` - forbidden-feature and dependency audit.
- `scripts/small_model.py` - capped independent Python model.
- `scripts/verify_package.sh` - package verification driver.
- `data/small_values.{json,csv}` - exact/symbolic small-model output.
- `patches/` - suggested root-import and audit patches.
- `notes/FORMALIZATION_SCOPE.md` - exact formalization boundary.
- `notes/REBASING.md` - how to retarget the independent engine to a later incumbent.
- `BUILD_STATUS.md` - checks performed and checks still required.
- `REPRODUCE.md` - integration and rebuild instructions.
- `MANIFEST.sha256` - checksums for all other distributed files.

## Verification status

The article, PDF render inspection, independent Python model, and static Lean
source audit were executed in the packaging environment. Lean 4.34.0 was not
available locally, and the exact release could not be installed in that
environment. Therefore the supplied Lean files have **not** been kernel-replayed
here. A clean `lake build`, the supplied small checks, `#print axioms`, and the
repository timing audit remain mandatory before acceptance. See
`BUILD_STATUS.md`.

## Safety

Do not evaluate `contender_60`, `F60 42`, `family59 42`, or comparable values.
The executable examples are capped at tiny `q`; the `q=2` model switches to a
rigorous digit lower bound before constructing the next enormous integer.
