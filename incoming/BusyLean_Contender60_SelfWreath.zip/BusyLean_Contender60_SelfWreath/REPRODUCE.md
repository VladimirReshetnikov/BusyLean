# Reproduction and integration

## 1. Prepare the exact BusyLean baseline

```bash
git clone https://github.com/VladimirReshetnikov/BusyLean.git
cd BusyLean
git checkout e5bdd4fa78779fa762f74150f4d524a42135bf46
cat lean-toolchain
# expected: leanprover/lean4:v4.34.0
```

The repository was advancing rapidly on 2026-10-13. Do not silently build the
proposal against an arbitrary later `main`; either use the exact pin or perform
an explicit rebase as described in `notes/REBASING.md`.

## 2. Install the proposal files

From the unpacked proposal directory:

```bash
cp BusyLean/SelfWreath.lean      /path/to/BusyLean/BusyLean/
cp BusyLean/Contender60.lean     /path/to/BusyLean/BusyLean/
cp BusyLean/Comparison60.lean    /path/to/BusyLean/BusyLean/
cp test/Audit60.lean             /path/to/BusyLean/test/
cp test/Small60.lean             /path/to/BusyLean/test/
```

Append these imports to the repository's root `BusyLean.lean`:

```lean
import BusyLean.SelfWreath
import BusyLean.Contender60
import BusyLean.Comparison60
```

The suggested textual changes are also shown in `patches/BusyLean.lean.patch`.

## 3. Kernel-check and audit

```bash
cd /path/to/BusyLean
lake build
lake env lean test/Small60.lean
lake env lean test/Audit60.lean
```

Add the following to the existing `test/Audit.lean`, after its custom
`#assert_not_in_closure` command has been defined:

```lean
#print axioms BusyLean.SelfWreath.score
#print axioms BusyLean.contender_60
#print axioms BusyLean.contender_59_lt_contender_60
#assert_not_in_closure BusyLean.contender_60 : BusyLean.contender_59
```

The expected policy result is no `Classical.choice` and no forbidden
construct. Do not infer this from the textual audit alone; inspect Lean's
actual output.

## 4. Package-only checks

```bash
python3 scripts/static_audit.py
python3 scripts/small_model.py --q 0 --q 1 --q 2 \
  --json data/small_values.json --csv data/small_values.csv
sha256sum -c MANIFEST.sha256
```

Never increase the small-model inputs to a contest-sized value.

## 5. Rebuild and inspect the article

```bash
cd article
latexmk -pdf -interaction=nonstopmode -halt-on-error \
  contender60_self_wreath.tex
```

Render for visual inspection:

```bash
python /home/oai/skills/pdfs/scripts/render_pdf.py \
  contender60_self_wreath.pdf --out_dir /tmp/selfwreath-render --dpi 160
```

Structural inspection:

```bash
python /home/oai/skills/pdfs/scripts/pdf_inspect.py \
  contender60_self_wreath.pdf
```
