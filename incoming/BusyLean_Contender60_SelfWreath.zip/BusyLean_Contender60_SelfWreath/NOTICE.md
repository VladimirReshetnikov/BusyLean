# Notice

This is a research proposal, not an accepted BusyLean contender at the time of
packaging.

- The mathematical counting and growth arguments are documented in the article.
- The Lean source has not been kernel-replayed in the packaging environment;
  see `BUILD_STATUS.md`.
- Do not evaluate the contender or its contest-scale intermediate values.
- The proposal targets one exact repository commit and may need rebasing if the
  verified incumbent changes.
