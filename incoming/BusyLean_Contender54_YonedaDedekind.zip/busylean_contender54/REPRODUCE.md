# Reproduction guide

All commands below are run from the archive root unless stated otherwise.

## 1. Independent finite-model tests

```bash
python3 scripts/yoneda_tower_reference.py --self-test
```

Expected JSON fingerprints:

```text
YD(0,0) = 1
YD(1,1) = 5
YD(2,2) = 38
|Y(B_0)| = 3
|Y(B_1)| = 5
|Y(B_2)| = 10
|Y(B_3)| = 28
```

The script exhaustively checks reflexivity, antisymmetry, and transitivity of
each reported finite relation.

Additional examples:

```bash
python3 scripts/yoneda_tower_reference.py 1 2
python3 scripts/yoneda_tower_reference.py 2 1 --matrix
```

## 2. Static source audit

```bash
python3 scripts/static_audit.py
```

This checks required declarations, forbidden placeholders (`sorry`, `admit`,
`axiom`, `noncomputable`), nested comments/strings, and delimiter balance. It is
explicitly not a substitute for the Lean kernel.

## 3. Lean build in BusyLean

Copy the files as described in `INTEGRATION.md`, then run:

```bash
lake env lean BusyLean/YonedaTower.lean
lake env lean BusyLean/Contender54.lean
lake env lean BusyLean/Comparison54.lean
lake env lean BusyLean/SmallChecks54.lean
lake build
```

The intended toolchain is exactly:

```text
leanprover/lean4:v4.34.0
```

## 4. Article build

A TeX Live installation with `latexmk`, Libertinus, TikZ, and the standard AMS
packages is sufficient:

```bash
cd docs
latexmk -pdf -interaction=nonstopmode -halt-on-error \
  yoneda_dedekind_contender54.tex
```

Clean auxiliary files with:

```bash
latexmk -C yoneda_dedekind_contender54.tex
```

## 5. PDF verification

The package PDF was rendered page-by-page at 144 dpi and all 12 pages were
visually inspected. Useful repeat commands are:

```bash
python /home/oai/skills/pdfs/scripts/render_pdf.py \
  docs/yoneda_dedekind_contender54.pdf \
  --out_dir rendered --dpi 144

python /home/oai/skills/pdfs/scripts/pdf_inspect.py \
  docs/yoneda_dedekind_contender54.pdf
```

`artifacts/pdf_validation.json` records the page dimensions, extracted-text
counts, outline count, embedded-font status, and visual result.

## 6. Integrity

From the archive root:

```bash
sha256sum -c MANIFEST.sha256
```
