#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
python3 "$ROOT/scripts/yoneda_tower_reference.py" --self-test
python3 "$ROOT/scripts/static_audit.py"
if command -v lake >/dev/null 2>&1; then
  echo "lake found; run the integration commands inside the pinned BusyLean checkout."
else
  echo "lake not found; Lean kernel build skipped (see VALIDATION.md)."
fi
