#!/usr/bin/env python3
"""Lightweight source audit for the proposed BusyLean files.

This is not a Lean kernel check.  It catches packaging mistakes, forbidden
placeholders, broken nested comments/strings, and delimiter imbalance before
integration into the pinned repository.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LEAN_DIR = ROOT / "BusyLean"
FILES = [
    LEAN_DIR / "YonedaTower.lean",
    LEAN_DIR / "Contender54.lean",
    LEAN_DIR / "Comparison54.lean",
    LEAN_DIR / "SmallChecks54.lean",
]

REQUIRED = {
    "YonedaTower.lean": [
        "structure FiniteRelationCode",
        "def idealMasks",
        "def yonedaStep",
        "def yonedaTower",
        "def yonedaDedekind",
        "theorem two_pow_le_yonedaDedekind",
    ],
    "Contender54.lean": ["def family53", "def F54", "def contender_54"],
    "Comparison54.lean": [
        "theorem family53_lt_F54",
        "theorem contender_53_lt_contender_54",
    ],
    "SmallChecks54.lean": ["#eval yonedaDedekind 2 2"],
}

FORBIDDEN = [r"\bsorry\b", r"\badmit\b", r"\baxiom\b", r"\bnoncomputable\b"]


def scan_delimiters(text: str) -> tuple[bool, str]:
    """Check nested Lean block comments, strings, and (), [], {} balance."""
    stack: list[str] = []
    comment_depth = 0
    in_string = False
    escaped = False
    i = 0
    pairs = {")": "(", "]": "[", "}": "{"}
    while i < len(text):
        two = text[i : i + 2]
        ch = text[i]
        if comment_depth:
            if two == "/-":
                comment_depth += 1
                i += 2
                continue
            if two == "-/":
                comment_depth -= 1
                i += 2
                continue
            i += 1
            continue
        if in_string:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
            i += 1
            continue
        if two == "/-":
            comment_depth = 1
            i += 2
            continue
        if two == "--":
            end = text.find("\n", i + 2)
            i = len(text) if end == -1 else end + 1
            continue
        if ch == '"':
            in_string = True
            i += 1
            continue
        if ch in "([{":
            stack.append(ch)
        elif ch in ")]}":
            if not stack or stack[-1] != pairs[ch]:
                return False, f"mismatched delimiter {ch!r} at byte {i}"
            stack.pop()
        i += 1
    if comment_depth:
        return False, f"unterminated nested block comment (depth {comment_depth})"
    if in_string:
        return False, "unterminated string literal"
    if stack:
        return False, f"unclosed delimiters: {''.join(stack)}"
    return True, "balanced"


def main() -> None:
    report: dict[str, object] = {
        "kind": "static source audit (not a Lean kernel build)",
        "files": {},
        "status": "passed",
    }
    failures: list[str] = []
    for path in FILES:
        text = path.read_text(encoding="utf-8")
        ok, delimiter_message = scan_delimiters(text)
        missing = [needle for needle in REQUIRED[path.name] if needle not in text]
        forbidden = [pat for pat in FORBIDDEN if re.search(pat, text)]
        entry = {
            "bytes": len(text.encode("utf-8")),
            "lines": len(text.splitlines()),
            "delimiter_check": delimiter_message,
            "missing_required_fragments": missing,
            "forbidden_placeholders": forbidden,
        }
        report["files"][path.name] = entry
        if not ok or missing or forbidden:
            failures.append(path.name)
    if failures:
        report["status"] = "failed"
        report["failed_files"] = failures
    print(json.dumps(report, indent=2, sort_keys=True))
    raise SystemExit(1 if failures else 0)


if __name__ == "__main__":
    main()
