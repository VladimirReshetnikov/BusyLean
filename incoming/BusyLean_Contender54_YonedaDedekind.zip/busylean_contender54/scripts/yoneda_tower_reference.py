#!/usr/bin/env python3
"""Reference evaluator for the finite Yoneda--Dedekind tower.

This mirrors BusyLean/YonedaTower.lean.  It is intended only for tiny inputs;
the construction becomes infeasible almost immediately by design.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import dataclass
from typing import Callable, Iterable


@dataclass(frozen=True)
class FiniteRelationCode:
    card: int
    leq: Callable[[int, int], bool]


def mask_subset(n: int, a: int, b: int) -> bool:
    return all(not ((a >> i) & 1) or bool((b >> i) & 1) for i in range(n))


def is_lower_mask(p: FiniteRelationCode, s: int) -> bool:
    for x in range(p.card):
        if not ((s >> x) & 1):
            continue
        for y in range(p.card):
            if p.leq(y, x) and not ((s >> y) & 1):
                return False
    return True


def ideal_masks(p: FiniteRelationCode) -> list[int]:
    return [s for s in range(1 << p.card) if is_lower_mask(p, s)]


def is_antichain_mask(p: FiniteRelationCode, s: int) -> bool:
    chosen = [i for i in range(p.card) if (s >> i) & 1]
    return all(
        x == y or (not p.leq(x, y) and not p.leq(y, x))
        for x in chosen
        for y in chosen
    )


def antichain_count(p: FiniteRelationCode) -> int:
    return sum(is_antichain_mask(p, s) for s in range(1 << p.card))


def boolean_lattice(n: int) -> FiniteRelationCode:
    size = 1 << n
    return FiniteRelationCode(size, lambda a, b: mask_subset(n, a, b))


def yoneda_step(p: FiniteRelationCode) -> FiniteRelationCode:
    ideals = ideal_masks(p)
    old = p.card

    def leq(x: int, y: int) -> bool:
        if x < old:
            if y < old:
                return p.leq(x, y)
            return bool((ideals[y - old] >> x) & 1)
        if y < old:
            return False
        return mask_subset(old, ideals[x - old], ideals[y - old])

    return FiniteRelationCode(old + len(ideals), leq)


def yoneda_tower(generators: int, depth: int) -> FiniteRelationCode:
    p = boolean_lattice(generators)
    for _ in range(depth):
        p = yoneda_step(p)
    return p


def relation_matrix(p: FiniteRelationCode) -> list[list[int]]:
    return [[int(p.leq(i, j)) for j in range(p.card)] for i in range(p.card)]


def relation_sha256(p: FiniteRelationCode) -> str:
    bits = bytes(int(p.leq(i, j)) for i in range(p.card) for j in range(p.card))
    return hashlib.sha256(bits).hexdigest()


def is_poset(p: FiniteRelationCode) -> bool:
    reflexive = all(p.leq(x, x) for x in range(p.card))
    antisymmetric = all(
        not (p.leq(x, y) and p.leq(y, x)) or x == y
        for x in range(p.card)
        for y in range(p.card)
    )
    transitive = all(
        not (p.leq(x, y) and p.leq(y, z)) or p.leq(x, z)
        for x in range(p.card)
        for y in range(p.card)
        for z in range(p.card)
    )
    return reflexive and antisymmetric and transitive


def self_test() -> dict[str, object]:
    expected = {(0, 0): 1, (1, 1): 5, (2, 2): 38}
    observed: dict[str, int] = {}
    relation_hashes: dict[str, str] = {}
    for key, value in expected.items():
        g, d = key
        p = yoneda_tower(g, d)
        assert p.card == value, (key, p.card, value)
        assert is_poset(p), key
        label = f"YD({g},{d})"
        observed[label] = p.card
        relation_hashes[label] = relation_sha256(p)

    # First-step checks: |Y(B_n)| = 2^n + M(n), M(0..3)=2,3,6,20.
    # The ideal-mask count is cross-checked against an independent brute-force
    # antichain count, using the finite Birkhoff correspondence.
    dedekind = [2, 3, 6, 20]
    first_steps: dict[str, int] = {}
    cross_checks: dict[str, dict[str, int]] = {}
    for n, m_n in enumerate(dedekind):
        p = boolean_lattice(n)
        ideals = len(ideal_masks(p))
        antichains = antichain_count(p)
        assert ideals == antichains == m_n
        q = yoneda_step(p)
        assert q.card == (1 << n) + m_n
        assert is_poset(q)
        first_steps[f"|Y(B_{n})|"] = q.card
        cross_checks[f"B_{n}"] = {"ideals": ideals, "antichains": antichains}

    return {
        "observed": observed,
        "relation_sha256": relation_hashes,
        "first_steps": first_steps,
        "ideal_antichain_cross_checks": cross_checks,
        "status": "all checks passed",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("generators", type=int, nargs="?", default=2)
    parser.add_argument("depth", type=int, nargs="?", default=2)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--matrix", action="store_true")
    args = parser.parse_args()

    if args.generators < 0 or args.depth < 0:
        parser.error("generators and depth must be nonnegative")

    if args.self_test:
        print(json.dumps(self_test(), indent=2, sort_keys=True))
        return

    p = yoneda_tower(args.generators, args.depth)
    result: dict[str, object] = {
        "generators": args.generators,
        "depth": args.depth,
        "cardinality": p.card,
        "is_poset": is_poset(p),
    }
    if args.matrix:
        result["relation_matrix"] = relation_matrix(p)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
