/-
Copyright 2026 BusyLean Contributors.
SPDX-License-Identifier: MIT-0
Authors: OpenAI
-/

import BusyLean.Contender54
import BusyLean.Comparison53

/-! # Contender 54: comparison theorems -/

namespace BusyLean

open FiniteRelationCode

/-- The whole Boolean lattice survives through the self-indexed tower. -/
theorem two_pow_family53_le_F54 (n : Nat) :
    2 ^ family53 n ≤ F54 n :=
  two_pow_le_yonedaDedekind (family53 n) (family53 n)

/-- At every input, `F54` is already larger than Contender 53's family. -/
theorem family53_lt_F54 (n : Nat) : family53 n < F54 n :=
  Nat.lt_of_lt_of_le (family53 n).lt_two_pow_self
    (two_pow_family53_le_F54 n)

/-- The input is smaller than Contender 53's family. -/
theorem input_lt_family53 (n : Nat) : n < family53 n :=
  Nat.lt_trans (input_lt_F53 n) (input_lt_F53 (F53 n))

/-- The new family is inflationary at every input. -/
theorem input_lt_F54 (n : Nat) : n < F54 n :=
  Nat.lt_trans (input_lt_family53 n) (family53_lt_F54 n)

/-- **The required comparison:** Contender 53 is strictly below Contender 54. -/
theorem contender_53_lt_contender_54 : contender_53 < contender_54 := by
  simpa [contender_53, contender_54, family53] using family53_lt_F54 42

/-- Consequently every earlier formally chained contender is also below 54. -/
theorem contender_52_lt_contender_54 : contender_52 < contender_54 :=
  Nat.lt_trans contender_52_lt_contender_53 contender_53_lt_contender_54

end BusyLean
