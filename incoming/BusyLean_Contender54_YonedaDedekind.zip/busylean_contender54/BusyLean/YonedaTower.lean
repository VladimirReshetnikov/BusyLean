/-
Copyright 2026 BusyLean Contributors.
SPDX-License-Identifier: MIT-0
Authors: OpenAI
-/

import BusyLean.Contender53

/-!
# Finite Yoneda--Dedekind towers

This file gives a deliberately executable encoding of a finite ordered universe.
A carrier with `card` points is represented by the natural numbers below `card`;
`leq x y` is its binary relation.  Lower ideals are represented by bit masks.

For a finite poset `P`, `yonedaStep P` is the finite poset whose carrier is the
disjoint union

```
P + Ideal(P).
```

The old points keep their old order.  Two ideals are ordered by inclusion, and
an old point `x` lies below a new ideal `I` exactly when `x ∈ I`.  No ideal lies
below an old point.  Thus every monotone predicate/lower ideal over the old
universe becomes a first-class point in the new universe.

The code carries only the finite relation data needed by the evaluator.  The
paper in `docs/` proves that `yonedaStep` preserves partial orders.  Keeping the
proof fields out of the executable structure makes reduction transparent and
avoids proof terms in the enormous enumeration.
-/

namespace BusyLean

/-- Executable code for a finite binary relation on `{0, ..., card - 1}`. -/
structure FiniteRelationCode where
  card : Nat
  leq : Nat → Nat → Bool

namespace FiniteRelationCode

/-- Inclusion of two `n`-bit masks. -/
def maskSubset (n a b : Nat) : Bool :=
  (List.range n).all fun i => (!(a.testBit i)) || b.testBit i

/-- Whether an `n`-bit mask is a lower ideal of the coded relation. -/
def isLowerMask (P : FiniteRelationCode) (s : Nat) : Bool :=
  (List.range P.card).all fun x =>
    (List.range P.card).all fun y =>
      (!(P.leq y x && s.testBit x)) || s.testBit y

/-- All lower ideals, represented by masks in increasing numerical order. -/
def idealMasks (P : FiniteRelationCode) : List Nat :=
  (List.range (2 ^ P.card)).filter fun s => isLowerMask P s

/-- Read the `j`th enumerated ideal.  The default is unreachable on valid indices. -/
def idealMaskAt (P : FiniteRelationCode) (j : Nat) : Nat :=
  (idealMasks P).getD j 0

/-- The Boolean lattice on `n` generators, encoded by inclusion of bit masks. -/
def booleanLattice (n : Nat) : FiniteRelationCode where
  card := 2 ^ n
  leq := fun a b => maskSubset n a b

/--
The cumulative ideal/Yoneda extension `P + Ideal(P)`.

The four order cases are old--old, old--ideal, ideal--old, and ideal--ideal.
-/
def yonedaStep (P : FiniteRelationCode) : FiniteRelationCode where
  card := P.card + (idealMasks P).length
  leq := fun x y =>
    if x < P.card then
      if y < P.card then
        P.leq x y
      else
        (idealMaskAt P (y - P.card)).testBit x
    else if y < P.card then
      false
    else
      maskSubset P.card
        (idealMaskAt P (x - P.card))
        (idealMaskAt P (y - P.card))

/-- Iterate the cumulative ideal extension a finite number of times. -/
def yonedaTower : Nat → FiniteRelationCode → FiniteRelationCode
  | 0, P => P
  | k + 1, P => yonedaTower k (yonedaStep P)

@[simp] theorem booleanLattice_card (n : Nat) :
    (booleanLattice n).card = 2 ^ n := rfl

@[simp] theorem yonedaStep_card (P : FiniteRelationCode) :
    (yonedaStep P).card = P.card + (idealMasks P).length := rfl

/-- A Yoneda step never discards old points. -/
theorem card_le_yonedaStep (P : FiniteRelationCode) :
    P.card ≤ (yonedaStep P).card := by
  change P.card ≤ P.card + (idealMasks P).length
  exact Nat.le_add_right _ _

/-- Every finite tower contains its initial carrier. -/
theorem card_le_yonedaTower (k : Nat) (P : FiniteRelationCode) :
    P.card ≤ (yonedaTower k P).card := by
  induction k generalizing P with
  | zero => exact Nat.le_refl _
  | succ k ih =>
      exact Nat.le_trans (card_le_yonedaStep P) (ih (yonedaStep P))

/-- The independent two-parameter Yoneda--Dedekind number. -/
def yonedaDedekind (generators depth : Nat) : Nat :=
  (yonedaTower depth (booleanLattice generators)).card

/-- The basic exponential lower bound, formalized without evaluating any ideals. -/
theorem two_pow_le_yonedaDedekind (generators depth : Nat) :
    2 ^ generators ≤ yonedaDedekind generators depth :=
  card_le_yonedaTower depth (booleanLattice generators)

end FiniteRelationCode

end BusyLean
