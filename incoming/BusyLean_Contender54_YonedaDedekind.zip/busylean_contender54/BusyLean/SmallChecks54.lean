/-
Copyright 2026 BusyLean Contributors.
SPDX-License-Identifier: MIT-0
Authors: OpenAI
-/

import BusyLean.YonedaTower

namespace BusyLean

open FiniteRelationCode

-- Independent computational fingerprints for the finite construction.
-- Expected output: 1, 5, 38.
#eval yonedaDedekind 0 0
#eval yonedaDedekind 1 1
#eval yonedaDedekind 2 2

end BusyLean
