#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/docs"
latexmk -pdf -interaction=nonstopmode -halt-on-error yoneda_dedekind_contender54.tex
