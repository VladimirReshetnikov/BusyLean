# Integration into BusyLean

## Baseline

Integrate against repository commit
`650b23afcc266fb90d0140bc4bbc136d63f07209`, whose `lean-toolchain` selects
`leanprover/lean4:v4.34.0` and whose current champion is Contender 53.

## Files to copy

From the archive root, copy:

```text
BusyLean/YonedaTower.lean
BusyLean/Contender54.lean
BusyLean/Comparison54.lean
BusyLean/SmallChecks54.lean   # optional; intended as a standalone smoke test
```

into the corresponding `BusyLean/` directory of the repository.

## Root imports

Append these imports to `BusyLean.lean`, immediately after the Contender 53
imports:

```lean
import BusyLean.YonedaTower
import BusyLean.Contender54
import BusyLean.Comparison54
```

Do not import `SmallChecks54` from the library root because it deliberately
contains `#eval` commands. The supplied `patches/BusyLean.lean.patch` makes the
same change.

## Kernel checks

Run from the repository root:

```bash
lake env lean BusyLean/YonedaTower.lean
lake env lean BusyLean/Contender54.lean
lake env lean BusyLean/Comparison54.lean
lake env lean BusyLean/SmallChecks54.lean
lake build
```

The smoke test should print:

```text
1
5
38
```

The critical theorem exposed to the repository is:

```lean
theorem contender_53_lt_contender_54 : contender_53 < contender_54
```

The comparison is intentionally independent of ideal-enumeration ordering. It
uses only that a Yoneda tower retains the Boolean lattice with `2^N` points and
that `N < 2^N`.

## README

`README_SECTION.md` is written to be inserted before the existing
“Contender 53” section. After integration, update the opening “Current
contender” heading and any repository-level theorem index as appropriate.

## License

The files use SPDX identifier `MIT-0`, matching the pinned BusyLean license.
