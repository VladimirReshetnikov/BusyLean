# Upstream baseline snapshot

- Repository: `VladimirReshetnikov/BusyLean`
- Branch: `main`
- Commit: `650b23afcc266fb90d0140bc4bbc136d63f07209`
- Commit time: `2026-10-13T20:14:43Z`
- Commit message: `New proposals`
- Toolchain: `leanprover/lean4:v4.34.0`
- Current champion at that revision: Contender 53

The incumbent's defining architecture is:

```lean
def reflAlong (T : CTree) (g : Nat → Nat) : CTree → Nat → Nat
  | .zero => g
  | .succ a => ladderReflect (reflAlong T g a) T
  | .lim f => fun m => maxUpTo (fun i => reflAlong T g (f i) m) m
  | _ => g

def family52 (n : Nat) : Nat := F52 (F52 n)

def F53 (n : Nat) : Nat :=
  hier (reflAlong (stackTree (family52 n)) family52
        (stackTree (family52 n)))
    (stackTree (family52 n)) (family52 n)

def contender_53 : Nat := F53 (F53 42)
```

This proposal deliberately changes both the state space and successor
mechanism: finite ordered semantic universes and ideal reification replace
coded ordinal trees and reflection/language closure.
