# Validation status

## Completed

1. **Repository pinning.** The proposal was designed against BusyLean commit
   `650b23afcc266fb90d0140bc4bbc136d63f07209`, current on 13 October 2026.
   Its root imports end at Contender 53 and Comparison 53; its toolchain is Lean
   `v4.34.0`.
2. **Mathematical audit.** The article proves that the cumulative ideal
   extension preserves finite partial orders, establishes the cardinality
   equation, proves the Dedekind lower bound, proves primitive recursiveness,
   and gives the contest comparison.
3. **Independent executable model.** The Python implementation mirrors the
   finite relation, lower-ideal enumeration, cumulative extension, and tower.
   Its self-test exhaustively validates the poset laws in the reported small
   cases and reproduces the fingerprints `1`, `5`, and `38`.
4. **Lean source static audit.** All Lean sources pass required-declaration,
   placeholder, nested-comment/string, and delimiter checks. No `sorry`,
   `admit`, `axiom`, or `noncomputable` declaration appears.
5. **Core API review.** The code uses only definitions and elementary lemmas
   available in the pinned Lean line, notably `Nat.le_add_right`,
   `Nat.lt_two_pow_self`, `List.getD`, Boolean bit operations, and structural
   recursion.
6. **Article build.** The LaTeX source compiles successfully with `latexmk`
   under TeX Live 2025. The output is a 12-page A4 PDF with 24 outline entries
   and embedded font programs.
7. **Visual PDF QA.** Every rendered page was inspected. No clipping, overlap,
   broken glyph, or margin violation was observed.

Machine-readable records are in:

```text
artifacts/reference_self_test.json
artifacts/static_audit.json
artifacts/pdf_validation.json
```

## Not completed in this environment

The final Lean files were **not kernel-checked locally** because neither `lean`
nor `lake` was installed and the sandbox could not retrieve the approximately
580 MB pinned Linux toolchain release asset. The package therefore does not
claim a completed local `lake build`.

This limitation is isolated to toolchain availability, not to an omitted proof:
`Comparison54.lean` contains the complete intended proof term. The exact four
commands needed for kernel verification are given in `INTEGRATION.md` and
`REPRODUCE.md`. The source was kept deliberately small so any elaboration issue
should be local and easy to repair rather than hidden in a large proof stack.

## Confidence and likely elaboration-sensitive points

The following lines deserve first attention in a kernel run, solely because
Lean notation and theorem namespaces can change between releases:

- method notation `(family53 n).lt_two_pow_self`;
- `Nat.le_add_right _ _`;
- `List.getD j 0`;
- the definitional reduction in `two_pow_le_yonedaDedekind`;
- the final `simpa [contender_53, contender_54, family53]`.

Each item was cross-checked against the current Lean 4 source API or against
usage in the pinned ecosystem, but only the kernel build is decisive.
