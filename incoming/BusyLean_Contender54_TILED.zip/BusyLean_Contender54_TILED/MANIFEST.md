# Archive manifest

## Research paper

- `article/contender54_tiled.tex` - complete LaTeX source.
- `article/contender54_tiled.pdf` - compiled 18-page paper, rendered and visually inspected.

## Lean formalization

- `BusyLean/LargeElim.lean` - tree-indexed semantic type family, polymorphic iterator, seeds, collapse, evaluator, and calibration lemmas.
- `BusyLean/Contender54.lean` - TILED schedule, family `F54`, and closed `contender_54`.
- `BusyLean/Comparison54.lean` - inflationarity, orbit lower bound, ramified-core inclusion, and strict comparisons with Contenders 53 and 52.
- `test/LargeElimSmoke.lean` - small executable reductions and theorem-signature checks.
- `test/Audit54.lean` - `#print axioms` driver for the closed number and principal comparison theorems.

## Integration

- `patch/contender54-tiled.patch` - ready-to-apply patch against BusyLean baseline `833aa2617f0ed7a8404015c7e520226e0ff64c3a`.
- `BUILD.md` - build, patch, audit, and paper-compilation instructions.

## Verification evidence

- `ci/verification-summary.txt` - concise verified-commit, toolchain, timings, theorem checks, axioms, and source hashes.
- `ci/evidence/` - exact files downloaded from the successful GitHub Actions artifact.
- `ci/contender54-verification.zip` - original downloaded CI artifact.
- `ci/contender54-ci.yml` - isolated verification workflow.
- `ci/BRANCH.txt` - baseline, temporary branch, verified commit, run, and job identifiers.
- `ci/pdf-preflight.txt` - PDF structural preflight.
- `ci/pdf-visual-verification.txt` - rendering and page-inspection record.
- `ci/final-package-audit.txt` - final text-extraction, placeholder, source-identity, patch, and PDF checks.

## Explanatory material

- `README.md` - overview, central idea, theorem statements, trust scope, and archive map.
- `RESEARCH_NOTES.md` - novelty analysis, limitations, and high-value next theorems.
- `SHA256SUMS.txt` - checksums of every other file in the archive.
