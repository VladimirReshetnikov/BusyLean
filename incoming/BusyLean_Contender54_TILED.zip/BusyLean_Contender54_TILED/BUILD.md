# Build and integration instructions

## Baseline

The proposal was developed against BusyLean commit:

`833aa2617f0ed7a8404015c7e520226e0ff64c3a`

The pinned toolchain is Lean 4.34.0.

## Apply the patch

From a clean checkout of the baseline commit:

```bash
git apply patch/contender54-tiled.patch
```

Alternatively, copy the three files under `BusyLean/` and the smoke test under `test/`, then add these imports to `BusyLean.lean`:

```lean
import BusyLean.LargeElim
import BusyLean.Contender54
import BusyLean.Comparison54
```

## Verify Lean sources

```bash
lake build BusyLean.LargeElim
lake build BusyLean.Contender54
lake build BusyLean.Comparison54
lake env lean test/LargeElimSmoke.lean
lake env lean test/Audit54.lean
```

Do not attempt to evaluate `contender_54`.

## Compile the paper

```bash
cd article
latexmk -pdf -interaction=nonstopmode -halt-on-error contender54_tiled.tex
```

## Re-run the isolated CI workflow

The archive includes the workflow used on the verification branch at:

`ci/contender54-ci.yml`

Copy it to `.github/workflows/contender54-ci.yml`, adjust the branch trigger if needed, and push the branch. The workflow builds the definitions and proofs from a clean checkout, runs smoke checks, prints axioms, records versions and source hashes, and uploads the evidence directory.
