# Research notes and open directions

## What is genuinely new

The novelty is not the use of a previous contender as a numeric seed; every integrated BusyLean successor must compare to and build on earlier machinery. The new resource is **value-indexed semantic type formation**:

```lean
LargeTy : CTree -> Type
```

The tree being traversed determines the type of intermediate values. Successor nodes raise the functional order, and limit nodes form non-uniform dependent products. Existing fixed-output tree languages do not expose this resource.

## Why the transparent orbit branch is present

A direct lower-bound theorem for arbitrary values of the ramified higher-type branch would require a substantial logical-relations development. Rather than hide that gap, TILED separates two roles:

1. branch zero gives a simple, independently checkable lower bound by an old-family orbit;
2. nonzero branches carry the new large-elimination mechanism, with a theorem proving that the deepest observed ramified branch is included in `F54`.

This makes the formal claim honest while leaving a clear target for strengthening.

## Most important next theorem

Prove a monotonicity/logical-relations theorem strong enough to derive a lower bound for:

```lean
largeElim family53
  (ramify (stackTree N) N)
  N
```

in terms of an explicit hierarchy over `family53`. Such a theorem would turn the presently structural inclusion result into a quantitative domination result for the novel branch itself.

## Other directions

- Internalize `LargeTy` in a coded CIC-like object language and prove normalization.
- Replace conservative `supL`/`supH` clauses by universe-indexed interpretations.
- Develop a parametricity theorem for `largeStep`, `largeSeed`, and `largeCollapse`.
- Compare TILED with bar recursion, higher-type primitive recursion, and iterated inductive definitions.
- Define a semantic-tree rank and seek matching upper/lower proof-theoretic calibrations.
- Prove robustness under alternative seed/collapse pairs.
- Add an independent checker or second Lean implementation of the kernel.
