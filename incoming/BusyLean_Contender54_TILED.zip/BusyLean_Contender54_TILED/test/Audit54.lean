import BusyLean.Comparison54

#print axioms BusyLean.contender_54
#print axioms BusyLean.contender_53_lt_contender_54
#print axioms BusyLean.iter_contender_53_lt_contender_54
