# BusyLean Contender 54: TILED

This archive proposes **Contender 54: Tree-Indexed Large-Elimination Diagonal (TILED)** for the BusyLean repository.

## Central idea

Earlier BusyLean tree readers recurse over a run-time tree while the result type is fixed by the reader's source. TILED instead eliminates the tree into `Type`:

- a leaf denotes `Nat`;
- a successor denotes an endomorphism space;
- a limit denotes a dependent product whose fibers are recursively selected by the tree.

A canonical typed iterator is built at that tree-computed type and then collapsed to a natural number by bounded observation. This is a genuine large-elimination mechanism, not merely an additional ordinal label or a longer application chain.

The closed number is:

```lean
def contender_54 : Nat := F54 (F54 42)
```

where `F54` evaluates the large-elimination kernel over a previous-contender-sized schedule of semantic types.

## Certified comparisons

The Lean package proves:

```lean
theorem contender_53_lt_contender_54 :
  contender_53 < contender_54
```

and the stronger quantitative lower bound:

```lean
theorem iter_contender_53_lt_contender_54 :
  Ordinal.iterN family53 contender_53 contender_53 < contender_54
```

Thus Contender 54 exceeds an orbit of the entire Contender 53 family whose length and starting point are both `contender_53`.

A separate theorem records the novel branch itself:

```lean
theorem ramified_core_le_F54 (n : Nat) :
  largeElim family53
    (ramify (stackTree (family53 n)) (family53 n))
    (family53 n) ≤ F54 n
```

This distinction is deliberate: the orbit branch gives a transparent formal comparison, while the ramified branch is the new dependent-type computational resource.

## Contents

- `BusyLean/LargeElim.lean` - reusable large-elimination kernel.
- `BusyLean/Contender54.lean` - TILED family and closed contender.
- `BusyLean/Comparison54.lean` - strict and quantitative comparisons.
- `test/LargeElimSmoke.lean` - executable small calibrations and theorem checks.
- `test/Audit54.lean` - axiom-report driver.
- `article/contender54_tiled.tex` - full research article.
- `article/contender54_tiled.pdf` - compiled article.
- `patch/contender54-tiled.patch` - integration patch against the recorded BusyLean baseline.
- `ci/` - verification transcript, versions, hashes, and branch record.
- `BUILD.md` - reproduction and integration instructions.

## Trust and scope

The definitions are total and constructive. No unbounded search, halting oracle, semantic truth predicate, `sorry`, or noncomputable choice is used in the new sources. The closed term is computable in principle, though evaluating it is infeasible by design.

The formal development certifies the comparison inequalities and inclusion of the ramified branch. It does **not** claim a complete proof-theoretic ordinal calibration of the new mechanism; that is explicitly separated as future research in the article.

## Verification branch

The exact clean-checkout verification was run successfully on the temporary branch:

`research/contender54-tiled-ci`

Verified commit: `803c9771c730fd0125eb6a8ebd877a90782e9fff`  
Workflow run: `38459404680`

The repository's `main` branch was not modified or merged by this research run.
